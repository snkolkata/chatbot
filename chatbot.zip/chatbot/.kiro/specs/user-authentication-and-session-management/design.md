# Design Document: User Authentication and Session Management

## Overview

This design document outlines the architecture for implementing a comprehensive authentication and authorization system with role-based access control (RBAC) for the RAG chatbot application. The system will integrate PostgreSQL for persistent storage, implement secure session management, and enhance the chatbot with interactive features and user-specific context.

### Key Design Goals

1. **Security First**: Implement industry-standard security practices for authentication and data protection
2. **Seamless Integration**: Integrate with existing Streamlit application architecture
3. **User Experience**: Provide intuitive interfaces with interactive chatbot features
4. **Scalability**: Design database schema and session management to support growth
5. **Admin Control**: Provide comprehensive administrative capabilities

## Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Streamlit Frontend                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │ Login Page   │  │ Register Page│  │  Chat Page   │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│  ┌──────────────┐  ┌──────────────┐                        │
│  │ Admin Panel  │  │ Password     │                        │
│  │              │  │ Reset Page   │                        │
│  └──────────────┘  └──────────────┘                        │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Application Services                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │ Auth Service │  │ User Service │  │Session Service│    │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│  ┌──────────────┐  ┌──────────────┐                        │
│  │ RAG Service  │  │ Email Service│                        │
│  │ (Enhanced)   │  │              │                        │
│  └──────────────┘  └──────────────┘                        │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Data Layer                                │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │ PostgreSQL   │  │ ChromaDB     │  │ File Storage │     │
│  │ (User Data)  │  │ (Vectors)    │  │ (Documents)  │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
└─────────────────────────────────────────────────────────────┘
```

### Technology Stack

- **Frontend**: Streamlit (existing)
- **Backend**: Python 3.x
- **Database**: PostgreSQL 14+ with psycopg2
- **ORM**: SQLAlchemy for database operations
- **Password Hashing**: bcrypt
- **Session Management**: Streamlit session_state + PostgreSQL
- **Email**: smtplib for password reset emails
- **Vector Store**: ChromaDB (existing)
- **LLM**: OpenAI/Gemini (existing)

## Components and Interfaces

### 1. Database Schema

#### Users Table
```sql
CREATE TABLE users (
    user_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'user',
    is_active BOOLEAN DEFAULT TRUE,
    failed_login_attempts INTEGER DEFAULT 0,
    account_locked_until TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    CONSTRAINT valid_role CHECK (role IN ('user', 'admin'))
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
```

#### Chat Sessions Table
```sql
CREATE TABLE chat_sessions (
    session_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    title VARCHAR(255) DEFAULT 'New Chat',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

CREATE INDEX idx_chat_sessions_user_id ON chat_sessions(user_id);
CREATE INDEX idx_chat_sessions_updated_at ON chat_sessions(updated_at DESC);
```

#### Chat Messages Table
```sql
CREATE TABLE chat_messages (
    message_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES chat_sessions(session_id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL,
    content TEXT NOT NULL,
    sources JSONB NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT valid_role CHECK (role IN ('user', 'assistant'))
);

CREATE INDEX idx_chat_messages_session_id ON chat_messages(session_id);
CREATE INDEX idx_chat_messages_created_at ON chat_messages(created_at);
```

#### Password Reset Tokens Table
```sql
CREATE TABLE password_reset_tokens (
    token_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_password_reset_tokens_token ON password_reset_tokens(token);
CREATE INDEX idx_password_reset_tokens_user_id ON password_reset_tokens(user_id);
```

### 2. Service Layer Components

#### AuthService (`services/auth_service.py`)

**Purpose**: Handle all authentication operations

**Key Methods**:
```python
class AuthService:
    def register_user(email: str, password: str, full_name: str) -> Dict
    def authenticate_user(email: str, password: str) -> Optional[User]
    def hash_password(password: str) -> str
    def verify_password(password: str, password_hash: str) -> bool
    def validate_password_strength(password: str) -> bool
    def handle_failed_login(email: str) -> None
    def is_account_locked(email: str) -> bool
    def unlock_account(email: str) -> None
    def create_password_reset_token(email: str) -> str
    def verify_reset_token(token: str) -> Optional[UUID]
    def reset_password(token: str, new_password: str) -> bool
```

**Security Features**:
- bcrypt password hashing with cost factor 12
- Rate limiting: 5 failed attempts = 15-minute lockout
- Password validation: min 8 chars, uppercase, lowercase, number
- Secure token generation for password reset (UUID4)
- Token expiration (1 hour)

#### UserService (`services/user_service.py`)

**Purpose**: Manage user data and profiles

**Key Methods**:
```python
class UserService:
    def get_user_by_id(user_id: UUID) -> Optional[User]
    def get_user_by_email(email: str) -> Optional[User]
    def get_all_users() -> List[User]
    def update_user_role(user_id: UUID, new_role: str) -> bool
    def deactivate_user(user_id: UUID) -> bool
    def delete_user(user_id: UUID) -> bool
    def update_last_login(user_id: UUID) -> None
    def get_user_statistics() -> Dict
```

#### SessionService (`services/session_service.py`)

**Purpose**: Manage chat sessions and message history

**Key Methods**:
```python
class SessionService:
    def create_session(user_id: UUID, title: str = "New Chat") -> UUID
    def get_user_sessions(user_id: UUID) -> List[ChatSession]
    def get_session_messages(session_id: UUID) -> List[ChatMessage]
    def add_message(session_id: UUID, role: str, content: str, sources: List = None) -> UUID
    def update_session_title(session_id: UUID, title: str) -> bool
    def delete_session(session_id: UUID) -> bool
    def get_active_session(user_id: UUID) -> Optional[ChatSession]
    def set_active_session(user_id: UUID, session_id: UUID) -> bool
    def get_session_context(session_id: UUID, max_messages: int = 10) -> List[Dict]
```

#### EmailService (`services/email_service.py`)

**Purpose**: Send transactional emails

**Key Methods**:
```python
class EmailService:
    def send_password_reset_email(email: str, reset_token: str) -> bool
    def send_welcome_email(email: str, full_name: str) -> bool
    def send_account_locked_email(email: str) -> bool
```

**Configuration**:
- SMTP server configuration via environment variables
- HTML email templates
- Fallback to console logging in development

### 3. Database Connection Manager

#### DatabaseManager (`services/database_manager.py`)

**Purpose**: Manage PostgreSQL connections and provide session management

**Key Features**:
```python
class DatabaseManager:
    def __init__(connection_string: str)
    def get_session() -> Session  # Context manager
    def initialize_database() -> None  # Create tables
    def health_check() -> bool
```

**Connection Pooling**:
- SQLAlchemy connection pool (pool_size=5, max_overflow=10)
- Automatic reconnection on failure
- Connection timeout: 30 seconds

### 4. Enhanced RAG Service

#### Modifications to RAGService

**New Features**:
1. **Context-Aware Responses**: Use chat history for better context
2. **User-Specific Retrieval**: Filter documents by user permissions (future)
3. **Streaming Responses**: Support for token-by-token streaming

**Updated Methods**:
```python
class RAGService:
    def query_with_context(
        user_message: str,
        chat_history: List[Dict],
        k: int = 3
    ) -> Dict
    
    def stream_response(
        user_message: str,
        context_chunks: List[Document],
        chat_history: List[Dict]
    ) -> Generator[str, None, None]
```

### 5. Frontend Components

#### Login Page (`pages/Login.py`)

**Features**:
- Email and password input fields
- "Remember me" checkbox (extends session to 7 days)
- "Forgot password?" link
- Link to registration page
- Error message display
- Redirect to appropriate page after login

**UI Layout**:
```
┌─────────────────────────────────┐
│         RAG Chatbot             │
│         Login                   │
│                                 │
│  Email: [________________]      │
│  Password: [____________]       │
│                                 │
│  □ Remember me                  │
│                                 │
│  [      Login      ]            │
│                                 │
│  Forgot password?               │
│  Don't have an account? Sign up │
└─────────────────────────────────┘
```

#### Registration Page (`pages/Register.py`)

**Features**:
- Full name, email, password, confirm password fields
- Real-time password strength indicator
- Terms of service checkbox
- Email validation
- Password match validation
- Success message with redirect

#### Enhanced Chat Page (`Home.py` - Modified)

**New Features**:
1. **Session Selector**: Dropdown to switch between chat sessions
2. **New Chat Button**: Create new session
3. **Session Title Editor**: Rename current session
4. **User Profile Display**: Show logged-in user info
5. **Typing Indicator**: Animated "..." while generating response
6. **Message Timestamps**: Display time for each message
7. **User Avatars**: Different icons for user vs assistant
8. **Smooth Typing Animation**: Simulate typing effect for responses
9. **Session History Sidebar**: List of previous sessions

**UI Enhancements**:
```python
# Typing indicator component
def show_typing_indicator():
    st.markdown("""
        <div class="typing-indicator">
            <span></span><span></span><span></span>
        </div>
    """, unsafe_allow_html=True)

# Animated response display
def display_response_animated(text: str, delay: float = 0.01):
    placeholder = st.empty()
    displayed_text = ""
    for char in text:
        displayed_text += char
        placeholder.markdown(displayed_text)
        time.sleep(delay)
```

#### Admin Dashboard (`pages/Admin.py` - Enhanced)

**New Sections**:

1. **User Management Tab**:
   - User list with search and filter
   - Role management controls
   - Account activation/deactivation
   - User deletion with confirmation
   - Last login timestamps

2. **Session Analytics Tab**:
   - Active sessions count
   - Total messages per day chart
   - Most active users
   - Average session duration
   - Query volume trends

3. **System Monitoring Tab**:
   - Database connection status
   - Vector store statistics
   - API usage metrics
   - Error logs viewer

4. **Document Management Tab** (existing):
   - Keep existing functionality

**UI Layout**:
```
┌─────────────────────────────────────────────────┐
│  Admin Dashboard                                │
│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐          │
│  │Users │ │Sessions│ │System│ │Docs │          │
│  └──────┘ └──────┘ └──────┘ └──────┘          │
│                                                 │
│  [Tab Content Area]                             │
│                                                 │
└─────────────────────────────────────────────────┘
```

#### Password Reset Page (`pages/PasswordReset.py`)

**Two-Step Process**:
1. **Request Reset**: Enter email, receive token
2. **Reset Password**: Enter token and new password

### 6. Middleware and Guards

#### AuthGuard (`utils/auth_guard.py`)

**Purpose**: Protect routes and check authentication

```python
def require_auth(func):
    """Decorator to require authentication"""
    def wrapper(*args, **kwargs):
        if not is_authenticated():
            st.switch_page("pages/Login.py")
            return
        return func(*args, **kwargs)
    return wrapper

def require_admin(func):
    """Decorator to require admin role"""
    def wrapper(*args, **kwargs):
        if not is_authenticated() or not is_admin():
            st.error("Access denied")
            return
        return func(*args, **kwargs)
    return wrapper

def is_authenticated() -> bool:
    return 'user_id' in st.session_state

def is_admin() -> bool:
    return st.session_state.get('role') == 'admin'
```

## Data Models

### User Model
```python
@dataclass
class User:
    user_id: UUID
    email: str
    full_name: str
    role: str
    is_active: bool
    created_at: datetime
    last_login: Optional[datetime]
```

### ChatSession Model
```python
@dataclass
class ChatSession:
    session_id: UUID
    user_id: UUID
    title: str
    created_at: datetime
    updated_at: datetime
    is_active: bool
    message_count: int = 0
```

### ChatMessage Model
```python
@dataclass
class ChatMessage:
    message_id: UUID
    session_id: UUID
    role: str
    content: str
    sources: Optional[List[str]]
    created_at: datetime
```

## Error Handling

### Custom Exceptions

```python
class AuthenticationError(Exception):
    """Raised when authentication fails"""
    pass

class AuthorizationError(Exception):
    """Raised when user lacks permissions"""
    pass

class AccountLockedError(Exception):
    """Raised when account is locked"""
    pass

class InvalidTokenError(Exception):
    """Raised when reset token is invalid"""
    pass

class DatabaseError(Exception):
    """Raised when database operations fail"""
    pass
```

### Error Handling Strategy

1. **User-Friendly Messages**: Never expose internal errors
2. **Logging**: Log all errors with context
3. **Graceful Degradation**: Fallback to safe states
4. **Retry Logic**: Automatic retry for transient failures
5. **Error Boundaries**: Catch errors at page level

## Security Considerations

### Authentication Security

1. **Password Storage**:
   - bcrypt hashing with cost factor 12
   - Never store plain text passwords
   - Salt automatically handled by bcrypt

2. **Session Security**:
   - Session tokens stored in Streamlit session_state
   - Session timeout: 24 hours (configurable)
   - Secure session invalidation on logout

3. **Brute Force Protection**:
   - Rate limiting: 5 attempts per 15 minutes
   - Account lockout with automatic unlock
   - Email notification on lockout

4. **Password Reset Security**:
   - Cryptographically secure tokens (UUID4)
   - Token expiration: 1 hour
   - Single-use tokens
   - No user enumeration (same message for valid/invalid emails)

### Database Security

1. **Connection Security**:
   - SSL/TLS for database connections
   - Connection string in environment variables
   - No hardcoded credentials

2. **SQL Injection Prevention**:
   - SQLAlchemy ORM (parameterized queries)
   - Input validation and sanitization

3. **Data Protection**:
   - Encrypted connections
   - Regular backups
   - Audit logging for sensitive operations

### API Security

1. **Environment Variables**:
   - All secrets in .env file
   - Never commit .env to version control
   - Separate configs for dev/prod

2. **Input Validation**:
   - Email format validation
   - Password strength requirements
   - SQL injection prevention
   - XSS prevention (Streamlit handles this)

## Testing Strategy

### Unit Tests

**Test Coverage Areas**:
1. **AuthService Tests** (`tests/test_auth_service.py`):
   - Password hashing and verification
   - User registration validation
   - Login attempt tracking
   - Account locking logic
   - Token generation and validation

2. **UserService Tests** (`tests/test_user_service.py`):
   - User CRUD operations
   - Role management
   - User queries and filters

3. **SessionService Tests** (`tests/test_session_service.py`):
   - Session creation and retrieval
   - Message storage and retrieval
   - Session context building
   - Session deletion

4. **DatabaseManager Tests** (`tests/test_database_manager.py`):
   - Connection management
   - Transaction handling
   - Error recovery

### Integration Tests

1. **Authentication Flow** (`tests/test_auth_flow.py`):
   - Complete registration process
   - Login and logout flow
   - Password reset flow
   - Session persistence

2. **Chat Session Flow** (`tests/test_chat_flow.py`):
   - Create session and add messages
   - Switch between sessions
   - Load session history
   - Delete sessions

3. **Admin Operations** (`tests/test_admin_operations.py`):
   - User management operations
   - Role changes
   - User deletion cascade

### Test Database

- Use separate test database
- Fixtures for test data
- Automatic cleanup after tests
- Mock external services (email, LLM)

## Configuration Management

### Environment Variables

```bash
# Database Configuration
DATABASE_URL=postgresql://user:password@localhost:5432/rag_chatbot
DATABASE_POOL_SIZE=5
DATABASE_MAX_OVERFLOW=10

# Session Configuration
SESSION_TIMEOUT_HOURS=24
SESSION_REMEMBER_ME_DAYS=7

# Security Configuration
PASSWORD_MIN_LENGTH=8
MAX_LOGIN_ATTEMPTS=5
ACCOUNT_LOCKOUT_MINUTES=15
RESET_TOKEN_EXPIRY_HOURS=1

# Email Configuration
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_FROM_EMAIL=noreply@ragchatbot.com
SMTP_FROM_NAME=RAG Chatbot

# Application Configuration
APP_URL=http://localhost:8501
ADMIN_EMAIL=admin@example.com

# Existing LLM Configuration
LLM_PROVIDER=openai
OPENAI_API_KEY=your-key
GEMINI_API_KEY=your-key
```

### Settings Class Updates

```python
class Settings:
    # Existing settings...
    
    # Database settings
    DATABASE_URL: str = os.getenv("DATABASE_URL")
    DATABASE_POOL_SIZE: int = int(os.getenv("DATABASE_POOL_SIZE", "5"))
    
    # Session settings
    SESSION_TIMEOUT_HOURS: int = int(os.getenv("SESSION_TIMEOUT_HOURS", "24"))
    
    # Security settings
    PASSWORD_MIN_LENGTH: int = int(os.getenv("PASSWORD_MIN_LENGTH", "8"))
    MAX_LOGIN_ATTEMPTS: int = int(os.getenv("MAX_LOGIN_ATTEMPTS", "5"))
    
    # Email settings
    SMTP_HOST: str = os.getenv("SMTP_HOST", "")
    SMTP_PORT: int = int(os.getenv("SMTP_PORT", "587"))
    SMTP_USER: str = os.getenv("SMTP_USER", "")
    SMTP_PASSWORD: str = os.getenv("SMTP_PASSWORD", "")
```

## Deployment Considerations

### Database Setup

1. **Initial Setup**:
   ```bash
   # Create database
   createdb rag_chatbot
   
   # Run migrations
   python scripts/init_database.py
   ```

2. **Create Admin User**:
   ```bash
   python scripts/create_admin.py --email admin@example.com --password SecurePass123
   ```

### Migration Strategy

1. **Database Migrations**:
   - Use Alembic for schema migrations
   - Version control migration scripts
   - Test migrations on staging first

2. **Data Migration**:
   - Existing chat history (if any) needs migration
   - Create default sessions for existing users

### Performance Optimization

1. **Database Indexing**:
   - Indexes on frequently queried columns
   - Composite indexes for complex queries

2. **Connection Pooling**:
   - Reuse database connections
   - Configure pool size based on load

3. **Caching**:
   - Cache user data in session_state
   - Cache session list for quick access
   - Invalidate cache on updates

4. **Query Optimization**:
   - Use pagination for large result sets
   - Lazy loading for related data
   - Optimize N+1 query problems

## Future Enhancements

1. **OAuth Integration**: Google, GitHub login
2. **Two-Factor Authentication**: TOTP-based 2FA
3. **User Preferences**: Theme, language, notification settings
4. **Advanced Analytics**: User behavior tracking, A/B testing
5. **Document Permissions**: User-specific document access
6. **Team Workspaces**: Multi-tenant support
7. **API Access**: REST API for programmatic access
8. **Mobile App**: React Native mobile client
9. **Real-time Collaboration**: Multiple users in same session
10. **Advanced Admin Tools**: Bulk operations, audit logs

## Conclusion

This design provides a comprehensive, secure, and scalable authentication and session management system for the RAG chatbot application. The architecture follows best practices for security, maintainability, and user experience while integrating seamlessly with the existing Streamlit-based application.
