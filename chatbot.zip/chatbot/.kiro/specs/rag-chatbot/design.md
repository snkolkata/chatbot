# Design Document: RAG-Based Chatbot with Streamlit

## Overview

This system implements a Retrieval-Augmented Generation (RAG) chatbot using Streamlit for the user interface, LangChain for RAG orchestration, and a vector database for document storage and retrieval. The application consists of two main interfaces: a chatbot page for end users and an admin page for document management.

The architecture follows a modular design with clear separation between the presentation layer (Streamlit UI), business logic layer (RAG processing), and data layer (vector store and document storage).

## Architecture

### High-Level Architecture

```mermaid
graph TB
    subgraph "Presentation Layer"
        A[Chatbot Page]
        B[Admin Page]
    end
    
    subgraph "Business Logic Layer"
        C[RAG Service]
        D[Document Processor]
        E[Query Engine]
    end
    
    subgraph "Data Layer"
        F[Vector Store - ChromaDB]
        G[File Storage]
        H[Metadata Store]
    end
    
    subgraph "External Services"
        I[OpenAI API / LLM]
        J[Embedding Model]
    end
    
    A --> C
    A --> E
    B --> D
    B --> H
    C --> E
    C --> I
    D --> J
    D --> F
    D --> G
    E --> F
    E --> I
```

### Technology Stack

- **Frontend**: Streamlit (multi-page app)
- **RAG Framework**: LangChain
- **Vector Database**: ChromaDB (local, persistent)
- **LLM**: OpenAI GPT (configurable model)
- **Embeddings**: OpenAI text-embedding-ada-002 or sentence-transformers
- **Document Processing**: LangChain document loaders (PyPDF, python-docx, text)
- **Storage**: Local file system for documents, ChromaDB for vectors

## Components and Interfaces

### 1. Streamlit Application Structure

```
app/
├── Home.py                    # Main chatbot interface
├── pages/
│   └── Admin.py              # Admin document management page
├── services/
│   ├── rag_service.py        # RAG orchestration
│   ├── document_service.py   # Document processing
│   └── vector_store.py       # Vector store management
├── config/
│   └── settings.py           # Configuration management
└── utils/
    └── helpers.py            # Utility functions
```

### 2. RAG Service

**Purpose**: Orchestrates the retrieval and generation process

**Key Methods**:
- `query(user_message: str) -> str`: Process user query and return response
- `get_relevant_chunks(query: str, k: int = 3) -> List[Document]`: Retrieve relevant document chunks
- `generate_response(query: str, context: List[Document]) -> str`: Generate response using LLM

**Interface**:
```python
class RAGService:
    def __init__(self, vector_store: VectorStore, llm_client):
        self.vector_store = vector_store
        self.llm_client = llm_client
        self.retriever = None
        
    def query(self, user_message: str) -> str:
        """Process user query and return AI response"""
        pass
        
    def get_relevant_chunks(self, query: str, k: int = 3) -> List[Document]:
        """Retrieve top k relevant document chunks"""
        pass
```

### 3. Document Service

**Purpose**: Handles document upload, processing, and management

**Key Methods**:
- `upload_document(file, filename: str) -> bool`: Upload and process document
- `delete_document(doc_id: str) -> bool`: Remove document and embeddings
- `list_documents() -> List[Dict]`: Get all uploaded documents
- `process_document(file_path: str) -> List[Document]`: Split and chunk document

**Interface**:
```python
class DocumentService:
    def __init__(self, vector_store: VectorStore, storage_path: str):
        self.vector_store = vector_store
        self.storage_path = storage_path
        
    def upload_document(self, file, filename: str) -> Dict:
        """Upload and process document into vector store"""
        pass
        
    def delete_document(self, doc_id: str) -> bool:
        """Delete document and its embeddings"""
        pass
        
    def list_documents(self) -> List[Dict]:
        """List all uploaded documents with metadata"""
        pass
```

### 4. Vector Store Manager

**Purpose**: Manages ChromaDB vector store operations

**Key Methods**:
- `initialize() -> None`: Initialize or load existing vector store
- `add_documents(documents: List[Document]) -> List[str]`: Add document chunks
- `delete_by_source(source: str) -> None`: Remove all chunks from a document
- `similarity_search(query: str, k: int) -> List[Document]`: Search for similar chunks

**Interface**:
```python
class VectorStoreManager:
    def __init__(self, persist_directory: str, embedding_function):
        self.persist_directory = persist_directory
        self.embedding_function = embedding_function
        self.client = None
        self.collection = None
        
    def initialize(self) -> None:
        """Initialize ChromaDB client and collection"""
        pass
        
    def add_documents(self, documents: List[Document], metadata: Dict) -> List[str]:
        """Add documents to vector store"""
        pass
```

## Data Models

### Document Metadata

```python
{
    "doc_id": "unique_document_id",
    "filename": "document.pdf",
    "upload_timestamp": "2025-11-19T10:30:00",
    "file_size": 1024000,
    "file_type": "pdf",
    "chunk_count": 15,
    "file_path": "/data/documents/document.pdf"
}
```

### Conversation Message

```python
{
    "role": "user" | "assistant",
    "content": "message text",
    "timestamp": "2025-11-19T10:30:00"
}
```

### Vector Store Document

```python
{
    "page_content": "chunk text content",
    "metadata": {
        "source": "document.pdf",
        "doc_id": "unique_document_id",
        "chunk_index": 0,
        "page": 1
    }
}
```

## User Interface Design

### Chatbot Page (Home.py)

**Layout**:
- Title: "RAG Chatbot"
- Sidebar: 
  - System status indicator
  - Document count display
  - Clear conversation button
- Main area:
  - Chat message container (scrollable)
  - User input text area at bottom
  - Send button

**Session State**:
- `messages`: List of conversation messages
- `rag_service`: Initialized RAG service instance

### Admin Page (pages/Admin.py)

**Layout**:
- Title: "Document Management"
- Upload section:
  - File uploader widget (accepts .pdf, .txt, .docx)
  - Upload button
  - Status messages
- Document list section:
  - Table/list of uploaded documents
  - Columns: Filename, Upload Date, Size, Actions
  - Delete button for each document
- Statistics section:
  - Total documents count
  - Total chunks count

## Error Handling

### Error Categories and Handling Strategy

1. **File Upload Errors**
   - Invalid file format: Display user-friendly message with supported formats
   - File too large: Display size limit message
   - Processing failure: Log error, display generic message to user

2. **Vector Store Errors**
   - Connection failure: Retry once, then display error message
   - Embedding generation failure: Log error, notify user to try again

3. **LLM API Errors**
   - Rate limit: Display message asking user to wait
   - API key invalid: Display configuration error message
   - Timeout: Retry once with exponential backoff

4. **Query Processing Errors**
   - Empty query: Validate before processing
   - No relevant documents: Return helpful message indicating no information found
   - Generation failure: Display error and suggest rephrasing

### Error Logging

- Use Python logging module
- Log level: INFO for operations, ERROR for failures
- Log format: `[timestamp] [level] [component] message`
- Log file: `logs/app.log`

## Testing Strategy

### Unit Tests

- Test document processing functions (chunking, metadata extraction)
- Test vector store operations (add, delete, search)
- Test RAG service query processing logic
- Mock external API calls (OpenAI)

### Integration Tests

- Test end-to-end document upload flow
- Test end-to-end query and response flow
- Test document deletion and vector store cleanup

### UI Tests

- Manual testing of Streamlit interfaces
- Test file upload with various formats
- Test chat interaction flows
- Test error message displays

### Test Data

- Sample PDF, TXT, and DOCX files
- Sample queries with expected relevant chunks
- Edge cases: empty files, large files, special characters

## Configuration Management

### Environment Variables

```
OPENAI_API_KEY=your_api_key_here
EMBEDDING_MODEL=text-embedding-ada-002
LLM_MODEL=gpt-3.5-turbo
CHUNK_SIZE=1000
CHUNK_OVERLAP=200
VECTOR_STORE_PATH=./data/chroma_db
DOCUMENT_STORAGE_PATH=./data/documents
MAX_FILE_SIZE_MB=10
```

### Configuration File (config/settings.py)

```python
class Settings:
    OPENAI_API_KEY: str
    EMBEDDING_MODEL: str = "text-embedding-ada-002"
    LLM_MODEL: str = "gpt-3.5-turbo"
    CHUNK_SIZE: int = 1000
    CHUNK_OVERLAP: int = 200
    VECTOR_STORE_PATH: str = "./data/chroma_db"
    DOCUMENT_STORAGE_PATH: str = "./data/documents"
    MAX_FILE_SIZE_MB: int = 10
    SUPPORTED_FILE_TYPES: List[str] = [".pdf", ".txt", ".docx"]
```

## Security Considerations

1. **API Key Management**: Store OpenAI API key in environment variables, never in code
2. **File Upload Validation**: Validate file types and sizes before processing
3. **Input Sanitization**: Sanitize user queries to prevent injection attacks
4. **Access Control**: Consider adding authentication for admin page in future iterations

## Performance Considerations

1. **Chunking Strategy**: Use 1000 character chunks with 200 character overlap for optimal retrieval
2. **Caching**: ChromaDB provides built-in persistence and caching
3. **Async Operations**: Consider async document processing for large files
4. **Rate Limiting**: Implement basic rate limiting for API calls to avoid quota exhaustion

## Deployment Notes

1. **Local Development**: Run with `streamlit run Home.py`
2. **Dependencies**: Install via `requirements.txt`
3. **Data Persistence**: Ensure `data/` directory has write permissions
4. **Environment Setup**: Copy `.env.example` to `.env` and configure API keys
