"""
SQLAlchemy ORM models for the RAG chatbot application.
"""
from datetime import datetime
from typing import List
import uuid

from sqlalchemy import (
    Column, String, Boolean, Integer, DateTime, Text, 
    ForeignKey, CheckConstraint, Index, UUID, JSON
)
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import JSONB

from services.database_manager import Base
from config.settings import settings


def generate_uuid():
    """Generate a new UUID for primary keys."""
    return str(uuid.uuid4())


# Use JSONB for PostgreSQL, JSON for SQLite
JSONType = JSONB if 'postgresql' in settings.DATABASE_URL else JSON


class User(Base):
    """User model for authentication and authorization."""
    
    __tablename__ = "users"
    
    # Primary key
    user_id = Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    
    # User credentials and info
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    
    # Role and status
    role = Column(String(20), nullable=False, default="user", index=True)
    is_active = Column(Boolean, default=True, nullable=False)
    
    # Security tracking
    failed_login_attempts = Column(Integer, default=0, nullable=False)
    account_locked_until = Column(DateTime, nullable=True)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    last_login = Column(DateTime, nullable=True)
    
    # Relationships
    chat_sessions = relationship("ChatSession", back_populates="user", cascade="all, delete-orphan")
    password_reset_tokens = relationship("PasswordResetToken", back_populates="user", cascade="all, delete-orphan")
    
    # Constraints
    __table_args__ = (
        CheckConstraint("role IN ('user', 'admin')", name="valid_role"),
        Index("idx_users_email", "email"),
        Index("idx_users_role", "role"),
    )
    
    def __repr__(self):
        return f"<User(user_id={self.user_id}, email={self.email}, role={self.role})>"


class ChatSession(Base):
    """Chat session model for storing conversation contexts."""
    
    __tablename__ = "chat_sessions"
    
    # Primary key
    session_id = Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    
    # Foreign key to user
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.user_id", ondelete="CASCADE"), nullable=False)
    
    # Session info
    title = Column(String(255), default="New Chat", nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="chat_sessions")
    messages = relationship("ChatMessage", back_populates="session", cascade="all, delete-orphan")
    
    # Indexes
    __table_args__ = (
        Index("idx_chat_sessions_user_id", "user_id"),
        Index("idx_chat_sessions_updated_at", "updated_at"),
    )
    
    def __repr__(self):
        return f"<ChatSession(session_id={self.session_id}, user_id={self.user_id}, title={self.title})>"


class ChatMessage(Base):
    """Chat message model for storing individual messages in sessions."""
    
    __tablename__ = "chat_messages"
    
    # Primary key
    message_id = Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    
    # Foreign key to session
    session_id = Column(UUID(as_uuid=False), ForeignKey("chat_sessions.session_id", ondelete="CASCADE"), nullable=False)
    
    # Message content
    role = Column(String(20), nullable=False)  # 'user' or 'assistant'
    content = Column(Text, nullable=False)
    sources = Column(JSONType, nullable=True)  # Store source documents as JSON
    
    # Timestamp
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Relationships
    session = relationship("ChatSession", back_populates="messages")
    
    # Constraints and indexes
    __table_args__ = (
        CheckConstraint("role IN ('user', 'assistant')", name="valid_message_role"),
        Index("idx_chat_messages_session_id", "session_id"),
        Index("idx_chat_messages_created_at", "created_at"),
    )
    
    def __repr__(self):
        return f"<ChatMessage(message_id={self.message_id}, session_id={self.session_id}, role={self.role})>"


class PasswordResetToken(Base):
    """Password reset token model for secure password recovery."""
    
    __tablename__ = "password_reset_tokens"
    
    # Primary key
    token_id = Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    
    # Foreign key to user
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.user_id", ondelete="CASCADE"), nullable=False)
    
    # Token info
    token = Column(String(255), unique=True, nullable=False, index=True)
    expires_at = Column(DateTime, nullable=False)
    used = Column(Boolean, default=False, nullable=False)
    
    # Timestamp
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="password_reset_tokens")
    
    # Indexes
    __table_args__ = (
        Index("idx_password_reset_tokens_token", "token"),
        Index("idx_password_reset_tokens_user_id", "user_id"),
    )
    
    def __repr__(self):
        return f"<PasswordResetToken(token_id={self.token_id}, user_id={self.user_id}, used={self.used})>"
