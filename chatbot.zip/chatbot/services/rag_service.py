"""
RAG Service for orchestrating retrieval and generation operations.

This module provides the RAGService class that handles the complete RAG workflow:
retrieving relevant document chunks and generating responses using an LLM.
"""

import os
import logging
from typing import List, Dict, Optional

# Set GOOGLE_API_KEY environment variable early, before importing Google libraries
from config.settings import settings
if settings.GEMINI_API_KEY and not os.getenv("GOOGLE_API_KEY"):
    os.environ["GOOGLE_API_KEY"] = settings.GEMINI_API_KEY

from langchain_core.documents import Document
from langchain_openai import ChatOpenAI
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.messages import HumanMessage, SystemMessage
from services.vector_store import VectorStoreManager
from utils.helpers import (
    ValidationError,
    LLMError,
    VectorStoreError,
    log_exception,
    validate_not_empty,
    retry_on_failure
)

logger = logging.getLogger(__name__)


class RAGService:
    """
    Service for Retrieval-Augmented Generation operations.
    
    This class orchestrates the RAG workflow by retrieving relevant document chunks
    from the vector store and generating contextually accurate responses using an LLM.
    """
    
    # System prompt template that instructs the LLM to use retrieved context
    SYSTEM_PROMPT = """You are a helpful AI assistant that answers questions based on the provided context from documents.

Instructions:
- Use ONLY the information from the context provided below to answer questions
- If the context doesn't contain enough information to answer the question, clearly state that you don't have that information in the available documents
- Be concise and accurate in your responses
- Cite specific parts of the context when relevant
- Do not make up information or use knowledge outside of the provided context

Context from documents:
{context}"""

    SYSTEM_PROMPT_WITH_HISTORY = """You are a helpful AI assistant that answers questions based on the provided context from documents.

Instructions:
- Use ONLY the information from the context provided below to answer questions
- Consider the conversation history to provide contextually relevant responses
- If the context doesn't contain enough information to answer the question, clearly state that you don't have that information in the available documents
- Be concise and accurate in your responses
- Cite specific parts of the context when relevant
- Do not make up information or use knowledge outside of the provided context

Conversation History:
{chat_history}

Context from documents:
{context}"""

    USER_PROMPT = """Based on the context provided above, please answer the following question:

{query}"""
    
    def __init__(self, vector_store: VectorStoreManager, llm_model: str = None):
        """
        Initialize the RAGService.
        
        Args:
            vector_store: VectorStoreManager instance for document retrieval
            llm_model: Optional LLM model name (defaults to settings)
        """
        self.vector_store = vector_store
        self.llm_model = llm_model or settings.LLM_MODEL
        self.llm_provider = settings.LLM_PROVIDER
        
        # Initialize LLM client based on provider
        # GOOGLE_API_KEY is already set at module level for Gemini
        if self.llm_provider == "gemini":
            self.llm_client = ChatGoogleGenerativeAI(
                model=self.llm_model,
                temperature=0.7
            )
            logger.info(f"RAG Service initialized with Gemini model: {self.llm_model}")
        else:
            self.llm_client = ChatOpenAI(
                model=self.llm_model,
                temperature=0.7,
                openai_api_key=settings.OPENAI_API_KEY
            )
            logger.info(f"RAG Service initialized with OpenAI model: {self.llm_model}")

    @log_exception
    @retry_on_failure(max_attempts=2, delay_seconds=1.0)
    def get_relevant_chunks(self, query: str, k: int = 3) -> List[Document]:
        """
        Retrieve top k relevant document chunks for a query.
        
        This method uses the vector store's similarity search to find the most
        relevant document chunks based on semantic similarity to the query.
        
        Args:
            query: User's question or search query
            k: Number of top relevant chunks to retrieve (default: 3)
            
        Returns:
            List of Document objects containing relevant text chunks
            
        Raises:
            VectorStoreError: If retrieval fails
        """
        try:
            logger.info(f"Retrieving top {k} relevant chunks for query")
            
            # Perform similarity search using vector store
            relevant_chunks = self.vector_store.similarity_search(query, k=k)
            
            logger.info(f"Retrieved {len(relevant_chunks)} relevant chunks")
            return relevant_chunks
            
        except Exception as e:
            logger.error(f"Failed to retrieve relevant chunks: {str(e)}", exc_info=True)
            raise VectorStoreError(f"Failed to retrieve relevant documents: {str(e)}") from e
    
    @log_exception
    @retry_on_failure(max_attempts=2, delay_seconds=1.0)
    def generate_response(self, query: str, context_chunks: List[Document], chat_history: Optional[List[Dict]] = None) -> str:
        """
        Generate a response using the LLM with retrieved context.
        
        This method constructs a prompt with the retrieved context and user query,
        then uses the LLM to generate a contextually grounded response.
        
        Args:
            query: User's question
            context_chunks: List of relevant document chunks to use as context
            chat_history: Optional list of previous messages for conversation context
            
        Returns:
            Generated response string from the LLM
            
        Raises:
            LLMError: If response generation fails
        """
        try:
            # Format context from chunks
            if context_chunks:
                context_text = "\n\n".join([
                    f"[Document: {chunk.metadata.get('source', 'Unknown')}]\n{chunk.page_content}"
                    for chunk in context_chunks
                ])
            else:
                context_text = "No relevant documents found."
            
            logger.info(f"Generating response with {len(context_chunks)} context chunks")
            
            # Create messages for the chat model
            if chat_history and len(chat_history) > 0:
                # Format chat history
                history_text = "\n".join([
                    f"{msg['role'].capitalize()}: {msg['content']}"
                    for msg in chat_history
                ])
                system_message = SystemMessage(content=self.SYSTEM_PROMPT_WITH_HISTORY.format(
                    chat_history=history_text,
                    context=context_text
                ))
                logger.info(f"Using conversation history with {len(chat_history)} messages")
            else:
                system_message = SystemMessage(content=self.SYSTEM_PROMPT.format(context=context_text))
            
            user_message = HumanMessage(content=self.USER_PROMPT.format(query=query))
            
            # Generate response using LLM
            try:
                response = self.llm_client.invoke([system_message, user_message])
            except Exception as e:
                error_msg = str(e).lower()
                if "rate limit" in error_msg:
                    raise LLMError("Rate limit exceeded. Please wait a moment and try again.") from e
                elif "api key" in error_msg or "authentication" in error_msg:
                    raise LLMError("API authentication failed. Please check your API key configuration.") from e
                elif "timeout" in error_msg:
                    raise LLMError("Request timed out. Please try again.") from e
                else:
                    raise LLMError(f"LLM API error: {str(e)}") from e
            
            if not response or not response.content:
                raise LLMError("LLM returned empty response")
            
            logger.info("Successfully generated response")
            return response.content
            
        except LLMError:
            raise
        except Exception as e:
            logger.error(f"Unexpected error generating response: {str(e)}", exc_info=True)
            raise LLMError(f"Failed to generate response: {str(e)}") from e
    
    @log_exception
    def query(self, user_message: str, k: int = 3, chat_history: Optional[List[Dict]] = None) -> Dict[str, any]:
        """
        Process a user query through the complete RAG pipeline.
        
        This method orchestrates the full RAG workflow:
        1. Validates and sanitizes input
        2. Retrieves relevant document chunks
        3. Handles cases with no relevant documents
        4. Generates a response using the LLM with context and chat history
        
        Args:
            user_message: User's question or query
            k: Number of relevant chunks to retrieve (default: 3)
            chat_history: Optional list of previous messages for conversation context (max 10 messages)
            
        Returns:
            Dictionary containing:
                - response: Generated answer string
                - sources: List of source documents used
                - chunk_count: Number of chunks retrieved
                
        Raises:
            ValidationError: If query is empty or invalid
            VectorStoreError: If retrieval fails
            LLMError: If response generation fails
        """
        # Validate input
        user_message = validate_not_empty(user_message, "Query")
        
        logger.info(f"Processing query: {user_message[:100]}...")
        
        # Limit chat history to last 10 messages for context window management
        if chat_history and len(chat_history) > 10:
            chat_history = chat_history[-10:]
            logger.info(f"Limited chat history to last 10 messages")
        
        try:
            # Step 1: Retrieve relevant chunks
            relevant_chunks = self.get_relevant_chunks(user_message, k=k)
            
            # Step 2: Handle case when no relevant documents are found
            if not relevant_chunks:
                logger.info("No relevant documents found for query")
                return {
                    "response": "I don't have any relevant information in the available documents to answer your question. Please make sure documents have been uploaded to the system.",
                    "sources": [],
                    "chunk_count": 0
                }
            
            # Step 3: Generate response with context and chat history
            response_text = self.generate_response(user_message, relevant_chunks, chat_history)
            
            # Extract unique sources from chunks
            sources = list(set([
                chunk.metadata.get('source', 'Unknown')
                for chunk in relevant_chunks
            ]))
            
            logger.info(f"Query processed successfully with {len(relevant_chunks)} chunks from {len(sources)} sources")
            
            return {
                "response": response_text,
                "sources": sources,
                "chunk_count": len(relevant_chunks)
            }
            
        except (ValidationError, VectorStoreError, LLMError):
            raise
        except Exception as e:
            logger.error(f"Unexpected error processing query: {str(e)}", exc_info=True)
            raise
