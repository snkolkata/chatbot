
"""
Database Manager for PostgreSQL connection and session management.
"""
import logging
from contextlib import contextmanager
from typing import Generator, Optional

from sqlalchemy import create_engine, text, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import sessionmaker, Session, declarative_base
from sqlalchemy.pool import QueuePool, StaticPool
from sqlalchemy.exc import SQLAlchemyError, OperationalError

from config.settings import settings

# Configure logging
logger = logging.getLogger(__name__)

# Create declarative base for ORM models
Base = declarative_base()


class DatabaseManager:
    """
    Manages PostgreSQL database connections with connection pooling.
    Provides session management and database initialization functionality.
    """
    
    _engine: Optional[Engine] = None
    _session_factory: Optional[sessionmaker] = None
    
    @classmethod
    def initialize(cls) -> None:
        """
        Initialize the database engine and session factory with connection pooling.
        Should be called once at application startup.
        """
        if cls._engine is not None:
            logger.warning("Database engine already initialized")
            return
        
        try:
            # Create engine with appropriate settings based on database URL
            db_url = settings.DATABASE_URL

            if db_url.startswith("sqlite"):
                # SQLite configuration
                # For in-memory DB, use StaticPool to share the same connection
                is_memory = db_url.endswith(":memory:") or db_url in (
                    "sqlite://",
                    "sqlite:///:memory:",
                )
                if is_memory:
                    cls._engine = create_engine(
                        db_url,
                        connect_args={"check_same_thread": False},
                        poolclass=StaticPool,
                        echo=False,
                    )
                else:
                    cls._engine = create_engine(
                        db_url,
                        connect_args={"check_same_thread": False},
                        echo=False,
                    )
            else:
                # Default: PostgreSQL (or other external DB) with QueuePool
                cls._engine = create_engine(
                    db_url,
                    poolclass=QueuePool,
                    pool_size=settings.DATABASE_POOL_SIZE,
                    max_overflow=settings.DATABASE_MAX_OVERFLOW,
                    pool_timeout=settings.DATABASE_POOL_TIMEOUT,
                    pool_recycle=settings.DATABASE_POOL_RECYCLE,
                    pool_pre_ping=True,  # Enable connection health checks
                    echo=False,  # Set to True for SQL query logging
                )
            
            # Add event listener for connection checkout (only for real engines)
            try:
                @event.listens_for(cls._engine, "connect")
                def receive_connect(dbapi_conn, connection_record):
                    logger.debug("Database connection established")
            except Exception:
                # Skip event listener for mocked engines in tests
                pass
            
            # Create session factory
            cls._session_factory = sessionmaker(
                bind=cls._engine,
                autocommit=False,
                autoflush=False,
                expire_on_commit=False
            )
            
            logger.info("Database engine initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize database engine: {e}")
            raise
    
    @classmethod
    def get_engine(cls) -> Engine:
        """
        Get the database engine instance.
        
        Returns:
            Engine: SQLAlchemy engine instance
            
        Raises:
            RuntimeError: If engine is not initialized
        """
        if cls._engine is None:
            raise RuntimeError("Database engine not initialized. Call initialize() first.")
        return cls._engine
    
    @classmethod
    @contextmanager
    def get_session(cls) -> Generator[Session, None, None]:
        """
        Context manager for database sessions.
        Automatically handles commit/rollback and session cleanup.
        
        Usage:
            with DatabaseManager.get_session() as session:
                user = session.query(User).first()
        
        Yields:
            Session: SQLAlchemy session instance
        """
        if cls._session_factory is None:
            raise RuntimeError("Database not initialized. Call initialize() first.")
        
        session = cls._session_factory()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"Database session error: {e}")
            raise
        finally:
            session.close()
    
    @classmethod
    def create_tables(cls) -> None:
        """
        Create all database tables defined in the ORM models.
        This should be called after all models are imported.
        """
        if cls._engine is None:
            raise RuntimeError("Database engine not initialized. Call initialize() first.")
        
        try:
            Base.metadata.create_all(bind=cls._engine)
            logger.info("Database tables created successfully")
        except Exception as e:
            logger.error(f"Failed to create database tables: {e}")
            raise
    
    @classmethod
    def drop_tables(cls) -> None:
        """
        Drop all database tables. Use with caution!
        Primarily for testing and development.
        """
        if cls._engine is None:
            raise RuntimeError("Database engine not initialized. Call initialize() first.")
        
        try:
            Base.metadata.drop_all(bind=cls._engine)
            logger.info("Database tables dropped successfully")
        except Exception as e:
            logger.error(f"Failed to drop database tables: {e}")
            raise
    
    @classmethod
    def health_check(cls) -> bool:
        """
        Perform a health check on the database connection.
        
        Returns:
            bool: True if database is accessible, False otherwise
        """
        if cls._engine is None:
            logger.error("Database engine not initialized")
            return False
        
        try:
            with cls._engine.connect() as connection:
                # Execute a simple query to test connection
                result = connection.execute(text("SELECT 1"))
                result.fetchone()
                logger.info("Database health check passed")
                return True
        except OperationalError as e:
            logger.error(f"Database health check failed - connection error: {e}")
            return False
        except SQLAlchemyError as e:
            logger.error(f"Database health check failed - SQL error: {e}")
            return False
        except Exception as e:
            logger.error(f"Database health check failed - unexpected error: {e}")
            return False
    
    @classmethod
    def get_connection_info(cls) -> dict:
        """
        Get information about the current database connection pool.
        
        Returns:
            dict: Connection pool statistics
        """
        if cls._engine is None:
            return {"status": "not_initialized"}
        
        pool = cls._engine.pool
        return {
            "status": "initialized",
            "pool_size": pool.size(),
            "checked_in_connections": pool.checkedin(),
            "checked_out_connections": pool.checkedout(),
            "overflow_connections": pool.overflow(),
            "total_connections": pool.size() + pool.overflow(),
        }
    
    @classmethod
    def close(cls) -> None:
        """
        Close all database connections and dispose of the engine.
        Should be called at application shutdown.
        """
        if cls._engine is not None:
            cls._engine.dispose()
            cls._engine = None
            cls._session_factory = None
            logger.info("Database connections closed")
