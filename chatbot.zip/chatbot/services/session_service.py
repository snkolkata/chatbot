"""
Session Service for chat session and message management.
Handles session CRUD operations, message storage, and context retrieval.
"""
import logging
from datetime import datetime, timedelta
from typing import Optional, List, Dict
from uuid import UUID

from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session
from sqlalchemy import func, desc

from services.database_manager import DatabaseManager
from services.models import ChatSession, ChatMessage, User

# Configure logging
logger = logging.getLogger(__name__)


class SessionService:
    """
    Service for handling chat session and message operations including:
    - Session CRUD operations
    - Message storage and retrieval
    - Session context management for RAG
    """
    
    @staticmethod
    def create_session(user_id: str, title: str = "New Chat") -> Optional[str]:
        """
        Create a new chat session for a user.
        
        Args:
            user_id: User's unique identifier
            title: Session title (default: "New Chat")
            
        Returns:
            Optional[str]: Session ID if successful, None otherwise
        """
        try:
            with DatabaseManager.get_session() as session:
                # Verify user exists
                user = session.query(User).filter(User.user_id == user_id).first()
                if not user:
                    logger.warning(f"Cannot create session - user not found: {user_id}")
                    return None
                
                # Create new session
                new_session = ChatSession(
                    user_id=user_id,
                    title=title,
                    is_active=True
                )
                
                session.add(new_session)
                session.commit()
                
                logger.info(f"Created new session {new_session.session_id} for user {user.email}")
                return new_session.session_id
                
        except SQLAlchemyError as e:
            logger.error(f"Database error creating session: {e}")
            raise Exception("Failed to create session")
        except Exception as e:
            logger.error(f"Unexpected error creating session: {e}")
            raise Exception("An unexpected error occurred")

    @staticmethod
    def get_user_sessions(user_id: str) -> List[Dict]:
        """
        Retrieve all chat sessions for a user, sorted by most recently updated.
        
        Args:
            user_id: User's unique identifier
            
        Returns:
            List[Dict]: List of session dictionaries sorted by updated_at (descending)
        """
        try:
            with DatabaseManager.get_session() as session:
                # Query sessions with message count
                sessions = session.query(
                    ChatSession,
                    func.count(ChatMessage.message_id).label("message_count")
                ).outerjoin(
                    ChatMessage, ChatSession.session_id == ChatMessage.session_id
                ).filter(
                    ChatSession.user_id == user_id
                ).group_by(
                    ChatSession.session_id
                ).order_by(
                    desc(ChatSession.updated_at)
                ).all()
                
                # Convert to dictionaries
                session_list = [
                    {
                        "session_id": chat_session.session_id,
                        "user_id": chat_session.user_id,
                        "title": chat_session.title,
                        "is_active": chat_session.is_active,
                        "created_at": chat_session.created_at,
                        "updated_at": chat_session.updated_at,
                        "message_count": message_count
                    }
                    for chat_session, message_count in sessions
                ]
                
                logger.info(f"Retrieved {len(session_list)} sessions for user {user_id}")
                return session_list
                
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving user sessions: {e}")
            raise Exception("Failed to retrieve sessions")
        except Exception as e:
            logger.error(f"Unexpected error retrieving user sessions: {e}")
            raise Exception("An unexpected error occurred")
    
    @staticmethod
    def get_active_session(user_id: str) -> Optional[Dict]:
        """
        Get the most recently updated session for a user.
        
        Args:
            user_id: User's unique identifier
            
        Returns:
            Optional[Dict]: Most recent session dictionary or None if no sessions exist
        """
        try:
            with DatabaseManager.get_session() as session:
                # Get most recently updated session
                chat_session = session.query(ChatSession).filter(
                    ChatSession.user_id == user_id
                ).order_by(
                    desc(ChatSession.updated_at)
                ).first()
                
                if not chat_session:
                    logger.info(f"No active session found for user {user_id}")
                    return None
                
                # Get message count
                message_count = session.query(func.count(ChatMessage.message_id)).filter(
                    ChatMessage.session_id == chat_session.session_id
                ).scalar()
                
                result = {
                    "session_id": chat_session.session_id,
                    "user_id": chat_session.user_id,
                    "title": chat_session.title,
                    "is_active": chat_session.is_active,
                    "created_at": chat_session.created_at,
                    "updated_at": chat_session.updated_at,
                    "message_count": message_count or 0
                }
                
                logger.info(f"Retrieved active session {chat_session.session_id} for user {user_id}")
                return result
                
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving active session: {e}")
            raise Exception("Failed to retrieve active session")
        except Exception as e:
            logger.error(f"Unexpected error retrieving active session: {e}")
            raise Exception("An unexpected error occurred")
    
    @staticmethod
    def set_active_session(user_id: str, session_id: str) -> bool:
        """
        Set a specific session as the active session by updating its timestamp.
        
        Args:
            user_id: User's unique identifier
            session_id: Session's unique identifier
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            with DatabaseManager.get_session() as session:
                # Verify session belongs to user
                chat_session = session.query(ChatSession).filter(
                    ChatSession.session_id == session_id,
                    ChatSession.user_id == user_id
                ).first()
                
                if not chat_session:
                    logger.warning(f"Cannot set active session - session not found or doesn't belong to user: {session_id}")
                    return False
                
                # Update timestamp to make it most recent
                chat_session.updated_at = datetime.utcnow()
                session.commit()
                
                logger.info(f"Set active session {session_id} for user {user_id}")
                return True
                
        except SQLAlchemyError as e:
            logger.error(f"Database error setting active session: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error setting active session: {e}")
            return False
    
    @staticmethod
    def update_session_title(session_id: str, title: str) -> bool:
        """
        Update the title of a chat session.
        
        Args:
            session_id: Session's unique identifier
            title: New title for the session
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            with DatabaseManager.get_session() as session:
                chat_session = session.query(ChatSession).filter(
                    ChatSession.session_id == session_id
                ).first()
                
                if not chat_session:
                    logger.warning(f"Cannot update title - session not found: {session_id}")
                    return False
                
                old_title = chat_session.title
                chat_session.title = title
                chat_session.updated_at = datetime.utcnow()
                session.commit()
                
                logger.info(f"Updated session {session_id} title: '{old_title}' -> '{title}'")
                return True
                
        except SQLAlchemyError as e:
            logger.error(f"Database error updating session title: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error updating session title: {e}")
            return False
    
    @staticmethod
    def delete_session(session_id: str) -> bool:
        """
        Delete a chat session and all associated messages (cascade delete).
        
        Args:
            session_id: Session's unique identifier
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            with DatabaseManager.get_session() as session:
                chat_session = session.query(ChatSession).filter(
                    ChatSession.session_id == session_id
                ).first()
                
                if not chat_session:
                    logger.warning(f"Cannot delete - session not found: {session_id}")
                    return False
                
                # Get message count before deletion for logging
                message_count = session.query(func.count(ChatMessage.message_id)).filter(
                    ChatMessage.session_id == session_id
                ).scalar()
                
                # Delete session (cascade will delete messages)
                session.delete(chat_session)
                session.commit()
                
                logger.info(f"Deleted session {session_id} and {message_count} associated messages")
                return True
                
        except SQLAlchemyError as e:
            logger.error(f"Database error deleting session: {e}")
            raise Exception("Failed to delete session")
        except Exception as e:
            logger.error(f"Unexpected error deleting session: {e}")
            raise Exception("An unexpected error occurred")

    @staticmethod
    def add_message(
        session_id: str,
        role: str,
        content: str,
        sources: Optional[List[Dict]] = None
    ) -> Optional[str]:
        """
        Add a message to a chat session and update the session timestamp.
        
        Args:
            session_id: Session's unique identifier
            role: Message role ('user' or 'assistant')
            content: Message content
            sources: Optional list of source documents (for RAG responses)
            
        Returns:
            Optional[str]: Message ID if successful, None otherwise
            
        Raises:
            ValueError: If role is invalid
        """
        # Validate role
        if role not in ["user", "assistant"]:
            raise ValueError("Invalid role. Must be 'user' or 'assistant'")
        
        try:
            with DatabaseManager.get_session() as session:
                # Verify session exists
                chat_session = session.query(ChatSession).filter(
                    ChatSession.session_id == session_id
                ).first()
                
                if not chat_session:
                    logger.warning(f"Cannot add message - session not found: {session_id}")
                    return None
                
                # Create new message
                new_message = ChatMessage(
                    session_id=session_id,
                    role=role,
                    content=content,
                    sources=sources
                )
                
                # Update session timestamp
                chat_session.updated_at = datetime.utcnow()
                
                session.add(new_message)
                session.commit()
                
                logger.info(f"Added {role} message to session {session_id}")
                return new_message.message_id
                
        except ValueError:
            raise
        except SQLAlchemyError as e:
            logger.error(f"Database error adding message: {e}")
            raise Exception("Failed to add message")
        except Exception as e:
            logger.error(f"Unexpected error adding message: {e}")
            raise Exception("An unexpected error occurred")
    
    @staticmethod
    def get_session_messages(session_id: str) -> List[Dict]:
        """
        Retrieve all messages for a session, ordered by creation time.
        
        Args:
            session_id: Session's unique identifier
            
        Returns:
            List[Dict]: List of message dictionaries ordered by created_at (ascending)
        """
        try:
            with DatabaseManager.get_session() as session:
                # Query messages ordered by creation time
                messages = session.query(ChatMessage).filter(
                    ChatMessage.session_id == session_id
                ).order_by(
                    ChatMessage.created_at
                ).all()
                
                # Convert to dictionaries
                message_list = [
                    {
                        "message_id": message.message_id,
                        "session_id": message.session_id,
                        "role": message.role,
                        "content": message.content,
                        "sources": message.sources,
                        "created_at": message.created_at
                    }
                    for message in messages
                ]
                
                logger.info(f"Retrieved {len(message_list)} messages for session {session_id}")
                return message_list
                
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving session messages: {e}")
            raise Exception("Failed to retrieve messages")
        except Exception as e:
            logger.error(f"Unexpected error retrieving session messages: {e}")
            raise Exception("An unexpected error occurred")
    
    @staticmethod
    def get_session_context(session_id: str, max_messages: int = 10) -> List[Dict]:
        """
        Get recent message context for RAG query processing.
        Returns the most recent messages in chronological order.
        
        Args:
            session_id: Session's unique identifier
            max_messages: Maximum number of recent messages to retrieve (default: 10)
            
        Returns:
            List[Dict]: List of recent messages with role and content, ordered chronologically
        """
        try:
            with DatabaseManager.get_session() as session:
                # Query most recent messages
                messages = session.query(ChatMessage).filter(
                    ChatMessage.session_id == session_id
                ).order_by(
                    desc(ChatMessage.created_at)
                ).limit(max_messages).all()
                
                # Reverse to get chronological order (oldest to newest)
                messages.reverse()
                
                # Convert to simplified format for RAG context
                context_list = [
                    {
                        "role": message.role,
                        "content": message.content
                    }
                    for message in messages
                ]
                
                logger.info(f"Retrieved {len(context_list)} messages for RAG context from session {session_id}")
                return context_list
                
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving session context: {e}")
            raise Exception("Failed to retrieve session context")
        except Exception as e:
            logger.error(f"Unexpected error retrieving session context: {e}")
            raise Exception("An unexpected error occurred")
    
    @staticmethod
    def get_session_analytics(days: int = 30) -> Dict:
        """
        Get session analytics for admin dashboard.
        
        Args:
            days: Number of days to include in analytics (default: 30)
            
        Returns:
            Dict: Dictionary containing session analytics
        """
        try:
            with DatabaseManager.get_session() as session:
                # Calculate date range
                start_date = datetime.utcnow() - timedelta(days=days)
                
                # Total active sessions
                active_sessions = session.query(func.count(ChatSession.session_id)).filter(
                    ChatSession.is_active == True
                ).scalar()
                
                # Total sessions in date range
                total_sessions = session.query(func.count(ChatSession.session_id)).filter(
                    ChatSession.created_at >= start_date
                ).scalar()
                
                # Total messages in date range
                total_messages = session.query(func.count(ChatMessage.message_id)).filter(
                    ChatMessage.created_at >= start_date
                ).scalar()
                
                # Messages per day
                messages_per_day = session.query(
                    func.date(ChatMessage.created_at).label('date'),
                    func.count(ChatMessage.message_id).label('count')
                ).filter(
                    ChatMessage.created_at >= start_date
                ).group_by(
                    func.date(ChatMessage.created_at)
                ).order_by(
                    func.date(ChatMessage.created_at)
                ).all()
                
                # Average session duration (time between first and last message)
                session_durations = session.query(
                    ChatSession.session_id,
                    func.min(ChatMessage.created_at).label('first_message'),
                    func.max(ChatMessage.created_at).label('last_message')
                ).join(
                    ChatMessage, ChatSession.session_id == ChatMessage.session_id
                ).filter(
                    ChatSession.created_at >= start_date
                ).group_by(
                    ChatSession.session_id
                ).all()
                
                # Calculate average duration
                durations = []
                for session_id, first_msg, last_msg in session_durations:
                    if first_msg and last_msg:
                        duration = (last_msg - first_msg).total_seconds() / 60  # in minutes
                        durations.append(duration)
                
                avg_duration = sum(durations) / len(durations) if durations else 0
                
                # Most active users by message count
                most_active = session.query(
                    User.email,
                    User.full_name,
                    func.count(ChatMessage.message_id).label('message_count')
                ).join(
                    ChatSession, User.user_id == ChatSession.user_id
                ).join(
                    ChatMessage, ChatSession.session_id == ChatMessage.session_id
                ).filter(
                    ChatMessage.created_at >= start_date
                ).group_by(
                    User.user_id, User.email, User.full_name
                ).order_by(
                    desc('message_count')
                ).limit(10).all()
                
                most_active_users = [
                    {
                        'email': email,
                        'full_name': full_name,
                        'message_count': message_count
                    }
                    for email, full_name, message_count in most_active
                ]
                
                analytics = {
                    'active_sessions': active_sessions or 0,
                    'total_sessions': total_sessions or 0,
                    'total_messages': total_messages or 0,
                    'avg_session_duration_minutes': round(avg_duration, 2),
                    'messages_per_day': [
                        {
                            'date': str(date),
                            'count': count
                        }
                        for date, count in messages_per_day
                    ],
                    'most_active_users': most_active_users
                }
                
                logger.info(f"Retrieved session analytics for {days} days")
                return analytics
                
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving session analytics: {e}")
            raise Exception("Failed to retrieve session analytics")
        except Exception as e:
            logger.error(f"Unexpected error retrieving session analytics: {e}")
            raise Exception("An unexpected error occurred")
    
    @staticmethod
    def get_all_sessions(
        page: int = 1,
        page_size: int = 50,
        user_email: Optional[str] = None
    ) -> tuple:
        """
        Get all sessions across all users for admin viewing.
        
        Args:
            page: Page number (1-indexed)
            page_size: Number of sessions per page
            user_email: Optional filter by user email
            
        Returns:
            Tuple[List[Dict], int]: (List of session dictionaries, total count)
        """
        try:
            with DatabaseManager.get_session() as session:
                # Build base query
                query = session.query(
                    ChatSession,
                    User.email,
                    User.full_name,
                    func.count(ChatMessage.message_id).label('message_count')
                ).join(
                    User, ChatSession.user_id == User.user_id
                ).outerjoin(
                    ChatMessage, ChatSession.session_id == ChatMessage.session_id
                )
                
                # Apply user filter if provided
                if user_email:
                    query = query.filter(User.email.ilike(f"%{user_email}%"))
                
                # Group by session
                query = query.group_by(
                    ChatSession.session_id,
                    User.email,
                    User.full_name
                )
                
                # Get total count
                total_count = query.count()
                
                # Apply pagination and ordering
                results = query.order_by(
                    desc(ChatSession.updated_at)
                ).offset(
                    (page - 1) * page_size
                ).limit(page_size).all()
                
                # Convert to dictionaries
                session_list = [
                    {
                        'session_id': chat_session.session_id,
                        'user_id': chat_session.user_id,
                        'user_email': email,
                        'user_name': full_name,
                        'title': chat_session.title,
                        'created_at': chat_session.created_at,
                        'updated_at': chat_session.updated_at,
                        'message_count': message_count
                    }
                    for chat_session, email, full_name, message_count in results
                ]
                
                logger.info(f"Retrieved {len(session_list)} sessions (page {page}, total: {total_count})")
                return session_list, total_count
                
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving all sessions: {e}")
            raise Exception("Failed to retrieve sessions")
        except Exception as e:
            logger.error(f"Unexpected error retrieving all sessions: {e}")
            raise Exception("An unexpected error occurred")
