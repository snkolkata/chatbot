"""
Email service for sending transactional emails.

This module provides functionality for sending various types of emails
including password reset, welcome emails, and account notifications.
"""

import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional
from config.settings import settings

# Configure logging
logger = logging.getLogger(__name__)


class EmailService:
    """Service for sending transactional emails via SMTP."""
    
    def __init__(self):
        """Initialize the email service with SMTP configuration."""
        self.smtp_host = settings.SMTP_HOST
        self.smtp_port = settings.SMTP_PORT
        self.smtp_user = settings.SMTP_USER
        self.smtp_password = settings.SMTP_PASSWORD
        self.from_email = settings.SMTP_FROM_EMAIL
        self.from_name = settings.SMTP_FROM_NAME
        self.app_url = settings.APP_URL
        
        # Check if email is configured
        self.is_configured = bool(self.smtp_host and self.smtp_user and self.smtp_password)
        
        if not self.is_configured:
            logger.warning("Email service is not configured. Emails will be logged to console only.")
    
    def _send_email(self, to_email: str, subject: str, html_content: str, text_content: Optional[str] = None) -> bool:
        """
        Send an email via SMTP.
        
        Args:
            to_email: Recipient email address
            subject: Email subject line
            html_content: HTML version of the email body
            text_content: Plain text version of the email body (optional)
            
        Returns:
            bool: True if email was sent successfully, False otherwise
        """
        try:
            # If email is not configured, log to console
            if not self.is_configured:
                logger.info(f"\n{'='*60}")
                logger.info(f"EMAIL (Development Mode)")
                logger.info(f"{'='*60}")
                logger.info(f"To: {to_email}")
                logger.info(f"Subject: {subject}")
                logger.info(f"{'='*60}")
                logger.info(f"{text_content or 'See HTML content'}")
                logger.info(f"{'='*60}\n")
                return True
            
            # Create message
            message = MIMEMultipart('alternative')
            message['Subject'] = subject
            message['From'] = f"{self.from_name} <{self.from_email}>"
            message['To'] = to_email
            
            # Add plain text version if provided
            if text_content:
                text_part = MIMEText(text_content, 'plain')
                message.attach(text_part)
            
            # Add HTML version
            html_part = MIMEText(html_content, 'html')
            message.attach(html_part)
            
            # Send email via SMTP
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_user, self.smtp_password)
                server.send_message(message)
            
            logger.info(f"Email sent successfully to {to_email}: {subject}")
            return True
            
        except smtplib.SMTPException as e:
            logger.error(f"SMTP error sending email to {to_email}: {str(e)}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error sending email to {to_email}: {str(e)}")
            return False
    
    def send_password_reset_email(self, email: str, reset_token: str, full_name: str = "") -> bool:
        """
        Send a password reset email with a reset link.
        
        Args:
            email: Recipient email address
            reset_token: Password reset token
            full_name: User's full name (optional)
            
        Returns:
            bool: True if email was sent successfully, False otherwise
        """
        reset_link = f"{self.app_url}/PasswordReset?token={reset_token}"
        
        subject = "Password Reset Request - RAG Chatbot"
        
        # Plain text version
        text_content = f"""
Hello{' ' + full_name if full_name else ''},

You have requested to reset your password for your RAG Chatbot account.

Please click the link below to reset your password:
{reset_link}

This link will expire in {settings.RESET_TOKEN_EXPIRY_HOURS} hour(s).

If you did not request this password reset, please ignore this email.

Best regards,
The RAG Chatbot Team
"""
        
        # HTML version
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }}
        .header {{
            background-color: #4CAF50;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 5px 5px 0 0;
        }}
        .content {{
            background-color: #f9f9f9;
            padding: 30px;
            border: 1px solid #ddd;
            border-radius: 0 0 5px 5px;
        }}
        .button {{
            display: inline-block;
            padding: 12px 30px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 20px 0;
        }}
        .footer {{
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 12px;
            color: #666;
        }}
        .warning {{
            background-color: #fff3cd;
            border: 1px solid #ffc107;
            padding: 10px;
            border-radius: 5px;
            margin: 15px 0;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Password Reset Request</h1>
    </div>
    <div class="content">
        <p>Hello{' ' + full_name if full_name else ''},</p>
        
        <p>You have requested to reset your password for your RAG Chatbot account.</p>
        
        <p>Please click the button below to reset your password:</p>
        
        <center>
            <a href="{reset_link}" class="button">Reset Password</a>
        </center>
        
        <p>Or copy and paste this link into your browser:</p>
        <p style="word-break: break-all; color: #666;">{reset_link}</p>
        
        <div class="warning">
            <strong>⏰ Important:</strong> This link will expire in {settings.RESET_TOKEN_EXPIRY_HOURS} hour(s).
        </div>
        
        <p>If you did not request this password reset, please ignore this email. Your password will remain unchanged.</p>
        
        <div class="footer">
            <p>Best regards,<br>The RAG Chatbot Team</p>
        </div>
    </div>
</body>
</html>
"""
        
        return self._send_email(email, subject, html_content, text_content)
    
    def send_welcome_email(self, email: str, full_name: str) -> bool:
        """
        Send a welcome email to a newly registered user.
        
        Args:
            email: Recipient email address
            full_name: User's full name
            
        Returns:
            bool: True if email was sent successfully, False otherwise
        """
        subject = "Welcome to RAG Chatbot!"
        
        # Plain text version
        text_content = f"""
Hello {full_name},

Welcome to RAG Chatbot! We're excited to have you on board.

Your account has been successfully created. You can now log in and start using our intelligent document-based chatbot.

Getting Started:
1. Log in to your account at {self.app_url}
2. Upload documents to build your knowledge base
3. Start asking questions and get AI-powered answers

If you have any questions or need assistance, feel free to reach out to us at {settings.ADMIN_EMAIL}.

Best regards,
The RAG Chatbot Team
"""
        
        # HTML version
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }}
        .header {{
            background-color: #4CAF50;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 5px 5px 0 0;
        }}
        .content {{
            background-color: #f9f9f9;
            padding: 30px;
            border: 1px solid #ddd;
            border-radius: 0 0 5px 5px;
        }}
        .button {{
            display: inline-block;
            padding: 12px 30px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 20px 0;
        }}
        .feature-box {{
            background-color: white;
            border-left: 4px solid #4CAF50;
            padding: 15px;
            margin: 15px 0;
            border-radius: 3px;
        }}
        .footer {{
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 12px;
            color: #666;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🎉 Welcome to RAG Chatbot!</h1>
    </div>
    <div class="content">
        <p>Hello {full_name},</p>
        
        <p>Welcome to RAG Chatbot! We're excited to have you on board.</p>
        
        <p>Your account has been successfully created. You can now log in and start using our intelligent document-based chatbot.</p>
        
        <h3>Getting Started:</h3>
        
        <div class="feature-box">
            <strong>1. Log In</strong><br>
            Access your account and explore the dashboard
        </div>
        
        <div class="feature-box">
            <strong>2. Upload Documents</strong><br>
            Build your knowledge base by uploading PDF, TXT, or DOCX files
        </div>
        
        <div class="feature-box">
            <strong>3. Start Chatting</strong><br>
            Ask questions and get AI-powered answers based on your documents
        </div>
        
        <center>
            <a href="{self.app_url}" class="button">Go to RAG Chatbot</a>
        </center>
        
        <p>If you have any questions or need assistance, feel free to reach out to us at <a href="mailto:{settings.ADMIN_EMAIL}">{settings.ADMIN_EMAIL}</a>.</p>
        
        <div class="footer">
            <p>Best regards,<br>The RAG Chatbot Team</p>
        </div>
    </div>
</body>
</html>
"""
        
        return self._send_email(email, subject, html_content, text_content)
    
    def send_account_locked_email(self, email: str, full_name: str = "") -> bool:
        """
        Send an account locked notification email.
        
        Args:
            email: Recipient email address
            full_name: User's full name (optional)
            
        Returns:
            bool: True if email was sent successfully, False otherwise
        """
        subject = "Account Locked - RAG Chatbot"
        
        # Plain text version
        text_content = f"""
Hello{' ' + full_name if full_name else ''},

Your RAG Chatbot account has been temporarily locked due to multiple failed login attempts.

For your security, your account will be automatically unlocked after {settings.ACCOUNT_LOCKOUT_MINUTES} minutes.

If you did not attempt to log in, please reset your password immediately to secure your account.

If you need immediate assistance, please contact us at {settings.ADMIN_EMAIL}.

Best regards,
The RAG Chatbot Team
"""
        
        # HTML version
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }}
        .header {{
            background-color: #f44336;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 5px 5px 0 0;
        }}
        .content {{
            background-color: #f9f9f9;
            padding: 30px;
            border: 1px solid #ddd;
            border-radius: 0 0 5px 5px;
        }}
        .button {{
            display: inline-block;
            padding: 12px 30px;
            background-color: #f44336;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 20px 0;
        }}
        .alert {{
            background-color: #ffebee;
            border: 1px solid #f44336;
            padding: 15px;
            border-radius: 5px;
            margin: 15px 0;
        }}
        .info-box {{
            background-color: #e3f2fd;
            border-left: 4px solid #2196F3;
            padding: 15px;
            margin: 15px 0;
            border-radius: 3px;
        }}
        .footer {{
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 12px;
            color: #666;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🔒 Account Locked</h1>
    </div>
    <div class="content">
        <p>Hello{' ' + full_name if full_name else ''},</p>
        
        <div class="alert">
            <strong>⚠️ Security Alert:</strong> Your RAG Chatbot account has been temporarily locked due to multiple failed login attempts.
        </div>
        
        <p>For your security, we've temporarily locked your account to prevent unauthorized access.</p>
        
        <div class="info-box">
            <strong>ℹ️ What happens next?</strong><br>
            Your account will be automatically unlocked after <strong>{settings.ACCOUNT_LOCKOUT_MINUTES} minutes</strong>.
        </div>
        
        <p><strong>If this was you:</strong><br>
        Please wait {settings.ACCOUNT_LOCKOUT_MINUTES} minutes and try logging in again. Make sure you're using the correct password.</p>
        
        <p><strong>If this wasn't you:</strong><br>
        Someone may be trying to access your account. We recommend resetting your password immediately.</p>
        
        <center>
            <a href="{self.app_url}/PasswordReset" class="button">Reset Password</a>
        </center>
        
        <p>If you need immediate assistance, please contact us at <a href="mailto:{settings.ADMIN_EMAIL}">{settings.ADMIN_EMAIL}</a>.</p>
        
        <div class="footer">
            <p>Best regards,<br>The RAG Chatbot Team</p>
        </div>
    </div>
</body>
</html>
"""
        
        return self._send_email(email, subject, html_content, text_content)


# Create a singleton instance
email_service = EmailService()
