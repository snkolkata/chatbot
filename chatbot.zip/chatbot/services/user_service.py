"""
User Service for user management operations.
Handles user CRUD operations, role management, and user administration.
"""
import logging
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Tuple
from uuid import UUID

from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session
from sqlalchemy import func, desc

from services.database_manager import DatabaseManager
from services.models import User, ChatSession, ChatMessage

# Configure logging
logger = logging.getLogger(__name__)


class UserService:
    """
    Service for handling user management operations including:
    - User CRUD operations
    - Role management
    - User administration functions
    - User statistics
    """
    
    @staticmethod
    def get_user_by_id(user_id: str) -> Optional[Dict]:
        """
        Retrieve a user by their user ID.
        
        Args:
            user_id: User's unique identifier
            
        Returns:
            Optional[Dict]: User information dictionary or None if not found
        """
        try:
            with DatabaseManager.get_session() as session:
                user = session.query(User).filter(User.user_id == user_id).first()
                
                if not user:
                    logger.info(f"User not found with ID: {user_id}")
                    return None
                
                return {
                    "user_id": user.user_id,
                    "email": user.email,
                    "full_name": user.full_name,
                    "role": user.role,
                    "is_active": user.is_active,
                    "created_at": user.created_at,
                    "last_login": user.last_login,
                    "failed_login_attempts": user.failed_login_attempts,
                    "account_locked_until": user.account_locked_until
                }
                
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving user by ID: {e}")
            raise Exception("Failed to retrieve user")
        except Exception as e:
            logger.error(f"Unexpected error retrieving user by ID: {e}")
            raise Exception("An unexpected error occurred")
    
    @staticmethod
    def get_user_by_email(email: str) -> Optional[Dict]:
        """
        Retrieve a user by their email address.
        
        Args:
            email: User's email address
            
        Returns:
            Optional[Dict]: User information dictionary or None if not found
        """
        try:
            with DatabaseManager.get_session() as session:
                user = session.query(User).filter(User.email == email.lower()).first()
                
                if not user:
                    logger.info(f"User not found with email: {email}")
                    return None
                
                return {
                    "user_id": user.user_id,
                    "email": user.email,
                    "full_name": user.full_name,
                    "role": user.role,
                    "is_active": user.is_active,
                    "created_at": user.created_at,
                    "last_login": user.last_login,
                    "failed_login_attempts": user.failed_login_attempts,
                    "account_locked_until": user.account_locked_until
                }
                
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving user by email: {e}")
            raise Exception("Failed to retrieve user")
        except Exception as e:
            logger.error(f"Unexpected error retrieving user by email: {e}")
            raise Exception("An unexpected error occurred")

    @staticmethod
    def get_all_users(
        page: int = 1,
        page_size: int = 50,
        search_email: Optional[str] = None,
        role_filter: Optional[str] = None,
        active_only: bool = False
    ) -> Tuple[List[Dict], int]:
        """
        Retrieve all users with pagination and optional filtering.
        
        Args:
            page: Page number (1-indexed)
            page_size: Number of users per page
            search_email: Optional email search term (partial match)
            role_filter: Optional role filter ('user' or 'admin')
            active_only: If True, only return active users
            
        Returns:
            Tuple[List[Dict], int]: (List of user dictionaries, total count)
        """
        try:
            with DatabaseManager.get_session() as session:
                # Build base query
                query = session.query(User)
                
                # Apply filters
                if search_email:
                    query = query.filter(User.email.ilike(f"%{search_email}%"))
                
                if role_filter:
                    query = query.filter(User.role == role_filter)
                
                if active_only:
                    query = query.filter(User.is_active == True)
                
                # Get total count before pagination
                total_count = query.count()
                
                # Apply pagination and ordering
                users = query.order_by(desc(User.created_at)).offset(
                    (page - 1) * page_size
                ).limit(page_size).all()
                
                # Convert to dictionaries
                user_list = [
                    {
                        "user_id": user.user_id,
                        "email": user.email,
                        "full_name": user.full_name,
                        "role": user.role,
                        "is_active": user.is_active,
                        "created_at": user.created_at,
                        "last_login": user.last_login,
                        "failed_login_attempts": user.failed_login_attempts,
                        "account_locked_until": user.account_locked_until
                    }
                    for user in users
                ]
                
                logger.info(f"Retrieved {len(user_list)} users (page {page}, total: {total_count})")
                
                return user_list, total_count
                
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving users: {e}")
            raise Exception("Failed to retrieve users")
        except Exception as e:
            logger.error(f"Unexpected error retrieving users: {e}")
            raise Exception("An unexpected error occurred")
    
    @staticmethod
    def update_last_login(user_id: str) -> bool:
        """
        Update the last login timestamp for a user.
        
        Args:
            user_id: User's unique identifier
            
        Returns:
            bool: True if update was successful, False otherwise
        """
        try:
            with DatabaseManager.get_session() as session:
                user = session.query(User).filter(User.user_id == user_id).first()
                
                if not user:
                    logger.warning(f"Cannot update last login - user not found: {user_id}")
                    return False
                
                user.last_login = datetime.utcnow()
                session.commit()
                
                logger.info(f"Updated last login for user: {user.email}")
                return True
                
        except SQLAlchemyError as e:
            logger.error(f"Database error updating last login: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error updating last login: {e}")
            return False

    @staticmethod
    def update_user_role(user_id: str, new_role: str) -> bool:
        """
        Update a user's role.
        
        Args:
            user_id: User's unique identifier
            new_role: New role ('user' or 'admin')
            
        Returns:
            bool: True if update was successful, False otherwise
            
        Raises:
            ValueError: If role is invalid
        """
        # Validate role
        if new_role not in ["user", "admin"]:
            raise ValueError("Invalid role. Must be 'user' or 'admin'")
        
        try:
            with DatabaseManager.get_session() as session:
                user = session.query(User).filter(User.user_id == user_id).first()
                
                if not user:
                    logger.warning(f"Cannot update role - user not found: {user_id}")
                    return False
                
                old_role = user.role
                user.role = new_role
                session.commit()
                
                logger.info(f"Updated role for user {user.email}: {old_role} -> {new_role}")
                return True
                
        except ValueError:
            raise
        except SQLAlchemyError as e:
            logger.error(f"Database error updating user role: {e}")
            raise Exception("Failed to update user role")
        except Exception as e:
            logger.error(f"Unexpected error updating user role: {e}")
            raise Exception("An unexpected error occurred")
    
    @staticmethod
    def deactivate_user(user_id: str) -> bool:
        """
        Deactivate a user account (soft delete).
        
        Args:
            user_id: User's unique identifier
            
        Returns:
            bool: True if deactivation was successful, False otherwise
        """
        try:
            with DatabaseManager.get_session() as session:
                user = session.query(User).filter(User.user_id == user_id).first()
                
                if not user:
                    logger.warning(f"Cannot deactivate - user not found: {user_id}")
                    return False
                
                user.is_active = False
                session.commit()
                
                logger.info(f"Deactivated user: {user.email}")
                return True
                
        except SQLAlchemyError as e:
            logger.error(f"Database error deactivating user: {e}")
            raise Exception("Failed to deactivate user")
        except Exception as e:
            logger.error(f"Unexpected error deactivating user: {e}")
            raise Exception("An unexpected error occurred")
    
    @staticmethod
    def activate_user(user_id: str) -> bool:
        """
        Activate a user account.
        
        Args:
            user_id: User's unique identifier
            
        Returns:
            bool: True if activation was successful, False otherwise
        """
        try:
            with DatabaseManager.get_session() as session:
                user = session.query(User).filter(User.user_id == user_id).first()
                
                if not user:
                    logger.warning(f"Cannot activate - user not found: {user_id}")
                    return False
                
                user.is_active = True
                session.commit()
                
                logger.info(f"Activated user: {user.email}")
                return True
                
        except SQLAlchemyError as e:
            logger.error(f"Database error activating user: {e}")
            raise Exception("Failed to activate user")
        except Exception as e:
            logger.error(f"Unexpected error activating user: {e}")
            raise Exception("An unexpected error occurred")
    
    @staticmethod
    def delete_user(user_id: str) -> bool:
        """
        Permanently delete a user account and all associated data.
        This will cascade delete all chat sessions and messages.
        
        Args:
            user_id: User's unique identifier
            
        Returns:
            bool: True if deletion was successful, False otherwise
        """
        try:
            with DatabaseManager.get_session() as session:
                user = session.query(User).filter(User.user_id == user_id).first()
                
                if not user:
                    logger.warning(f"Cannot delete - user not found: {user_id}")
                    return False
                
                email = user.email
                
                # Delete user (cascade will handle related records)
                session.delete(user)
                session.commit()
                
                logger.info(f"Deleted user and all associated data: {email}")
                return True
                
        except SQLAlchemyError as e:
            logger.error(f"Database error deleting user: {e}")
            raise Exception("Failed to delete user")
        except Exception as e:
            logger.error(f"Unexpected error deleting user: {e}")
            raise Exception("An unexpected error occurred")
    
    @staticmethod
    def get_user_statistics() -> Dict:
        """
        Get system-wide user statistics for admin dashboard.
        
        Returns:
            Dict: Dictionary containing user statistics
        """
        try:
            with DatabaseManager.get_session() as session:
                # Total users
                total_users = session.query(func.count(User.user_id)).scalar()
                
                # Active users
                active_users = session.query(func.count(User.user_id)).filter(
                    User.is_active == True
                ).scalar()
                
                # Admin users
                admin_users = session.query(func.count(User.user_id)).filter(
                    User.role == "admin"
                ).scalar()
                
                # Users registered in last 30 days
                thirty_days_ago = datetime.utcnow() - timedelta(days=30)
                recent_users = session.query(func.count(User.user_id)).filter(
                    User.created_at >= thirty_days_ago
                ).scalar()
                
                # Users who logged in recently (last 7 days)
                seven_days_ago = datetime.utcnow() - timedelta(days=7)
                recent_logins = session.query(func.count(User.user_id)).filter(
                    User.last_login >= seven_days_ago
                ).scalar()
                
                # Total chat sessions
                total_sessions = session.query(func.count(ChatSession.session_id)).scalar()
                
                # Total messages
                total_messages = session.query(func.count(ChatMessage.message_id)).scalar()
                
                # Most active users (by message count)
                most_active_users = session.query(
                    User.email,
                    User.full_name,
                    func.count(ChatMessage.message_id).label("message_count")
                ).join(
                    ChatSession, User.user_id == ChatSession.user_id
                ).join(
                    ChatMessage, ChatSession.session_id == ChatMessage.session_id
                ).group_by(
                    User.user_id, User.email, User.full_name
                ).order_by(
                    desc("message_count")
                ).limit(10).all()
                
                most_active = [
                    {
                        "email": email,
                        "full_name": full_name,
                        "message_count": message_count
                    }
                    for email, full_name, message_count in most_active_users
                ]
                
                statistics = {
                    "total_users": total_users or 0,
                    "active_users": active_users or 0,
                    "admin_users": admin_users or 0,
                    "recent_registrations": recent_users or 0,
                    "recent_logins": recent_logins or 0,
                    "total_sessions": total_sessions or 0,
                    "total_messages": total_messages or 0,
                    "most_active_users": most_active
                }
                
                logger.info("Retrieved user statistics")
                return statistics
                
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving user statistics: {e}")
            raise Exception("Failed to retrieve user statistics")
        except Exception as e:
            logger.error(f"Unexpected error retrieving user statistics: {e}")
            raise Exception("An unexpected error occurred")
