"""
Document Service for handling document upload, processing, and management.

This module provides the DocumentService class that manages document lifecycle
including upload, validation, processing, chunking, and deletion operations.
"""

import os
import json
import logging
from datetime import datetime
from typing import List, Dict, Optional, BinaryIO
from pathlib import Path

from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader, TextLoader, Docx2txtLoader

from config.settings import settings
from services.vector_store import VectorStoreManager
from utils.helpers import (
    ValidationError,
    DocumentProcessingError,
    log_exception,
    validate_file_format,
    validate_file_size
)

logger = logging.getLogger(__name__)


class DocumentService:
    """
    Service for managing document upload, processing, and retrieval operations.
    
    This class handles document validation, loading different file formats,
    text chunking, metadata management, and integration with the vector store.
    """
    
    def __init__(self, vector_store: VectorStoreManager, storage_path: str = None):
        """
        Initialize the DocumentService.
        
        Args:
            vector_store: VectorStoreManager instance for storing document embeddings
            storage_path: Path to store uploaded documents (defaults to settings)
        """
        self.vector_store = vector_store
        self.storage_path = storage_path or settings.DOCUMENT_STORAGE_PATH
        self.metadata_file = os.path.join(self.storage_path, "metadata.json")
        
        # Create storage directory if it doesn't exist
        os.makedirs(self.storage_path, exist_ok=True)
        
        # Initialize metadata storage
        self._load_metadata()
        
    def _load_metadata(self) -> None:
        """Load document metadata from JSON file."""
        if os.path.exists(self.metadata_file):
            try:
                with open(self.metadata_file, 'r') as f:
                    self.metadata = json.load(f)
            except Exception as e:
                logger.error(f"Failed to load metadata: {str(e)}")
                self.metadata = {}
        else:
            self.metadata = {}
    
    def _save_metadata(self) -> None:
        """Save document metadata to JSON file."""
        try:
            with open(self.metadata_file, 'w') as f:
                json.dump(self.metadata, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save metadata: {str(e)}")
            raise

    def _validate_file(self, filename: str, file_size: int) -> None:
        """
        Validate file format and size.
        
        Args:
            filename: Name of the file to validate
            file_size: Size of the file in bytes
            
        Raises:
            ValidationError: If validation fails
        """
        # Check file extension using helper
        validate_file_format(filename, settings.SUPPORTED_FILE_TYPES)
        
        # Check file size using helper
        validate_file_size(file_size, settings.MAX_FILE_SIZE_MB)
    
    @log_exception
    def _load_document(self, file_path: str) -> List[Document]:
        """
        Load document based on file type using appropriate LangChain loader.
        
        Args:
            file_path: Path to the document file
            
        Returns:
            List of Document objects
            
        Raises:
            ValidationError: If file type is not supported
            DocumentProcessingError: If document loading fails
        """
        file_ext = Path(file_path).suffix.lower()
        
        try:
            if file_ext == '.pdf':
                loader = PyPDFLoader(file_path)
            elif file_ext == '.txt':
                loader = TextLoader(file_path, encoding='utf-8')
            elif file_ext == '.docx':
                loader = Docx2txtLoader(file_path)
            else:
                raise ValidationError(f"Unsupported file type: {file_ext}")
            
            documents = loader.load()
            
            if not documents:
                raise DocumentProcessingError(f"No content could be extracted from {file_path}")
            
            logger.info(f"Loaded {len(documents)} pages/sections from {file_path}")
            return documents
            
        except (ValidationError, DocumentProcessingError):
            raise
        except Exception as e:
            logger.error(f"Failed to load document {file_path}: {str(e)}", exc_info=True)
            raise DocumentProcessingError(f"Failed to load document: {str(e)}") from e
    
    def _chunk_documents(self, documents: List[Document]) -> List[Document]:
        """
        Split documents into chunks using RecursiveCharacterTextSplitter.
        
        Args:
            documents: List of Document objects to chunk
            
        Returns:
            List of chunked Document objects
        """
        # Filter out empty documents
        non_empty_docs = []
        total_chars = 0
        for i, doc in enumerate(documents):
            content = doc.page_content.strip() if doc.page_content else ""
            if content:
                non_empty_docs.append(doc)
                total_chars += len(content)
                logger.debug(f"Page {i+1}: {len(content)} characters")
            else:
                logger.warning(f"Skipping empty document page {i+1}")
        
        if not non_empty_docs:
            logger.error("All document pages are empty or contain no text")
            return []
        
        logger.info(f"Processing {len(non_empty_docs)} non-empty pages with {total_chars} total characters")
        
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=settings.CHUNK_SIZE,
            chunk_overlap=settings.CHUNK_OVERLAP,
            length_function=len,
            separators=["\n\n", "\n", " ", ""]
        )
        
        chunks = text_splitter.split_documents(non_empty_docs)
        logger.info(f"Split documents into {len(chunks)} chunks")
        
        # If no chunks were created but we have non-empty docs, use the docs as chunks
        if not chunks and non_empty_docs:
            logger.warning("Text splitter returned 0 chunks, using original documents as chunks")
            chunks = non_empty_docs
        
        return chunks

    @log_exception
    def upload_document(self, file: BinaryIO, filename: str) -> Dict:
        """
        Upload and process a document into the vector store.
        
        This method handles the complete document upload workflow:
        1. Validates file format and size
        2. Saves file to storage
        3. Loads and processes document
        4. Chunks text into smaller pieces
        5. Adds chunks to vector store
        6. Stores metadata
        
        Args:
            file: File object (binary stream)
            filename: Original filename
            
        Returns:
            Dictionary containing upload result with doc_id and metadata
            
        Raises:
            ValidationError: If file validation fails
            DocumentProcessingError: If upload or processing fails
        """
        file_path = None
        
        try:
            # Read file content
            file_content = file.read()
            file_size = len(file_content)
            
            logger.info(f"Starting upload for {filename} ({file_size} bytes)")
            
            # Validate file
            self._validate_file(filename, file_size)
            
            # Generate unique document ID with microseconds for uniqueness
            doc_id = f"{datetime.now().strftime('%Y%m%d%H%M%S%f')}_{filename}"
            file_path = os.path.join(self.storage_path, doc_id)
            
            # Save file to storage
            try:
                with open(file_path, 'wb') as f:
                    f.write(file_content)
                logger.info(f"Saved file to {file_path}")
            except IOError as e:
                raise DocumentProcessingError(f"Failed to save file: {str(e)}") from e
            
            # Load document
            documents = self._load_document(file_path)
            
            # Chunk documents
            chunks = self._chunk_documents(documents)
            
            if not chunks:
                raise DocumentProcessingError(
                    "No text chunks could be created from the document. "
                    "The PDF may be image-based or contain no extractable text. "
                    "Please ensure the PDF contains selectable text."
                )
            
            # Add source metadata to chunks
            for chunk in chunks:
                chunk.metadata['source'] = filename
                chunk.metadata['doc_id'] = doc_id
            
            # Add to vector store
            try:
                self.vector_store.add_documents(chunks)
            except Exception as e:
                raise DocumentProcessingError(f"Failed to add document to vector store: {str(e)}") from e
            
            # Store metadata
            upload_timestamp = datetime.now().isoformat()
            self.metadata[doc_id] = {
                "doc_id": doc_id,
                "filename": filename,
                "upload_timestamp": upload_timestamp,
                "file_size": file_size,
                "file_type": Path(filename).suffix.lower(),
                "chunk_count": len(chunks),
                "file_path": file_path
            }
            
            try:
                self._save_metadata()
            except Exception as e:
                logger.error(f"Failed to save metadata, but document was uploaded: {str(e)}")
            
            logger.info(f"Successfully uploaded document: {filename} ({len(chunks)} chunks)")
            
            return {
                "success": True,
                "doc_id": doc_id,
                "filename": filename,
                "chunk_count": len(chunks),
                "message": f"Document uploaded successfully with {len(chunks)} chunks"
            }
            
        except (ValidationError, DocumentProcessingError):
            # Clean up file if it was saved
            if file_path and os.path.exists(file_path):
                try:
                    os.remove(file_path)
                    logger.info(f"Cleaned up file after error: {file_path}")
                except Exception as cleanup_error:
                    logger.error(f"Failed to clean up file {file_path}: {str(cleanup_error)}")
            raise
        except Exception as e:
            # Clean up file if it was saved
            if file_path and os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except Exception:
                    pass
            logger.error(f"Unexpected error uploading document {filename}: {str(e)}", exc_info=True)
            raise DocumentProcessingError(f"Failed to upload document: {str(e)}") from e

    def list_documents(self) -> List[Dict]:
        """
        Retrieve all document metadata.
        
        Returns:
            List of dictionaries containing document metadata
        """
        try:
            documents = list(self.metadata.values())
            logger.info(f"Retrieved {len(documents)} documents")
            return documents
        except Exception as e:
            logger.error(f"Failed to list documents: {str(e)}")
            return []
    
    @log_exception
    def delete_document(self, doc_id: str) -> bool:
        """
        Delete a document and its associated embeddings.
        
        This method removes:
        1. Document chunks from vector store
        2. Physical file from storage
        3. Metadata entry
        
        Args:
            doc_id: Unique document identifier
            
        Returns:
            True if deletion was successful
            
        Raises:
            ValidationError: If document ID is not found
            DocumentProcessingError: If deletion fails
        """
        # Check if document exists
        if doc_id not in self.metadata:
            raise ValidationError(f"Document not found: {doc_id}")
        
        doc_metadata = self.metadata[doc_id]
        filename = doc_metadata['filename']
        file_path = doc_metadata['file_path']
        
        errors = []
        
        # Delete from vector store
        try:
            self.vector_store.delete_by_source(filename)
            logger.info(f"Deleted embeddings for document: {filename}")
        except Exception as e:
            error_msg = f"Failed to delete embeddings: {str(e)}"
            logger.error(error_msg, exc_info=True)
            errors.append(error_msg)
        
        # Delete physical file
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                logger.info(f"Deleted file: {file_path}")
            else:
                logger.warning(f"File not found for deletion: {file_path}")
        except Exception as e:
            error_msg = f"Failed to delete file: {str(e)}"
            logger.error(error_msg, exc_info=True)
            errors.append(error_msg)
        
        # Remove metadata
        try:
            del self.metadata[doc_id]
            self._save_metadata()
            logger.info(f"Removed metadata for document: {doc_id}")
        except Exception as e:
            error_msg = f"Failed to remove metadata: {str(e)}"
            logger.error(error_msg, exc_info=True)
            errors.append(error_msg)
        
        if errors:
            raise DocumentProcessingError(
                f"Document deletion completed with errors: {'; '.join(errors)}"
            )
        
        logger.info(f"Successfully deleted document: {doc_id}")
        return True
    
    def get_document_stats(self) -> Dict:
        """
        Get statistics about stored documents.
        
        Returns:
            Dictionary containing document statistics
        """
        try:
            total_documents = len(self.metadata)
            total_chunks = sum(doc['chunk_count'] for doc in self.metadata.values())
            total_size = sum(doc['file_size'] for doc in self.metadata.values())
            
            return {
                "total_documents": total_documents,
                "total_chunks": total_chunks,
                "total_size_bytes": total_size,
                "total_size_mb": round(total_size / (1024 * 1024), 2)
            }
        except Exception as e:
            logger.error(f"Failed to get document stats: {str(e)}")
            return {
                "total_documents": 0,
                "total_chunks": 0,
                "total_size_bytes": 0,
                "total_size_mb": 0
            }
