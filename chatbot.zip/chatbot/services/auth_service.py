"""
Authentication Service for user authentication and authorization.
Handles password hashing, user registration, login, and password reset.
"""
import logging
import re
import uuid
from datetime import datetime, timedelta
from typing import Optional, Dict, Tuple
import bcrypt

from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import Session

from config.settings import settings
from services.database_manager import DatabaseManager
from services.models import User, PasswordResetToken

# Configure logging
logger = logging.getLogger(__name__)


class AuthenticationError(Exception):
    """Raised when authentication fails."""
    pass


class AccountLockedError(Exception):
    """Raised when account is locked due to failed login attempts."""
    pass


class InvalidTokenError(Exception):
    """Raised when password reset token is invalid or expired."""
    pass


class AuthService:
    """
    Service for handling authentication operations including:
    - Password hashing and verification
    - User registration
    - User login and authentication
    - Password reset functionality
    """
    
    @staticmethod
    def hash_password(password: str) -> str:
        """
        Hash a password using bcrypt with configured cost factor.
        
        Args:
            password: Plain text password to hash
            
        Returns:
            str: Hashed password
        """
        # Generate salt and hash password
        salt = bcrypt.gensalt(rounds=settings.BCRYPT_COST_FACTOR)
        password_hash = bcrypt.hashpw(password.encode('utf-8'), salt)
        return password_hash.decode('utf-8')
    
    @staticmethod
    def verify_password(password: str, password_hash: str) -> bool:
        """
        Verify a password against its hash.
        
        Args:
            password: Plain text password to verify
            password_hash: Hashed password to compare against
            
        Returns:
            bool: True if password matches, False otherwise
        """
        try:
            return bcrypt.checkpw(
                password.encode('utf-8'),
                password_hash.encode('utf-8')
            )
        except Exception as e:
            logger.error(f"Password verification error: {e}")
            return False
    
    @staticmethod
    def validate_password_strength(password: str) -> Tuple[bool, str]:
        """
        Validate password meets minimum security requirements.
        Requirements:
        - Minimum 8 characters
        - At least one uppercase letter
        - At least one lowercase letter
        - At least one number
        
        Args:
            password: Password to validate
            
        Returns:
            Tuple[bool, str]: (is_valid, error_message)
        """
        if len(password) < settings.PASSWORD_MIN_LENGTH:
            return False, f"Password must be at least {settings.PASSWORD_MIN_LENGTH} characters long"
        
        if not re.search(r'[A-Z]', password):
            return False, "Password must contain at least one uppercase letter"
        
        if not re.search(r'[a-z]', password):
            return False, "Password must contain at least one lowercase letter"
        
        if not re.search(r'\d', password):
            return False, "Password must contain at least one number"
        
        return True, ""
    
    @staticmethod
    def validate_email(email: str) -> Tuple[bool, str]:
        """
        Validate email format.
        
        Args:
            email: Email address to validate
            
        Returns:
            Tuple[bool, str]: (is_valid, error_message)
        """
        # Basic email validation regex
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        
        if not email or not email.strip():
            return False, "Email is required"
        
        if not re.match(email_pattern, email):
            return False, "Invalid email format"
        
        return True, ""
    
    @staticmethod
    def register_user(
        email: str,
        password: str,
        full_name: str,
        role: str = "user"
    ) -> Dict:
        """
        Register a new user with email and password.
        
        Args:
            email: User's email address
            password: User's password (plain text)
            full_name: User's full name
            role: User role (default: "user")
            
        Returns:
            Dict: Dictionary containing user_id and success message
            
        Raises:
            ValueError: If validation fails
            IntegrityError: If email already exists
        """
        # Validate email
        email_valid, email_error = AuthService.validate_email(email)
        if not email_valid:
            raise ValueError(email_error)
        
        # Validate password strength
        password_valid, password_error = AuthService.validate_password_strength(password)
        if not password_valid:
            raise ValueError(password_error)
        
        # Validate full name
        if not full_name or not full_name.strip():
            raise ValueError("Full name is required")
        
        # Validate role
        if role not in ["user", "admin"]:
            raise ValueError("Invalid role. Must be 'user' or 'admin'")
        
        try:
            with DatabaseManager.get_session() as session:
                # Check if email already exists
                existing_user = session.query(User).filter(User.email == email.lower()).first()
                if existing_user:
                    raise ValueError("Email already registered")
                
                # Hash password
                password_hash = AuthService.hash_password(password)
                
                # Create new user
                new_user = User(
                    email=email.lower(),
                    password_hash=password_hash,
                    full_name=full_name.strip(),
                    role=role,
                    is_active=True
                )
                
                session.add(new_user)
                session.flush()  # Flush to get the user_id
                
                user_id = new_user.user_id
                
                logger.info(f"User registered successfully: {email}")
                
                return {
                    "user_id": user_id,
                    "email": email.lower(),
                    "full_name": full_name.strip(),
                    "role": role,
                    "message": "User registered successfully"
                }
                
        except ValueError:
            # Re-raise validation errors
            raise
        except IntegrityError as e:
            logger.error(f"Database integrity error during registration: {e}")
            raise ValueError("Email already registered")
        except SQLAlchemyError as e:
            logger.error(f"Database error during registration: {e}")
            raise Exception("Failed to register user. Please try again.")
        except Exception as e:
            logger.error(f"Unexpected error during registration: {e}")
            raise Exception("An unexpected error occurred. Please try again.")
    
    @staticmethod
    def is_account_locked(email: str) -> bool:
        """
        Check if an account is currently locked due to failed login attempts.
        
        Args:
            email: User's email address
            
        Returns:
            bool: True if account is locked, False otherwise
        """
        try:
            with DatabaseManager.get_session() as session:
                user = session.query(User).filter(User.email == email.lower()).first()
                
                if not user:
                    return False
                
                # Check if account is locked and lock period hasn't expired
                if user.account_locked_until:
                    if datetime.utcnow() < user.account_locked_until:
                        return True
                    else:
                        # Lock period expired, unlock account
                        user.account_locked_until = None
                        user.failed_login_attempts = 0
                        session.commit()
                        return False
                
                return False
                
        except Exception as e:
            logger.error(f"Error checking account lock status: {e}")
            return False
    
    @staticmethod
    def _handle_failed_login(session: Session, user: User) -> None:
        """
        Handle failed login attempt by incrementing counter and locking account if needed.
        
        Args:
            session: Database session
            user: User object
        """
        user.failed_login_attempts += 1
        
        # Lock account if max attempts reached
        if user.failed_login_attempts >= settings.MAX_LOGIN_ATTEMPTS:
            lockout_duration = timedelta(minutes=settings.ACCOUNT_LOCKOUT_MINUTES)
            user.account_locked_until = datetime.utcnow() + lockout_duration
            logger.warning(f"Account locked for user {user.email} until {user.account_locked_until}")
        
        session.commit()
    
    @staticmethod
    def _reset_failed_login_attempts(session: Session, user: User) -> None:
        """
        Reset failed login attempts counter on successful login.
        
        Args:
            session: Database session
            user: User object
        """
        user.failed_login_attempts = 0
        user.account_locked_until = None
        session.commit()
    
    @staticmethod
    def authenticate_user(email: str, password: str) -> Dict:
        """
        Authenticate a user with email and password.
        
        Args:
            email: User's email address
            password: User's password (plain text)
            
        Returns:
            Dict: Dictionary containing user information
            
        Raises:
            AuthenticationError: If credentials are invalid
            AccountLockedError: If account is locked
            ValueError: If user is inactive
        """
        try:
            with DatabaseManager.get_session() as session:
                # Find user by email
                user = session.query(User).filter(User.email == email.lower()).first()
                
                if not user:
                    logger.warning(f"Login attempt for non-existent user: {email}")
                    raise AuthenticationError("Invalid email or password")
                
                # Check if account is locked
                if user.account_locked_until:
                    if datetime.utcnow() < user.account_locked_until:
                        remaining_time = user.account_locked_until - datetime.utcnow()
                        minutes = int(remaining_time.total_seconds() / 60)
                        raise AccountLockedError(
                            f"Account is locked due to too many failed login attempts. "
                            f"Please try again in {minutes} minutes."
                        )
                    else:
                        # Lock period expired, unlock account
                        user.account_locked_until = None
                        user.failed_login_attempts = 0
                
                # Check if account is active
                if not user.is_active:
                    logger.warning(f"Login attempt for inactive user: {email}")
                    raise ValueError("Account is inactive. Please contact support.")
                
                # Verify password
                if not AuthService.verify_password(password, user.password_hash):
                    logger.warning(f"Failed login attempt for user: {email}")
                    AuthService._handle_failed_login(session, user)
                    raise AuthenticationError("Invalid email or password")
                
                # Successful login - reset failed attempts and update last login
                AuthService._reset_failed_login_attempts(session, user)
                user.last_login = datetime.utcnow()
                session.commit()
                
                logger.info(f"User authenticated successfully: {email}")
                
                return {
                    "user_id": user.user_id,
                    "email": user.email,
                    "full_name": user.full_name,
                    "role": user.role,
                    "last_login": user.last_login
                }
                
        except (AuthenticationError, AccountLockedError, ValueError):
            # Re-raise expected exceptions
            raise
        except SQLAlchemyError as e:
            logger.error(f"Database error during authentication: {e}")
            raise Exception("Authentication failed. Please try again.")
        except Exception as e:
            logger.error(f"Unexpected error during authentication: {e}")
            raise Exception("An unexpected error occurred. Please try again.")
    
    @staticmethod
    def create_password_reset_token(email: str) -> Optional[str]:
        """
        Create a password reset token for a user.
        
        Args:
            email: User's email address
            
        Returns:
            Optional[str]: Reset token if user exists, None otherwise
            
        Note:
            Returns None for non-existent users to prevent user enumeration.
        """
        try:
            with DatabaseManager.get_session() as session:
                # Find user by email
                user = session.query(User).filter(User.email == email.lower()).first()
                
                if not user:
                    # Don't reveal that user doesn't exist
                    logger.info(f"Password reset requested for non-existent user: {email}")
                    return None
                
                # Generate secure token
                token = str(uuid.uuid4())
                
                # Calculate expiration time
                expires_at = datetime.utcnow() + timedelta(hours=settings.RESET_TOKEN_EXPIRY_HOURS)
                
                # Create reset token record
                reset_token = PasswordResetToken(
                    user_id=user.user_id,
                    token=token,
                    expires_at=expires_at,
                    used=False
                )
                
                session.add(reset_token)
                session.commit()
                
                logger.info(f"Password reset token created for user: {email}")
                
                return token
                
        except SQLAlchemyError as e:
            logger.error(f"Database error creating reset token: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error creating reset token: {e}")
            return None
    
    @staticmethod
    def verify_reset_token(token: str) -> Optional[str]:
        """
        Verify a password reset token and return the associated user_id.
        
        Args:
            token: Reset token to verify
            
        Returns:
            Optional[str]: User ID if token is valid, None otherwise
            
        Raises:
            InvalidTokenError: If token is invalid or expired
        """
        try:
            with DatabaseManager.get_session() as session:
                # Find token
                reset_token = session.query(PasswordResetToken).filter(
                    PasswordResetToken.token == token
                ).first()
                
                if not reset_token:
                    raise InvalidTokenError("Invalid or expired reset token")
                
                # Check if token has been used
                if reset_token.used:
                    raise InvalidTokenError("Reset token has already been used")
                
                # Check if token has expired
                if datetime.utcnow() > reset_token.expires_at:
                    raise InvalidTokenError("Reset token has expired")
                
                return reset_token.user_id
                
        except InvalidTokenError:
            raise
        except SQLAlchemyError as e:
            logger.error(f"Database error verifying reset token: {e}")
            raise InvalidTokenError("Failed to verify reset token")
        except Exception as e:
            logger.error(f"Unexpected error verifying reset token: {e}")
            raise InvalidTokenError("Failed to verify reset token")
    
    @staticmethod
    def reset_password(token: str, new_password: str) -> bool:
        """
        Reset a user's password using a valid reset token.
        
        Args:
            token: Reset token
            new_password: New password (plain text)
            
        Returns:
            bool: True if password was reset successfully
            
        Raises:
            InvalidTokenError: If token is invalid or expired
            ValueError: If new password doesn't meet requirements
        """
        # Validate new password strength
        password_valid, password_error = AuthService.validate_password_strength(new_password)
        if not password_valid:
            raise ValueError(password_error)
        
        try:
            with DatabaseManager.get_session() as session:
                # Verify token and get user_id
                user_id = AuthService.verify_reset_token(token)
                
                # Find the token record
                reset_token = session.query(PasswordResetToken).filter(
                    PasswordResetToken.token == token
                ).first()
                
                if not reset_token:
                    raise InvalidTokenError("Invalid reset token")
                
                # Find user
                user = session.query(User).filter(User.user_id == user_id).first()
                
                if not user:
                    raise InvalidTokenError("User not found")
                
                # Hash new password
                new_password_hash = AuthService.hash_password(new_password)
                
                # Update user password
                user.password_hash = new_password_hash
                
                # Mark token as used
                reset_token.used = True
                
                # Reset failed login attempts
                user.failed_login_attempts = 0
                user.account_locked_until = None
                
                session.commit()
                
                logger.info(f"Password reset successfully for user: {user.email}")
                
                # Clean up expired/used tokens for this user
                AuthService._cleanup_expired_tokens(user_id)
                
                return True
                
        except (InvalidTokenError, ValueError):
            raise
        except SQLAlchemyError as e:
            logger.error(f"Database error resetting password: {e}")
            raise Exception("Failed to reset password. Please try again.")
        except Exception as e:
            logger.error(f"Unexpected error resetting password: {e}")
            raise Exception("An unexpected error occurred. Please try again.")
    
    @staticmethod
    def _cleanup_expired_tokens(user_id: str) -> None:
        """
        Clean up expired or used password reset tokens for a user.
        
        Args:
            user_id: User's ID
        """
        try:
            with DatabaseManager.get_session() as session:
                # Delete expired or used tokens
                session.query(PasswordResetToken).filter(
                    PasswordResetToken.user_id == user_id,
                    (PasswordResetToken.used == True) | 
                    (PasswordResetToken.expires_at < datetime.utcnow())
                ).delete()
                
                session.commit()
                logger.debug(f"Cleaned up expired tokens for user: {user_id}")
                
        except Exception as e:
            logger.error(f"Error cleaning up expired tokens: {e}")
