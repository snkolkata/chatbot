"""
Vector Store Manager for ChromaDB operations.

This module provides the VectorStoreManager class that handles all interactions
with the ChromaDB vector database, including initialization, document management,
and similarity search operations.
"""

import os
import logging

# Set GOOGLE_API_KEY environment variable early, before importing Google libraries
# This is required because langchain_google_genai checks env vars during import
from config.settings import settings
if settings.GEMINI_API_KEY and not os.getenv("GOOGLE_API_KEY"):
    os.environ["GOOGLE_API_KEY"] = settings.GEMINI_API_KEY

import chromadb
from chromadb.config import Settings as ChromaSettings
from typing import List, Dict, Any, Optional
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_chroma import Chroma

from utils.helpers import VectorStoreError, log_exception

logger = logging.getLogger(__name__)


class VectorStoreManager:
    """
    Manages ChromaDB vector store operations for document storage and retrieval.
    
    This class handles the initialization of ChromaDB, adding documents with embeddings,
    deleting documents by source, and performing similarity searches for RAG operations.
    """
    
    def __init__(self, persist_directory: str, embedding_function=None):
        """
        Initialize the VectorStoreManager.
        
        Args:
            persist_directory: Path to the directory where ChromaDB will persist data
            embedding_function: Optional embedding function (defaults based on LLM_PROVIDER)
        """
        self.persist_directory = persist_directory
        
        # Use provided embedding function or create one based on provider
        if embedding_function:
            self.embedding_function = embedding_function
        elif settings.EMBEDDING_PROVIDER == "gemini":
            # GOOGLE_API_KEY is already set at module level
            self.embedding_function = GoogleGenerativeAIEmbeddings(
                model=settings.EMBEDDING_MODEL
            )
            logger.info(f"Using Gemini embeddings: {settings.EMBEDDING_MODEL}")
        else:
            self.embedding_function = OpenAIEmbeddings(
                model=settings.EMBEDDING_MODEL,
                openai_api_key=settings.OPENAI_API_KEY
            )
            logger.info(f"Using OpenAI embeddings: {settings.EMBEDDING_MODEL}")
            
        self.client = None
        self.collection = None
        self.vectorstore = None
        
    @log_exception
    def initialize(self) -> None:
        """
        Initialize ChromaDB client and collection.
        
        Creates the persist directory if it doesn't exist and sets up the ChromaDB
        client with persistent storage. Initializes or loads the document collection.
        
        Raises:
            VectorStoreError: If initialization fails
        """
        try:
            # Create persist directory if it doesn't exist
            os.makedirs(self.persist_directory, exist_ok=True)
            logger.info(f"Persist directory ready: {self.persist_directory}")
            
            # Initialize ChromaDB client with persistent storage
            try:
                self.client = chromadb.PersistentClient(
                    path=self.persist_directory,
                    settings=ChromaSettings(
                        anonymized_telemetry=False,
                        allow_reset=True
                    )
                )
            except Exception as e:
                raise VectorStoreError(f"Failed to initialize ChromaDB client: {str(e)}") from e
            
            # Initialize LangChain Chroma vectorstore
            try:
                self.vectorstore = Chroma(
                    client=self.client,
                    collection_name="documents",
                    embedding_function=self.embedding_function,
                    persist_directory=self.persist_directory
                )
            except Exception as e:
                raise VectorStoreError(f"Failed to initialize Chroma vectorstore: {str(e)}") from e
            
            logger.info(f"Vector store initialized successfully at {self.persist_directory}")
            
        except VectorStoreError:
            raise
        except Exception as e:
            logger.error(f"Unexpected error initializing vector store: {str(e)}", exc_info=True)
            raise VectorStoreError(f"Failed to initialize vector store: {str(e)}") from e
    
    @log_exception
    def add_documents(self, documents: List[Document], metadata: Optional[Dict[str, Any]] = None) -> List[str]:
        """
        Add document chunks with metadata to the vector store.
        
        Args:
            documents: List of LangChain Document objects containing text chunks
            metadata: Optional additional metadata to add to all documents
            
        Returns:
            List of document IDs that were added
            
        Raises:
            VectorStoreError: If vector store is not initialized or adding documents fails
        """
        if self.vectorstore is None:
            raise VectorStoreError("Vector store not initialized. Call initialize() first.")
        
        if not documents:
            logger.warning("No documents provided to add_documents")
            return []
        
        try:
            # Add additional metadata if provided
            if metadata:
                for doc in documents:
                    doc.metadata.update(metadata)
            
            # Add documents to vector store
            ids = self.vectorstore.add_documents(documents)
            
            logger.info(f"Added {len(documents)} document chunks to vector store")
            return ids
            
        except Exception as e:
            logger.error(f"Failed to add documents to vector store: {str(e)}", exc_info=True)
            raise VectorStoreError(f"Failed to add documents: {str(e)}") from e
    
    @log_exception
    def delete_by_source(self, source: str) -> None:
        """
        Remove all document chunks from a specific source file.
        
        Args:
            source: The source filename to delete (e.g., "document.pdf")
            
        Raises:
            VectorStoreError: If vector store is not initialized or deletion fails
        """
        if self.vectorstore is None:
            raise VectorStoreError("Vector store not initialized. Call initialize() first.")
        
        try:
            # Get the underlying collection
            collection = self.vectorstore._collection
            
            # Query for all documents with matching source
            results = collection.get(
                where={"source": source}
            )
            
            # Delete documents if found
            if results and results['ids']:
                collection.delete(ids=results['ids'])
                logger.info(f"Deleted {len(results['ids'])} chunks from source: {source}")
            else:
                logger.info(f"No documents found for source: {source}")
                
        except Exception as e:
            logger.error(f"Failed to delete documents by source {source}: {str(e)}", exc_info=True)
            raise VectorStoreError(f"Failed to delete documents from source: {str(e)}") from e
    
    @log_exception
    def similarity_search(self, query: str, k: int = 3) -> List[Document]:
        """
        Retrieve the most relevant document chunks for a query.
        
        Args:
            query: The search query text
            k: Number of top results to return (default: 3)
            
        Returns:
            List of Document objects containing the most relevant chunks
            
        Raises:
            VectorStoreError: If vector store is not initialized or search fails
        """
        if self.vectorstore is None:
            raise VectorStoreError("Vector store not initialized. Call initialize() first.")
        
        if not query or not query.strip():
            logger.warning("Empty query provided to similarity_search")
            return []
        
        try:
            # Perform similarity search
            results = self.vectorstore.similarity_search(query, k=k)
            
            logger.info(f"Retrieved {len(results)} relevant chunks for query")
            return results
            
        except Exception as e:
            logger.error(f"Failed to perform similarity search: {str(e)}", exc_info=True)
            raise VectorStoreError(f"Failed to search documents: {str(e)}") from e
    
    def get_document_count(self) -> int:
        """
        Get the total number of document chunks in the vector store.
        
        Returns:
            Total count of document chunks
        """
        if self.vectorstore is None:
            return 0
        
        try:
            collection = self.vectorstore._collection
            return collection.count()
        except Exception as e:
            logger.error(f"Failed to get document count: {str(e)}")
            return 0

    def cleanup(self) -> None:
        """
        Cleanup resources and release file handles.
        """
        try:
            if self.vectorstore:
                self.vectorstore = None
            
            if self.client:
                self.client = None
                
            import gc
            gc.collect()
            
        except Exception as e:
            logger.error(f"Error during cleanup: {str(e)}")
