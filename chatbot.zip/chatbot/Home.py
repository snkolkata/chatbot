"""
RAG Chatbot - Main Application Entry Point

This is the main Streamlit application that provides a chat interface for users
to interact with the RAG-based chatbot system.
"""

import streamlit as st
import logging
from datetime import datetime
from typing import Dict, List

from config.settings import settings
from services.vector_store import VectorStoreManager
from services.rag_service import RAGService
from services.document_service import DocumentService
from services.session_service import SessionService
from services.database_manager import DatabaseManager
from utils.auth_guard import require_auth, get_current_user_email, get_current_user_id, logout
from utils.helpers import (
    setup_logging,
    format_error_message,
    ValidationError,
    VectorStoreError,
    LLMError
)
from utils.styles import inject_custom_css

# Configure logging
setup_logging('logs/app.log', logging.INFO)

logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="RAG Chatbot",
    page_icon="💬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Inject custom CSS
inject_custom_css()


def initialize_services():
    """
    Initialize RAG services and store in session state.
    
    Returns:
        Tuple of (rag_service, document_service, initialization_success)
    """
    try:
        # Initialize database first
        try:
            DatabaseManager.initialize()
            logger.info("Database initialized successfully")
            # Ensure tables exist (required for in-memory SQLite)
            try:
                DatabaseManager.create_tables()
                logger.info("Database tables ensured/created successfully")
            except Exception as table_error:
                logger.error(f"Creating tables failed: {str(table_error)}")
        except Exception as db_error:
            logger.error(f"Database initialization failed: {str(db_error)}")
            # Continue anyway - database might already be initialized
        
        # Validate settings
        settings.validate()
        
        # Initialize vector store
        vector_store = VectorStoreManager(
            persist_directory=settings.VECTOR_STORE_PATH
        )
        vector_store.initialize()
        
        # Initialize RAG service
        rag_service = RAGService(vector_store=vector_store)
        
        # Initialize document service
        document_service = DocumentService(vector_store=vector_store)
        
        logger.info("Services initialized successfully")
        return rag_service, document_service, True
        
    except Exception as e:
        logger.error(f"Failed to initialize services: {str(e)}")
        return None, None, False


def initialize_session_state():
    """Initialize Streamlit session state variables."""
    # Initialize messages list for conversation history
    if 'messages' not in st.session_state:
        st.session_state.messages = []
    
    # Initialize services
    if 'rag_service' not in st.session_state:
        rag_service, document_service, success = initialize_services()
        st.session_state.rag_service = rag_service
        st.session_state.document_service = document_service
        st.session_state.services_initialized = success
    
    # Initialize error state
    if 'last_error' not in st.session_state:
        st.session_state.last_error = None
    
    # Initialize current session ID
    if 'current_session_id' not in st.session_state:
        st.session_state.current_session_id = None
    
    # Initialize session list
    if 'user_sessions' not in st.session_state:
        st.session_state.user_sessions = []


def display_sidebar():
    """Display sidebar with system status and controls."""
    with st.sidebar:
        st.title("💬 RAG Chatbot")
        st.markdown("---")
        
        # User information
        st.subheader("👤 User Info")
        user_email = get_current_user_email()
        user_role = st.session_state.get('role', 'user')
        
        st.write(f"**Email:** {user_email}")
        st.write(f"**Role:** {user_role.capitalize()}")
        
        # Logout button
        if st.button("🚪 Logout", use_container_width=True):
            logout()
            st.success("Logged out successfully!")
            st.switch_page("pages/Login.py")
        
        st.markdown("---")
        
        # Session Management
        st.subheader("💬 Chat Sessions")
        
        # New Chat button
        if st.button("➕ New Chat", use_container_width=True):
            user_id = get_current_user_id()
            try:
                new_session_id = SessionService.create_session(user_id, "New Chat")
                if new_session_id:
                    st.session_state.current_session_id = new_session_id
                    st.session_state.messages = []
                    st.session_state.last_error = None
                    # Refresh session list
                    st.session_state.user_sessions = SessionService.get_user_sessions(user_id)
                    st.success("New chat session created!")
                    st.rerun()
                else:
                    st.error("Failed to create new session")
            except Exception as e:
                logger.error(f"Error creating new session: {str(e)}")
                st.error("Failed to create new session")
        
        # Load user sessions
        user_id = get_current_user_id()
        try:
            st.session_state.user_sessions = SessionService.get_user_sessions(user_id)
        except Exception as e:
            logger.error(f"Error loading sessions: {str(e)}")
            st.session_state.user_sessions = []
        
        # Session selector
        if st.session_state.user_sessions:
            # Create options for selectbox
            session_options = {}
            for session in st.session_state.user_sessions:
                session_id = session['session_id']
                title = session['title']
                message_count = session['message_count']
                updated_at = session['updated_at'].strftime("%Y-%m-%d %H:%M")
                label = f"{title} ({message_count} msgs) - {updated_at}"
                session_options[label] = session_id
            
            # Find current selection
            current_label = None
            if st.session_state.current_session_id:
                for label, sid in session_options.items():
                    if sid == st.session_state.current_session_id:
                        current_label = label
                        break
            
            # Session selector dropdown
            selected_label = st.selectbox(
                "Select Session",
                options=list(session_options.keys()),
                index=list(session_options.keys()).index(current_label) if current_label else 0,
                key="session_selector"
            )
            
            selected_session_id = session_options[selected_label]
            
            # If selection changed, switch session
            if selected_session_id != st.session_state.current_session_id:
                st.session_state.current_session_id = selected_session_id
                # Load messages for this session
                try:
                    messages = SessionService.get_session_messages(selected_session_id)
                    st.session_state.messages = messages
                    SessionService.set_active_session(user_id, selected_session_id)
                    st.rerun()
                except Exception as e:
                    logger.error(f"Error loading session messages: {str(e)}")
                    st.error("Failed to load session messages")
            
            # Session title editor
            st.markdown("**Edit Session Title:**")
            current_session = next((s for s in st.session_state.user_sessions if s['session_id'] == st.session_state.current_session_id), None)
            if current_session:
                new_title = st.text_input(
                    "Title",
                    value=current_session['title'],
                    key="session_title_input",
                    label_visibility="collapsed"
                )
                
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("💾 Save", use_container_width=True):
                        if new_title and new_title != current_session['title']:
                            try:
                                if SessionService.update_session_title(st.session_state.current_session_id, new_title):
                                    st.session_state.user_sessions = SessionService.get_user_sessions(user_id)
                                    st.success("Title updated!")
                                    st.rerun()
                                else:
                                    st.error("Failed to update title")
                            except Exception as e:
                                logger.error(f"Error updating session title: {str(e)}")
                                st.error("Failed to update title")
                
                with col2:
                    if st.button("🗑️ Delete", use_container_width=True):
                        try:
                            if SessionService.delete_session(st.session_state.current_session_id):
                                st.session_state.current_session_id = None
                                st.session_state.messages = []
                                st.session_state.user_sessions = SessionService.get_user_sessions(user_id)
                                st.success("Session deleted!")
                                st.rerun()
                            else:
                                st.error("Failed to delete session")
                        except Exception as e:
                            logger.error(f"Error deleting session: {str(e)}")
                            st.error("Failed to delete session")
        
        st.markdown("---")
        
        # System status
        st.subheader("System Status")
        
        if st.session_state.services_initialized:
            st.success("✅ System Ready")
            
            # Get document statistics
            try:
                if st.session_state.document_service:
                    stats = st.session_state.document_service.get_document_stats()
                    st.metric("Documents", stats['total_documents'])
                    st.metric("Total Chunks", stats['total_chunks'])
            except Exception as e:
                logger.error(f"Failed to get document stats: {str(e)}")
                st.warning("Unable to load document statistics")
        else:
            st.error("❌ System Error")
            st.error("Failed to initialize services. Please check your configuration.")
        
        st.markdown("---")
        
        # Information
        st.subheader("About")
        st.info(
            "This chatbot uses Retrieval-Augmented Generation (RAG) to answer "
            "questions based on uploaded documents. Upload documents via the "
            "Admin page to expand the knowledge base."
        )


def show_typing_indicator():
    """Display animated typing indicator."""
    return st.markdown("""
        <div class="typing-indicator">
            <span></span>
            <span></span>
            <span></span>
        </div>
    """, unsafe_allow_html=True)


def display_response_animated(text: str, placeholder):
    """
    Display response with smooth typing animation.
    
    Args:
        text: The text to display
        placeholder: Streamlit placeholder to update
    """
    import time
    
    # For long responses, show chunks instead of character by character
    chunk_size = 10
    displayed_text = ""
    
    for i in range(0, len(text), chunk_size):
        displayed_text = text[:i + chunk_size]
        placeholder.markdown(displayed_text)
        time.sleep(0.02)  # Small delay for typing effect
    
    # Ensure full text is displayed
    placeholder.markdown(text)


def display_chat_messages():
    """Display conversation history with visual distinction between roles."""
    for message in st.session_state.messages:
        role = message['role']
        content = message['content']
        
        # Get timestamp - handle both string and datetime formats
        timestamp = message.get('timestamp', message.get('created_at', ''))
        if hasattr(timestamp, 'strftime'):
            timestamp = timestamp.strftime("%Y-%m-%d %H:%M:%S")
        
        sources = message.get('sources', [])
        
        # Display message with appropriate avatar and styling
        avatar = "👤" if role == "user" else "🤖"
        with st.chat_message(role, avatar=avatar):
            st.markdown(content)
            
            # Display sources if available (for assistant messages)
            if sources and role == "assistant":
                if isinstance(sources, list) and len(sources) > 0:
                    # Handle both string sources and dict sources
                    source_names = []
                    for source in sources:
                        if isinstance(source, dict):
                            source_names.append(source.get('source', 'Unknown'))
                        else:
                            source_names.append(str(source))
                    if source_names:
                        st.caption(f"📚 Sources: {', '.join(source_names)}")
            
            # Display timestamp
            if timestamp:
                st.caption(f"_{timestamp}_")


def handle_user_input():
    """Handle user input and generate chatbot response."""
    # Chat input at the bottom
    user_input = st.chat_input("Ask me anything about your documents...")
    
    if user_input:
        # Validate that services are initialized
        if not st.session_state.services_initialized:
            st.error("System is not properly initialized. Please check your configuration.")
            return
        
        # Ensure we have a current session
        if not st.session_state.current_session_id:
            st.error("No active chat session. Please create a new chat.")
            return
        
        # Add user message to conversation history
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Save user message to database
        try:
            message_id = SessionService.add_message(
                st.session_state.current_session_id,
                'user',
                user_input
            )
            if not message_id:
                st.error("Failed to save message")
                return
        except Exception as e:
            logger.error(f"Error saving user message: {str(e)}")
            st.error("Failed to save message")
            return
        
        # Add to session state for display
        st.session_state.messages.append({
            'role': 'user',
            'content': user_input,
            'timestamp': timestamp
        })
        
        # Display user message immediately
        with st.chat_message("user"):
            st.markdown(user_input)
            st.caption(f"_{timestamp}_")
        
        # Generate response
        try:
            with st.chat_message("assistant", avatar="🤖"):
                # Show typing indicator
                typing_placeholder = st.empty()
                typing_placeholder.markdown("""
                    <div class="typing-indicator">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                """, unsafe_allow_html=True)
                
                # Get chat history for context (last 10 messages, excluding current)
                chat_history = []
                try:
                    if st.session_state.current_session_id:
                        chat_history = SessionService.get_session_context(
                            st.session_state.current_session_id,
                            max_messages=10
                        )
                except Exception as e:
                    logger.warning(f"Failed to get chat history: {str(e)}")
                    chat_history = []
                
                # Call RAG service with chat history
                result = st.session_state.rag_service.query(user_input, chat_history=chat_history)
                response = result['response']
                sources = result.get('sources', [])
                
                # Clear typing indicator and display response with animation
                typing_placeholder.empty()
                response_placeholder = st.empty()
                display_response_animated(response, response_placeholder)
                
                # Display sources if available
                if sources:
                    st.caption(f"📚 Sources: {', '.join(sources)}")
                
                response_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                st.caption(f"_{response_timestamp}_")
            
            # Save assistant message to database
            try:
                # Convert sources list to proper format for database
                sources_data = [{"source": source} for source in sources] if sources else None
                
                assistant_message_id = SessionService.add_message(
                    st.session_state.current_session_id,
                    'assistant',
                    response,
                    sources_data
                )
                if not assistant_message_id:
                    logger.warning("Failed to save assistant message to database")
            except Exception as e:
                logger.error(f"Error saving assistant message: {str(e)}")
            
            # Add assistant message to conversation history
            st.session_state.messages.append({
                'role': 'assistant',
                'content': response,
                'timestamp': response_timestamp,
                'sources': sources
            })
            
            # Clear any previous errors
            st.session_state.last_error = None
            
        except ValidationError as e:
            # Handle validation errors
            error_msg = format_error_message(e, user_friendly=True)
            logger.error(f"Validation error: {str(e)}")
            st.error(error_msg)
            st.session_state.last_error = str(e)
            
        except VectorStoreError as e:
            # Handle vector store errors
            error_msg = format_error_message(e, user_friendly=True)
            logger.error(f"Vector store error: {str(e)}")
            st.error(error_msg)
            st.session_state.last_error = str(e)
            
        except LLMError as e:
            # Handle LLM errors
            error_msg = format_error_message(e, user_friendly=True)
            logger.error(f"LLM error: {str(e)}")
            st.error(error_msg)
            st.session_state.last_error = str(e)
            
        except Exception as e:
            # Handle unexpected errors
            error_msg = format_error_message(e, user_friendly=True)
            logger.error(f"Unexpected error processing query: {str(e)}", exc_info=True)
            st.error(error_msg)
            st.session_state.last_error = str(e)


@require_auth
def main():
    """Main application function."""
    # Initialize session state
    initialize_session_state()
    
    # Ensure user has an active session
    user_id = get_current_user_id()
    if not st.session_state.current_session_id:
        # Try to get or create a session
        try:
            active_session = SessionService.get_active_session(user_id)
            if active_session:
                st.session_state.current_session_id = active_session['session_id']
                # Load messages for this session
                messages = SessionService.get_session_messages(active_session['session_id'])
                st.session_state.messages = messages
            else:
                # Create a new session
                new_session_id = SessionService.create_session(user_id, "New Chat")
                if new_session_id:
                    st.session_state.current_session_id = new_session_id
                    st.session_state.messages = []
        except Exception as e:
            logger.error(f"Error initializing session: {str(e)}")
            st.error("Failed to initialize chat session")
    
    # Display sidebar
    display_sidebar()
    
    # Main content area
    st.title("💬 Chat with Your Documents")
    
    # Display error if services failed to initialize
    if not st.session_state.services_initialized:
        st.error(
            "⚠️ Failed to initialize the chatbot system. "
            "Please ensure your OpenAI API key is configured in the .env file."
        )
        st.info(
            "To set up the system:\n"
            "1. Copy `.env.example` to `.env`\n"
            "2. Add your OpenAI API key\n"
            "3. Restart the application"
        )
        return
    
    # Display welcome message if no conversation history
    if not st.session_state.messages:
        st.info(
            "👋 Welcome! I'm your RAG-powered assistant. "
            "Ask me questions about the documents in the knowledge base. "
            "If you haven't uploaded any documents yet, visit the Admin page to get started."
        )
    
    # Display conversation history
    display_chat_messages()
    
    # Handle user input
    handle_user_input()


if __name__ == "__main__":
    # Ensure logs directory exists
    import os
    os.makedirs('logs', exist_ok=True)
    
    # Run the application
    main()
