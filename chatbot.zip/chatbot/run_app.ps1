# Set environment variables for this session
$env:GEMINI_API_KEY = "AIzaSyBAmt8ikQUvsGnBdKPy2WE2_ISoidiwaDw"
$env:GOOGLE_API_KEY = "AIzaSyBAmt8ikQUvsGnBdKPy2WE2_ISoidiwaDw"

Write-Host "Environment variables set successfully!" -ForegroundColor Green
Write-Host "GEMINI_API_KEY: $($env:GEMINI_API_KEY.Substring(0,20))..." -ForegroundColor Cyan
Write-Host "GOOGLE_API_KEY: $($env:GOOGLE_API_KEY.Substring(0,20))..." -ForegroundColor Cyan
Write-Host ""
Write-Host "Starting Streamlit app..." -ForegroundColor Yellow
Write-Host ""

# Run Streamlit
python -m streamlit run Home.py
