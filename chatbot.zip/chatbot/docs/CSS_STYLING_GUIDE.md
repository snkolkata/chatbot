# CSS Styling Guide

## Overview

This document describes the custom CSS styling system implemented for the RAG Chatbot application. All styles are centralized in `utils/styles.py` for easy maintenance and consistency across all pages.

## Architecture

### Centralized Styling

All CSS styles are defined in a single module (`utils/styles.py`) that provides:
- **`get_custom_css()`**: Returns the complete CSS as a string
- **`inject_custom_css()`**: Injects the CSS into a Streamlit page

### Usage

To apply custom styling to any page:

```python
from utils.styles import inject_custom_css

def main():
    # Inject custom CSS at the start of your page
    inject_custom_css()
    
    # Rest of your page code...
```

## Style Categories

### 1. Global Styles

**Features:**
- Smooth transitions for all elements (0.3s ease)
- Custom scrollbar styling with rounded corners
- Consistent color scheme based on purple gradient (#667eea to #764ba2)

### 2. Authentication Pages

**Applies to:** Login, Register, Password Reset pages

**Features:**
- Rounded form inputs with focus states
- Gradient button styling with hover effects
- Consistent spacing and padding
- Form validation visual feedback

**Key Classes:**
- `.auth-container`: Main form container with gradient background
- `.stTextInput`: Styled input fields with focus effects
- `.stButton`: Enhanced button styling with hover animations

### 3. Password Strength Indicator

**Features:**
- Real-time visual feedback
- Color-coded strength levels (red/orange/yellow/green)
- Smooth progress bar animation
- Requirements checklist

**Strength Levels:**
- **Weak** (< 40%): Red (#dc3545)
- **Fair** (40-69%): Orange (#fd7e14)
- **Good** (70-89%): Yellow (#ffc107)
- **Strong** (90-100%): Green (#28a745)

**Key Classes:**
- `.password-strength-container`: Main container
- `.password-strength-bar`: Progress bar background
- `.password-strength-fill`: Animated fill with color transitions

### 4. Typing Indicator Animation

**Features:**
- Three-dot bouncing animation
- Smooth ease-in-out timing
- Staggered animation delays for natural effect

**Key Classes:**
- `.typing-indicator`: Container for the animation
- Animation: `typing-bounce` (1.4s infinite)

**Usage:**
```html
<div class="typing-indicator">
    <span></span>
    <span></span>
    <span></span>
</div>
```

### 5. Chat UI Enhancements

**Features:**
- Fade-in animation for new messages
- Gradient avatars for user and assistant
- Styled message timestamps
- Source citations with left border accent

**Key Classes:**
- `.stChatMessage`: Message container with fade-in
- `.message-timestamp`: Styled timestamp display
- `.message-sources`: Source citation container

**Animations:**
- `message-fade-in`: 0.3s ease-in from bottom

### 6. Session Selector

**Features:**
- Hover effects with slide animation
- Active session highlighting
- Gradient background for selected items
- Smooth transitions

**Key Classes:**
- `.session-selector-container`: Main container
- `.session-item`: Individual session item
- `.session-item.active`: Active session styling

**Hover Effects:**
- Background color change
- Left border color accent
- Slide-right transform (5px)

### 7. Admin Dashboard

#### Tab Styling

**Features:**
- Rounded tabs with hover effects
- Gradient background for active tab
- Smooth transitions between tabs

**Key Classes:**
- `.stTabs [data-baseweb="tab"]`: Individual tab styling
- `.stTabs [aria-selected="true"]`: Active tab with gradient

#### Table Styling

**Features:**
- Card-based row design
- Hover elevation effect
- Rounded corners and shadows
- Responsive layout

**Key Classes:**
- `.admin-table-row`: Individual table row
- `.admin-table-header`: Table header styling

#### Metric Cards

**Features:**
- Large, prominent value display
- Color-coded delta indicators
- Hover elevation effect
- Responsive sizing

**Key Classes:**
- `.metric-card`: Main card container
- `.metric-value`: Large number display
- `.metric-delta`: Change indicator

#### Status Badges

**Features:**
- Color-coded status indicators
- Rounded pill design
- Uppercase text with letter spacing

**Status Types:**
- **Success**: Green (#d4edda)
- **Warning**: Yellow (#fff3cd)
- **Error**: Red (#f8d7da)
- **Info**: Blue (#d1ecf1)

### 8. Charts and Visualizations

**Features:**
- White background with shadow
- Rounded corners
- Consistent padding
- Title styling

**Key Classes:**
- `.chart-container`: Main chart wrapper
- `.chart-title`: Chart title styling

### 9. Alerts and Notifications

**Features:**
- Slide-in animation from left
- Color-coded left border
- Rounded corners
- Consistent padding

**Animation:**
- `alert-slide-in`: 0.3s ease from left

### 10. Responsive Design

#### Breakpoints

**Tablet (≤ 768px):**
- Reduced padding on containers
- Full-width buttons
- Stacked columns
- Adjusted metric card spacing

**Mobile (≤ 480px):**
- Further reduced padding
- Smaller font sizes
- Compact button styling
- Smaller typing indicator dots
- Compact tab styling

#### Responsive Features

- Flexible grid layouts
- Stacked columns on mobile
- Touch-friendly button sizes
- Optimized spacing for small screens

### 11. Loading States

**Features:**
- Spinning loader animation
- Consistent color scheme
- Smooth rotation

**Key Classes:**
- `.loading-spinner`: Animated spinner
- Animation: `spinner-rotate` (1s linear infinite)

### 12. Accessibility

**Features:**
- Focus indicators with outline
- High contrast mode support
- Reduced motion support
- Keyboard navigation friendly

**Accessibility Enhancements:**
- 3px focus outline with offset
- High contrast borders in high contrast mode
- Minimal animations for reduced motion preference
- Semantic HTML structure

## Color Palette

### Primary Colors

- **Primary Gradient**: #667eea → #764ba2
- **Secondary Gradient**: #f093fb → #f5576c

### Status Colors

- **Success**: #28a745
- **Warning**: #ffc107
- **Error**: #dc3545
- **Info**: #17a2b8

### Neutral Colors

- **Text Primary**: #333
- **Text Secondary**: #666
- **Text Muted**: #888
- **Background**: #f8f9fa
- **Border**: #e0e0e0

## Animation Timing

### Standard Transitions

- **Default**: 0.3s ease
- **Quick**: 0.2s ease
- **Slow**: 0.5s ease

### Keyframe Animations

- **Typing Bounce**: 1.4s infinite ease-in-out
- **Spinner Rotate**: 1s linear infinite
- **Fade In**: 0.3s ease-in
- **Slide In**: 0.3s ease
- **Pulse**: 2s cubic-bezier infinite

## Best Practices

### 1. Consistency

- Always use the centralized CSS module
- Don't add inline styles in individual pages
- Use predefined classes and animations

### 2. Performance

- CSS is injected once per page load
- Animations use GPU-accelerated properties (transform, opacity)
- Reduced motion support for accessibility

### 3. Maintainability

- All styles in one location
- Well-organized with clear sections
- Comprehensive comments
- Semantic class names

### 4. Responsiveness

- Mobile-first approach
- Test on multiple screen sizes
- Use relative units (rem, %, vh/vw)
- Flexible layouts with flexbox/grid

### 5. Accessibility

- Sufficient color contrast
- Focus indicators on all interactive elements
- Support for reduced motion
- Support for high contrast mode

## Customization

### Changing Colors

To change the primary color scheme, update these values in `utils/styles.py`:

```css
/* Primary gradient */
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

/* Update all instances of #667eea and #764ba2 */
```

### Adding New Styles

1. Add new CSS to the appropriate section in `get_custom_css()`
2. Follow the existing naming conventions
3. Add comments to describe the purpose
4. Test on all screen sizes
5. Ensure accessibility compliance

### Modifying Animations

1. Locate the animation in the CSS
2. Adjust timing, easing, or keyframes
3. Test for smoothness and performance
4. Consider reduced motion preferences

## Testing

### Visual Testing

- Test on Chrome, Firefox, Safari, Edge
- Test on desktop, tablet, and mobile
- Test with different zoom levels
- Test in light and dark mode (if applicable)

### Accessibility Testing

- Test with keyboard navigation
- Test with screen readers
- Test with high contrast mode
- Test with reduced motion enabled

### Performance Testing

- Check for layout shifts
- Monitor animation performance
- Verify CSS file size
- Test on slower devices

## Troubleshooting

### Styles Not Applying

1. Ensure `inject_custom_css()` is called in the page
2. Check for Streamlit caching issues (clear cache)
3. Verify import statement is correct
4. Check browser console for errors

### Animation Issues

1. Check browser compatibility
2. Verify animation keyframes are defined
3. Test with reduced motion disabled
4. Check for conflicting styles

### Responsive Issues

1. Test at exact breakpoint widths
2. Check for hardcoded widths
3. Verify media queries are correct
4. Test with browser dev tools

## Future Enhancements

### Planned Features

- Dark mode support
- Theme customization system
- Additional animation presets
- More chart styling options
- Enhanced mobile gestures

### Considerations

- Performance optimization
- Bundle size reduction
- CSS-in-JS migration (if needed)
- Component-based styling system

## Resources

### Documentation

- [Streamlit Theming](https://docs.streamlit.io/library/advanced-features/theming)
- [CSS Animations](https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Animations)
- [Responsive Design](https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Responsive_Design)

### Tools

- [CSS Gradient Generator](https://cssgradient.io/)
- [Color Contrast Checker](https://webaim.org/resources/contrastchecker/)
- [Animation Timing Functions](https://cubic-bezier.com/)

## Conclusion

The centralized CSS styling system provides a consistent, maintainable, and accessible design across the entire RAG Chatbot application. By following the guidelines in this document, developers can ensure a cohesive user experience while maintaining code quality and performance.
