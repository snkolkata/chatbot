# Quick Start Guide

## ✅ Issue RESOLVED - Document Upload Working!

### Start the App
```powershell
.\run_app.ps1
```

The app will be available at: **http://localhost:8501**

### Stop the App
Press `Ctrl+C` in the terminal running the app

### Test Results
✅ Document successfully uploaded: "NIPS-2017-attention-is-all-you-need-Paper.pdf"
✅ 43 chunks created and embedded
✅ Vector store working correctly
✅ API key validated and functional

### What Was Fixed
The Google API key wasn't being loaded correctly due to a system environment variable conflict. The fix ensures the correct API key from `.env` is used.

### For Permanent Solution
Remove old system environment variables:
1. Press `Win + R` → type `sysdm.cpl`
2. Advanced → Environment Variables
3. Delete `GEMINI_API_KEY` and `GOOGLE_API_KEY` from system variables
4. Restart terminal

Then you can run normally:
```powershell
python -m streamlit run Home.py
```

### Need Help?
- See `FIX_API_KEY.md` for detailed troubleshooting
- See `TASK_COMPLETED.md` for complete solution summary
- Run `python test_api_key_fix.py` to verify configuration
