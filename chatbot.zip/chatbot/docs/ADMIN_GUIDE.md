# RAG Chatbot Administrator Guide

This guide provides comprehensive information for administrators managing the RAG Chatbot system, including user management, session monitoring, system administration, and troubleshooting.

## Table of Contents

1. [Administrator Overview](#administrator-overview)
2. [Accessing the Admin Dashboard](#accessing-the-admin-dashboard)
3. [User Management](#user-management)
4. [Session Analytics](#session-analytics)
5. [Session Viewing and Export](#session-viewing-and-export)
6. [Document Management](#document-management)
7. [System Monitoring](#system-monitoring)
8. [Security and Best Practices](#security-and-best-practices)
9. [Troubleshooting](#troubleshooting)
10. [Maintenance Tasks](#maintenance-tasks)

---

## Administrator Overview

### What is an Administrator?

Administrators have elevated privileges in the RAG Chatbot system, allowing them to:

- Manage user accounts (create, modify, delete)
- Change user roles and permissions
- View all user chat sessions
- Monitor system analytics and usage
- Manage the document knowledge base
- Access system monitoring tools
- Export chat logs and data

### Administrator Responsibilities

As an administrator, you are responsible for:

1. **User Management**: Creating accounts, managing roles, handling access issues
2. **Content Management**: Uploading and maintaining the document knowledge base
3. **System Monitoring**: Ensuring the system is healthy and performing well
4. **Security**: Protecting user data and maintaining system security
5. **Support**: Helping users with issues and questions
6. **Compliance**: Ensuring proper data handling and privacy practices

---

## Accessing the Admin Dashboard

### Logging In as Administrator

1. Navigate to the login page
2. Enter your administrator credentials
3. Click "Login"
4. You'll be automatically redirected to the Admin Dashboard

**Note**: Only accounts with the "admin" role can access the Admin Dashboard.

### Admin Dashboard Layout

The Admin Dashboard is organized into tabs:


- **User Management**: Manage user accounts and roles
- **Session Analytics**: View usage statistics and trends
- **Document Management**: Upload and manage documents
- **System Monitoring**: Check system health and status

---

## User Management

The User Management tab provides comprehensive tools for managing user accounts.

### Viewing All Users

**User List Display**:
- Email address
- Full name
- Role (User or Admin)
- Account status (Active/Inactive)
- Registration date
- Last login timestamp

**Sorting and Filtering**:
- Search users by email address
- Filter by role (All, Users, Admins)
- Filter by status (All, Active, Inactive)
- Sort by registration date or last login

### Searching for Users

1. **Use the Search Box**
   - Enter an email address or partial email
   - Results update as you type
   - Search is case-insensitive

2. **Apply Filters**
   - Select role filter to show only users or admins
   - Select status filter to show only active or inactive accounts

### Changing User Roles

**To Promote a User to Admin**:

1. Locate the user in the user list
2. Find the "Role" dropdown for that user
3. Select "Admin" from the dropdown
4. Confirm the change when prompted
5. The user will have admin privileges on their next login

**To Demote an Admin to User**:

1. Locate the admin in the user list
2. Find the "Role" dropdown for that user
3. Select "User" from the dropdown
4. Confirm the change when prompted
5. The user will lose admin privileges immediately

**Important Considerations**:
- Role changes take effect immediately
- Users don't need to log out and back in
- Be careful not to demote yourself if you're the only admin
- Always maintain at least one active admin account

### Activating and Deactivating Users

**To Deactivate a User**:

1. Locate the user in the user list
2. Click the "Deactivate" button
3. Confirm the action when prompted
4. The user's account status changes to "Inactive"

**What Happens When a User is Deactivated**:
- User cannot log in
- Existing sessions are terminated
- Chat history is preserved
- Account can be reactivated later

**To Reactivate a User**:

1. Locate the inactive user in the user list
2. Click the "Activate" button
3. The user can now log in again
4. All previous data is intact

**Use Cases for Deactivation**:
- Temporary suspension for policy violations
- Employee on leave or sabbatical
- Pending investigation or review
- Soft deletion before permanent removal

### Deleting Users

**To Delete a User Account**:

1. Locate the user in the user list
2. Click the "Delete" button
3. Read the confirmation dialog carefully
4. Type the confirmation text if required
5. Click "Confirm Delete"

**What Happens When a User is Deleted**:
- User account is permanently removed
- All chat sessions are deleted (CASCADE)
- All chat messages are deleted (CASCADE)
- Password reset tokens are deleted
- This action CANNOT be undone

**Important Warnings**:
- Deletion is permanent and irreversible
- All user data is lost
- Consider deactivation instead if you might need the data later
- Export chat logs before deletion if needed for records
- You cannot delete your own account while logged in

**Best Practices**:
- Always export important data before deletion
- Verify you're deleting the correct user
- Document the reason for deletion
- Consider deactivation for temporary situations

### Creating New Users

While users typically register themselves, administrators can create accounts manually:

**Using the Admin Interface** (if available):
1. Click "Create User" button
2. Enter email, name, and temporary password
3. Select role (User or Admin)
4. Click "Create"
5. Provide the credentials to the user securely

**Using the Command Line**:
```bash
python scripts/create_admin.py --email user@example.com --name "User Name"
```

**After Creating an Account**:
- Provide the temporary password to the user securely
- Instruct them to change their password on first login
- Verify they can log in successfully

### Viewing User Details

Click on any user in the list to view detailed information:

- Full account information
- Login history
- Session count and activity
- Last active timestamp
- Account creation date
- Failed login attempts (if any)

---

## Session Analytics

The Session Analytics tab provides insights into system usage and user activity.

### Key Metrics Dashboard

**Overview Metrics**:
- **Total Users**: Total number of registered users
- **Active Users**: Users who logged in within the last 30 days
- **Total Sessions**: Total number of chat sessions created
- **Active Sessions**: Sessions with activity in the last 7 days
- **Total Messages**: Total messages across all sessions
- **Messages Today**: Messages sent in the last 24 hours

### Usage Trends

**Message Volume Chart**:
- Daily message count over time
- Helps identify usage patterns
- Shows peak usage times
- Useful for capacity planning

**Session Activity**:
- New sessions created per day
- Average session duration
- Messages per session average
- User engagement metrics

### Most Active Users

**Top Users by Activity**:
- Ranked by message count
- Shows email and message count
- Helps identify power users
- Useful for understanding usage patterns

**Metrics Displayed**:
- User email
- Total messages sent
- Number of sessions
- Last active date
- Average messages per session

### Date Range Filtering

**Apply Custom Date Ranges**:
1. Select start date
2. Select end date
3. Click "Apply Filter"
4. All analytics update to show data for that period

**Common Date Ranges**:
- Last 7 days
- Last 30 days
- Last 90 days
- Custom range

### Exporting Analytics Data

**Export Options**:
- CSV format for spreadsheet analysis
- JSON format for programmatic access
- PDF reports for presentations

**To Export Data**:
1. Configure your desired date range and filters
2. Click "Export" button
3. Select format (CSV, JSON, or PDF)
4. Download the file

---

## Session Viewing and Export

Administrators can view and export all user chat sessions for support, monitoring, or compliance purposes.

### Viewing All Sessions

**Session List Display**:
- User email
- Session title
- Created date
- Last updated date
- Message count
- Active status

**Sorting and Filtering**:
- Sort by date, user, or activity
- Filter by user email
- Filter by date range
- Search by session title or content

### Viewing a Specific User's Sessions

**To View Sessions for a User**:

1. Navigate to the Session Viewer
2. Enter the user's email in the search box
3. Click "Search" or press Enter
4. All sessions for that user are displayed

**Session Details**:
- Session title and metadata
- Complete message history
- Timestamps for each message
- Source citations (if available)
- User and assistant messages clearly distinguished

### Viewing Session Messages

**To View Messages in a Session**:

1. Click on a session in the list
2. The message history loads in read-only mode
3. Scroll through the conversation
4. View timestamps and sources

**Message Display**:
- User messages on the right
- Assistant messages on the left
- Timestamps for each message
- Source documents referenced
- Message metadata (if available)

### Searching Within Sessions

**Search Capabilities**:
- Search by keyword across all sessions
- Search within a specific user's sessions
- Search by date range
- Search by session title

**To Perform a Search**:

1. Enter search terms in the search box
2. Select search scope (all sessions or specific user)
3. Click "Search"
4. Results show matching sessions with context

### Exporting Chat Logs

**Export Individual Sessions**:

1. Select the session you want to export
2. Click "Export Session"
3. Choose format:
   - **TXT**: Plain text format
   - **JSON**: Structured data format
   - **PDF**: Formatted document with timestamps
4. Download the file

**Export Multiple Sessions**:

1. Select multiple sessions using checkboxes
2. Click "Export Selected"
3. Choose format
4. Download as a ZIP file containing all sessions

**Export All Sessions for a User**:

1. Filter sessions by user email
2. Click "Export All for User"
3. Choose format
4. Download the complete export

**Export Format Examples**:

**TXT Format**:
```
Session: Product Documentation Q&A
User: john@example.com
Created: 2024-01-15 10:30:00

[2024-01-15 10:30:15] User: What are the system requirements?
[2024-01-15 10:30:18] Assistant: Based on the installation guide...

[2024-01-15 10:32:00] User: How do I install it?
[2024-01-15 10:32:05] Assistant: The installation process...
```

**JSON Format**:
```json
{
  "session_id": "uuid-here",
  "user_email": "john@example.com",
  "title": "Product Documentation Q&A",
  "created_at": "2024-01-15T10:30:00Z",
  "messages": [
    {
      "role": "user",
      "content": "What are the system requirements?",
      "timestamp": "2024-01-15T10:30:15Z"
    },
    {
      "role": "assistant",
      "content": "Based on the installation guide...",
      "timestamp": "2024-01-15T10:30:18Z",
      "sources": ["installation_guide.pdf"]
    }
  ]
}
```

### Privacy and Compliance Considerations

**When Viewing User Sessions**:
- Only view sessions when necessary for support or monitoring
- Document the reason for accessing user data
- Follow your organization's privacy policies
- Be aware of data protection regulations (GDPR, etc.)
- Inform users of monitoring policies in terms of service

**Data Retention**:
- Establish clear data retention policies
- Regularly review and archive old sessions
- Delete data when no longer needed
- Comply with user data deletion requests

---

## Document Management

The Document Management tab allows you to manage the knowledge base that powers the chatbot's responses.

### Viewing Documents

**Document List Display**:
- Document filename
- File type (PDF, TXT, DOCX)
- Upload date
- File size
- Number of chunks (text segments)
- Status (Processed, Processing, Error)

### Uploading Documents

**To Upload a New Document**:

1. Click "Upload Document" button
2. Select file(s) from your computer
3. Wait for upload and processing
4. Verify the document appears in the list

**Supported File Types**:
- PDF (`.pdf`)
- Text files (`.txt`)
- Microsoft Word (`.docx`)

**File Size Limits**:
- Default maximum: 10 MB per file
- Configurable in settings
- Large files take longer to process

**Processing Steps**:
1. File is uploaded to server
2. Text is extracted from the document
3. Text is split into chunks
4. Embeddings are generated for each chunk
5. Embeddings are stored in vector database
6. Document is marked as "Processed"

**Upload Best Practices**:
- Use descriptive filenames
- Ensure documents are text-readable (not scanned images)
- Upload high-quality, relevant documents
- Organize documents by topic or category
- Remove outdated documents regularly

### Deleting Documents

**To Delete a Document**:

1. Locate the document in the list
2. Click the "Delete" button
3. Confirm the deletion
4. The document and its embeddings are removed

**What Happens When a Document is Deleted**:
- File is removed from storage
- All embeddings are removed from vector database
- The chatbot can no longer reference this document
- Existing chat messages referencing it remain unchanged

**Important Notes**:
- Deletion is permanent
- Users will no longer get answers from this document
- Consider the impact before deleting
- Download a backup if you might need it later

### Document Statistics

**View Statistics**:
- Total number of documents
- Total storage used
- Total number of chunks/embeddings
- Average chunks per document
- Most referenced documents

### Troubleshooting Document Issues

**Document Won't Upload**:
- Check file size (must be under limit)
- Verify file type is supported
- Ensure file is not corrupted
- Check available disk space

**Document Processing Failed**:
- Check application logs for errors
- Verify the document contains readable text
- Try re-uploading the document
- Check if the file is password-protected

**Poor Quality Responses**:
- Upload more relevant documents
- Ensure documents are well-formatted
- Remove outdated or conflicting information
- Check document text quality

---

## System Monitoring

The System Monitoring tab provides real-time information about system health and performance.

### Database Status

**Connection Status**:
- ✅ Connected: Database is accessible
- ❌ Disconnected: Database connection failed
- ⚠️ Degraded: Connection issues or slow performance

**Database Metrics**:
- Active connections
- Connection pool usage
- Query performance
- Database size
- Table sizes

**Actions**:
- Test connection
- View connection details
- Check query logs

### Vector Store Status

**ChromaDB Status**:
- Connection status
- Number of collections
- Total embeddings stored
- Storage size
- Query performance

**Metrics**:
- Average query time
- Embeddings per document
- Storage utilization
- Index health

### System Health Indicators

**Overall System Health**:
- 🟢 Healthy: All systems operational
- 🟡 Warning: Minor issues detected
- 🔴 Critical: Major issues requiring attention

**Component Status**:
- Database: Connection and performance
- Vector Store: ChromaDB status
- LLM API: OpenAI/Gemini connectivity
- Email Service: SMTP status
- File Storage: Disk space and accessibility

### Error Logs

**Recent Errors**:
- Timestamp
- Error type
- Error message
- Affected component
- User (if applicable)

**Log Levels**:
- ERROR: Critical errors requiring attention
- WARNING: Potential issues
- INFO: General information
- DEBUG: Detailed debugging information

**Viewing Logs**:
1. Select log level filter
2. Select date range
3. Search by keyword
4. View detailed error information

**Exporting Logs**:
- Export logs for troubleshooting
- Share with technical support
- Archive for compliance

### Performance Metrics

**Response Times**:
- Average query response time
- Database query time
- Vector search time
- LLM response time

**Resource Usage**:
- CPU utilization
- Memory usage
- Disk space
- Network bandwidth

### System Alerts

**Configure Alerts**:
- Set thresholds for metrics
- Email notifications for issues
- Alert history and acknowledgment

**Common Alerts**:
- Database connection failures
- High error rates
- Slow response times
- Low disk space
- API rate limits exceeded

---

## Security and Best Practices

### Administrator Account Security

**Password Security**:
- Use a strong, unique password
- Change password regularly (every 90 days recommended)
- Never share your admin credentials
- Use a password manager

**Account Protection**:
- Enable two-factor authentication (if available)
- Log out when not in use
- Don't use admin account for regular chatting
- Monitor your account activity

### User Data Protection

**Privacy Principles**:
- Only access user data when necessary
- Document reasons for accessing user sessions
- Follow data minimization principles
- Respect user privacy

**Data Handling**:
- Encrypt sensitive data
- Use secure connections (HTTPS)
- Regularly backup data
- Implement data retention policies

### Access Control Best Practices

**Role Management**:
- Follow principle of least privilege
- Regularly review admin accounts
- Remove admin access when no longer needed
- Maintain at least two active admins

**User Account Management**:
- Deactivate accounts promptly when users leave
- Review inactive accounts regularly
- Enforce password policies
- Monitor for suspicious activity

### Security Monitoring

**Regular Checks**:
- Review failed login attempts
- Monitor for unusual activity patterns
- Check for unauthorized access attempts
- Review admin action logs

**Incident Response**:
- Have a plan for security incidents
- Know how to lock accounts quickly
- Document security events
- Report serious incidents promptly

### Compliance Considerations

**Data Protection Regulations**:
- GDPR (if applicable)
- CCPA (if applicable)
- Industry-specific regulations
- Organizational policies

**User Rights**:
- Right to access their data
- Right to data portability
- Right to deletion
- Right to rectification

**Documentation**:
- Maintain audit logs
- Document data processing activities
- Keep records of user consents
- Document security measures

---

## Troubleshooting

### Common Administrator Issues

#### Cannot Access Admin Dashboard

**Problem**: Login successful but can't access admin features.

**Solutions**:
- Verify your account has admin role
- Check with another administrator
- Review user management logs
- Contact system administrator

#### User Cannot Log In

**Problem**: User reports they cannot log in.

**Diagnosis**:
1. Check if account exists
2. Check if account is active
3. Check for account lockout
4. Verify password reset if needed

**Solutions**:
- Reactivate account if deactivated
- Unlock account if locked
- Reset password for user
- Check for system-wide login issues

#### Document Upload Failures

**Problem**: Documents fail to upload or process.

**Diagnosis**:
1. Check file size and type
2. Review error logs
3. Check disk space
4. Verify vector store connection

**Solutions**:
- Ensure file meets requirements
- Free up disk space if needed
- Restart vector store service
- Check application logs for details

#### Slow System Performance

**Problem**: System is slow or unresponsive.

**Diagnosis**:
1. Check system resource usage
2. Review database performance
3. Check vector store performance
4. Review recent changes

**Solutions**:
- Optimize database queries
- Clear old data if needed
- Restart services
- Scale resources if needed

#### Email Notifications Not Sending

**Problem**: Password reset emails not being delivered.

**Diagnosis**:
1. Check SMTP configuration
2. Test email service connection
3. Review email logs
4. Check spam filters

**Solutions**:
- Verify SMTP credentials
- Test with different email provider
- Check firewall settings
- Review email service status

### Getting Technical Support

**Before Contacting Support**:
1. Check application logs
2. Note exact error messages
3. Document steps to reproduce
4. Gather relevant screenshots

**Information to Provide**:
- Error messages and logs
- Steps to reproduce the issue
- When the issue started
- What changed recently
- System configuration details

---

## Maintenance Tasks

### Regular Maintenance Schedule

**Daily Tasks**:
- Monitor system health dashboard
- Review error logs
- Check for failed login attempts
- Verify backup completion

**Weekly Tasks**:
- Review user activity
- Check disk space usage
- Review and respond to user issues
- Update documents as needed

**Monthly Tasks**:
- Review user accounts (remove inactive)
- Analyze usage trends
- Review and update documentation
- Check for system updates
- Review security logs

**Quarterly Tasks**:
- Comprehensive security audit
- Review and update policies
- Clean up old data
- Performance optimization
- Disaster recovery testing

### Database Maintenance

**Regular Tasks**:
```bash
# Backup database
pg_dump rag_chatbot > backup_$(date +%Y%m%d).sql

# Vacuum database (optimize)
python scripts/db_cli.py vacuum

# Check database health
python scripts/db_cli.py health-check
```

**Backup Strategy**:
- Daily automated backups
- Weekly full backups
- Monthly archive backups
- Test restore procedures regularly

### Vector Store Maintenance

**Optimization**:
- Rebuild indexes periodically
- Remove orphaned embeddings
- Optimize storage
- Monitor performance

**Commands**:
```bash
# Check vector store health
python scripts/check_vector_store.py

# Rebuild indexes
python scripts/rebuild_indexes.py
```

### Log Management

**Log Rotation**:
- Rotate logs daily or weekly
- Compress old logs
- Archive logs for compliance
- Delete very old logs

**Log Analysis**:
- Review error patterns
- Identify performance issues
- Track usage trends
- Monitor security events

### System Updates

**Update Process**:
1. Review release notes
2. Test in staging environment
3. Schedule maintenance window
4. Backup all data
5. Apply updates
6. Test functionality
7. Monitor for issues

**Rollback Plan**:
- Keep previous version available
- Document rollback procedure
- Test rollback process
- Have backup ready

---

## Appendix

### Useful Commands

**Database Management**:
```bash
# Initialize database
python scripts/db_cli.py init

# Create admin user
python scripts/db_cli.py create-admin

# Check database status
python scripts/db_cli.py health-check

# Backup database
python scripts/db_cli.py backup

# Run migrations
python -m alembic upgrade head
```

**User Management**:
```bash
# Create admin user
python scripts/create_admin.py --email admin@example.com --name "Admin Name"

# Check user details
python scripts/db_cli.py user-info --email user@example.com
```

**System Checks**:
```bash
# Check all services
python scripts/check_database.py

# View logs
tail -f logs/app.log
```

### Configuration Reference

See the main README.md for complete configuration reference.

### Support Resources

- **Application Logs**: `logs/app.log`
- **Database Scripts**: `scripts/` directory
- **Documentation**: `docs/` directory
- **Configuration**: `.env` file

---

## Conclusion

As an administrator, you play a crucial role in maintaining a secure, efficient, and user-friendly RAG Chatbot system. This guide provides the foundation for effective system administration.

**Key Takeaways**:
- Regularly monitor system health and user activity
- Maintain security best practices
- Keep documentation and knowledge base up to date
- Respond promptly to user issues
- Perform regular maintenance tasks
- Stay informed about system updates

For technical issues or questions not covered in this guide, consult the application logs and system documentation, or contact technical support.

Thank you for administering the RAG Chatbot system! 🛡️
