# Gemini API Rate Limits Guide

## Free Tier Rate Limits (as of Nov 2024)

### Gemini 1.5 Flash (Recommended for Free Tier)
- **Requests per minute**: 15
- **Tokens per minute**: 1,000,000
- **Requests per day**: 1,500
- **Best for**: Development, testing, production with moderate traffic

### Gemini 1.5 Pro
- **Requests per minute**: 2
- **Tokens per minute**: 32,000
- **Requests per day**: 50
- **Best for**: Occasional high-quality responses, not for interactive apps

### Gemini 2.0 Flash Exp (Experimental)
- **Requests per minute**: 0 (quota exceeded immediately)
- **Status**: Very limited free tier access
- **Not recommended** for any production use

### Gemini 2.5 Pro
- **Requests per minute**: 2
- **Tokens per minute**: Limited
- **Requests per day**: Very limited
- **Not recommended** for interactive applications

## Current Configuration

Your app is now using: **Gemini 1.5 Flash**

This provides:
- ✅ 15 requests per minute (good for interactive chat)
- ✅ 1,500 requests per day (sufficient for development/testing)
- ✅ Fast response times
- ✅ Good quality responses

## Recommendations

### For Development/Testing
Use **Gemini 1.5 Flash** (current setting)
```env
LLM_MODEL=gemini-1.5-flash
```

### For Production with Low Traffic
Use **Gemini 1.5 Flash** with rate limiting in your app

### For Production with High Traffic
Consider:
1. Upgrading to paid tier
2. Implementing request queuing
3. Adding caching for common queries
4. Using OpenAI as alternative (requires paid API key)

## Monitoring Usage

Check your usage at: https://ai.dev/usage?tab=rate-limit

## Error Messages

### 429 Quota Exceeded
**Cause**: Too many requests in short time period
**Solution**: 
- Wait for rate limit to reset (usually 1 minute)
- Switch to model with higher limits (Gemini 1.5 Flash)
- Implement rate limiting in your application

### API Key Invalid
**Cause**: API key not found or incorrect
**Solution**: Check `.env` file has correct `GOOGLE_API_KEY`

## Rate Limit Best Practices

1. **Cache responses** for common queries
2. **Implement retry logic** with exponential backoff
3. **Monitor usage** regularly
4. **Use appropriate model** for your use case
5. **Consider upgrading** to paid tier for production

---

**Current Status**: ✅ Using Gemini 1.5 Flash (15 RPM limit)
