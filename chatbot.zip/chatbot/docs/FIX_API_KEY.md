# API Key Issue - Root Cause and Solution

## Problem
You have an **old/invalid API key** set as a **Windows system environment variable** that's overriding your `.env` file.

## Evidence
- `.env` file has: `AIzaSyBAmt8ikQUvsGnBdKPy2WE2_ISoidiwaDw` (VALID ✓)
- System env var has: `AIzaSyA03ylPKgIN-PxW...` (INVALID ✗)
- The system environment variable takes precedence over `.env` file

## Solution - Remove the Old System Environment Variable

### Option 1: GUI Method (Permanent Fix)
1. Press `Win + R` and type: `sysdm.cpl`
2. Click "Advanced" tab → "Environment Variables" button
3. Look in both "User variables" and "System variables" sections
4. Find and DELETE these variables:
   - `GEMINI_API_KEY`
   - `GOOGLE_API_KEY`
5. Click OK to save
6. **Restart your terminal/IDE** for changes to take effect

### Option 2: PowerShell Method (Temporary - Current Session Only)
Run these commands in your PowerShell terminal:
```powershell
$env:GEMINI_API_KEY = "AIzaSyBAmt8ikQUvsGnBdKPy2WE2_ISoidiwaDw"
$env:GOOGLE_API_KEY = "AIzaSyBAmt8ikQUvsGnBdKPy2WE2_ISoidiwaDw"
```

Then run your Streamlit app in the SAME terminal window.

### Option 3: Quick Test Script
Create a batch file `run_app.bat`:
```batch
@echo off
set GEMINI_API_KEY=AIzaSyBAmt8ikQUvsGnBdKPy2WE2_ISoidiwaDw
set GOOGLE_API_KEY=AIzaSyBAmt8ikQUvsGnBdKPy2WE2_ISoidiwaDw
streamlit run Home.py
```

## Verification
After fixing, run this to verify:
```powershell
python test_api_key_fix.py
```

All tests should pass with ✓ marks.

## Why This Happened
- You likely set `GEMINI_API_KEY` as a system environment variable at some point
- That old key is now invalid or from a different project
- System environment variables override `.env` file values
- The `.env` file has the correct key, but it's being ignored

## Recommended Approach
**Use Option 1 (GUI Method)** to permanently remove the system environment variables, then rely on your `.env` file for configuration. This is cleaner and more portable.
