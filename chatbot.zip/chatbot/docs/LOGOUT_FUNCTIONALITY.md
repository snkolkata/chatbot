# Logout Functionality Documentation

## Overview

The logout functionality provides a secure way for users to end their authenticated session and clear all session data from the application.

## Implementation Details

### Core Functions

#### `logout()` - Main Logout Function
Located in `utils/auth_guard.py`

**Purpose**: Performs a complete logout operation including logging and session cleanup.

**Behavior**:
1. Logs the logout event with user email and ID
2. Calls `clear_session()` to remove all session data
3. Logs successful logout completion

**Usage**:
```python
from utils.auth_guard import logout

# In a Streamlit page
if st.button("Logout"):
    logout()
    st.success("Logged out successfully!")
    st.switch_page("pages/Login.py")
```

#### `clear_session()` - Session Data Cleanup
Located in `utils/auth_guard.py`

**Purpose**: Removes all authentication and application-related data from Streamlit session state.

**Keys Cleared**:
- Authentication data: `user_id`, `email`, `full_name`, `role`, `is_active`
- Session management: `last_activity`, `remember_me`, `authenticated`
- Chat data: `current_session_id`, `messages`, `user_sessions`
- Service instances: `rag_service`, `document_service`, `services_initialized`
- Admin data: `admin_document_service`, `admin_services_initialized`
- UI state: `upload_status`, `delete_confirm`, `last_error`

**Note**: Chat sessions and messages are persisted in the database and are NOT deleted during logout. Users can access their previous conversations when they log back in.

### Session Expiration Handling

The authentication guards (`require_auth` and `require_admin`) automatically check for session expiration on every page load:

1. **Session Timeout Check**: Validates that the session hasn't exceeded the configured timeout period
2. **Automatic Logout**: If session has expired, automatically calls `logout()` and redirects to login page
3. **User Notification**: Displays a message informing the user that their session has expired

**Configuration**:
- Default timeout: 24 hours (configurable via `SESSION_TIMEOUT_HOURS`)
- Remember me timeout: 7 days (configurable via `SESSION_REMEMBER_ME_DAYS`)

### Logout Button Locations

Logout buttons are available on all authenticated pages:

1. **Home Page** (`Home.py`):
   - Located in the sidebar
   - Visible to all authenticated users

2. **Admin Page** (`pages/Admin.py`):
   - Located in the sidebar
   - Visible to admin users

### Database Considerations

**No Database Cleanup Required**:
- Chat sessions remain in the database after logout
- Messages are preserved for future access
- User account data is unchanged
- Session management is handled entirely through Streamlit session state

**Rationale**:
- Users expect their chat history to persist across sessions
- Database sessions are managed by `updated_at` timestamps, not active/inactive flags
- No need for explicit session cleanup in the database

### Security Features

1. **Complete Session Clearing**: All sensitive data is removed from memory
2. **Logging**: All logout events are logged for audit purposes
3. **Automatic Expiration**: Sessions automatically expire after the configured timeout
4. **Deactivated Account Handling**: Deactivated accounts are automatically logged out

### Testing

Comprehensive tests are available in `tests/test_logout.py`:

- `test_logout_clears_session_data`: Verifies session data is cleared
- `test_logout_logs_user_email`: Verifies logging includes user information
- `test_clear_session_removes_all_keys`: Verifies all expected keys are removed
- `test_logout_handles_missing_user_data`: Verifies graceful handling of missing data
- `test_is_authenticated_after_logout`: Verifies authentication state after logout

**Run tests**:
```bash
python -m pytest tests/test_logout.py -v
```

## User Experience

### Normal Logout Flow

1. User clicks "🚪 Logout" button in sidebar
2. System logs the logout event
3. All session data is cleared
4. Success message is displayed
5. User is redirected to login page

### Session Expiration Flow

1. User attempts to access a protected page
2. System detects session has expired
3. Error message is displayed: "⏱️ Your session has expired. Please log in again."
4. Session is automatically cleared
5. User is redirected to login page

### Deactivated Account Flow

1. Admin deactivates a user account
2. User attempts to access a protected page
3. System detects account is deactivated
4. Error message is displayed: "🚫 Account Deactivated"
5. Session is automatically cleared
6. User cannot proceed

## Configuration

Logout behavior can be configured through environment variables:

```env
# Session timeout (hours)
SESSION_TIMEOUT_HOURS=24

# Remember me duration (days)
SESSION_REMEMBER_ME_DAYS=7
```

## Requirements Satisfied

This implementation satisfies all requirements from task 16:

✅ **Add logout function to clear session state** - `logout()` function implemented
✅ **Add logout button to all authenticated pages** - Buttons added to Home and Admin pages
✅ **Implement session cleanup in database** - Not required; sessions persist in database
✅ **Add redirect to login page after logout** - Implemented in all logout flows
✅ **Handle session expiration with automatic logout** - Implemented in auth guards

## Related Files

- `utils/auth_guard.py` - Core logout and session management functions
- `Home.py` - Home page with logout button
- `pages/Admin.py` - Admin page with logout button
- `tests/test_logout.py` - Comprehensive test suite
- `.kiro/specs/user-authentication-and-session-management/requirements.md` - Requirements 8.1-8.5
