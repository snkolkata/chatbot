# RAG Chatbot User Guide

Welcome to the RAG Chatbot! This guide will help you get started with using the application, from creating your account to managing your chat sessions.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Registration](#registration)
3. [Login](#login)
4. [Password Reset](#password-reset)
5. [Chat Interface](#chat-interface)
6. [Session Management](#session-management)
7. [Tips and Best Practices](#tips-and-best-practices)
8. [Troubleshooting](#troubleshooting)

---

## Getting Started

The RAG Chatbot is an AI-powered assistant that answers your questions based on documents uploaded to the system. To use the chatbot, you'll need to:

1. Create an account (or have one created for you by an administrator)
2. Log in to access the chat interface
3. Start asking questions!

---

## Registration

### Creating Your Account

1. **Navigate to the Registration Page**
   - Open the application in your web browser
   - If you're on the login page, click the "Don't have an account? Sign up" link

2. **Fill Out the Registration Form**
   - **Full Name**: Enter your full name (e.g., "John Smith")
   - **Email**: Enter a valid email address (e.g., "john.smith@example.com")
   - **Password**: Create a strong password
   - **Confirm Password**: Re-enter your password to confirm

3. **Password Requirements**
   
   Your password must meet the following criteria:
   - At least 8 characters long
   - Contains at least one uppercase letter (A-Z)
   - Contains at least one lowercase letter (a-z)
   - Contains at least one number (0-9)
   
   **Example of a strong password**: `MyPass123`

4. **Password Strength Indicator**
   
   As you type your password, a strength indicator will show you how secure your password is:
   - 🔴 **Weak**: Does not meet all requirements
   - 🟡 **Medium**: Meets basic requirements
   - 🟢 **Strong**: Meets all requirements with good complexity

5. **Accept Terms of Service**
   - Check the box to accept the terms of service

6. **Complete Registration**
   - Click the "Register" button
   - If successful, you'll see a success message
   - You'll be redirected to the login page

### Registration Errors

**"Email already registered"**
- This email is already in use
- Try logging in instead, or use a different email address
- If you forgot your password, use the password reset feature

**"Passwords do not match"**
- The password and confirmation password don't match
- Re-enter both fields carefully

**"Password does not meet requirements"**
- Your password doesn't meet the security requirements
- Review the password requirements above and try again

---

## Login

### Logging Into Your Account

1. **Navigate to the Login Page**
   - Open the application in your web browser
   - You'll see the login page by default

2. **Enter Your Credentials**
   - **Email**: Enter the email address you registered with
   - **Password**: Enter your password

3. **Remember Me (Optional)**
   - Check the "Remember me" box to stay logged in for 7 days
   - Without this option, your session will expire after 24 hours of inactivity

4. **Click Login**
   - Click the "Login" button to access the application
   - You'll be redirected to the chat interface

### Login Errors

**"Invalid email or password"**
- Your credentials are incorrect
- Double-check your email and password
- Remember that passwords are case-sensitive
- If you forgot your password, use the "Forgot password?" link

**"Account is locked"**
- Your account has been temporarily locked due to too many failed login attempts
- Wait 15 minutes and try again
- You should receive an email notification about the lockout
- If you continue to have issues, contact an administrator

**Security Note**: After 5 failed login attempts, your account will be locked for 15 minutes to protect against unauthorized access.

### Session Duration

- **Regular Login**: Your session lasts for 24 hours of inactivity
- **Remember Me**: Your session lasts for 7 days
- After the session expires, you'll need to log in again
- You can log out manually at any time using the logout button

---

## Password Reset

If you forget your password, you can reset it using the password reset feature.

### Step 1: Request Password Reset

1. **Navigate to Password Reset**
   - On the login page, click "Forgot password?"
   - You'll be taken to the password reset request page

2. **Enter Your Email**
   - Enter the email address associated with your account
   - Click "Send Reset Link"

3. **Check Your Email**
   - You'll receive an email with a password reset link
   - The email will arrive within a few minutes
   - Check your spam folder if you don't see it
   - The reset link is valid for 1 hour

**Note**: For security reasons, you'll see a success message even if the email doesn't exist in the system. This prevents attackers from discovering which emails are registered.

### Step 2: Reset Your Password

1. **Click the Reset Link**
   - Open the email and click the password reset link
   - You'll be taken to the password reset form

2. **Enter Your New Password**
   - **New Password**: Enter your new password
   - **Confirm Password**: Re-enter your new password
   - Make sure your password meets all requirements (see Registration section)

3. **Submit the Form**
   - Click "Reset Password"
   - If successful, you'll see a confirmation message
   - You'll be redirected to the login page

4. **Log In with New Password**
   - Use your new password to log in

### Password Reset Errors

**"Invalid or expired token"**
- The reset link has expired (links are valid for 1 hour)
- The link has already been used
- Request a new password reset link

**"Passwords do not match"**
- The password and confirmation don't match
- Re-enter both fields carefully

---

## Chat Interface

Once you're logged in, you'll see the main chat interface where you can interact with the AI assistant.

### Understanding the Interface

The chat interface consists of several key areas:

1. **Sidebar** (Left)
   - User information (your name and email)
   - Session selector dropdown
   - "New Chat" button
   - List of your previous sessions
   - Logout button

2. **Main Chat Area** (Center)
   - Chat history with messages
   - Message timestamps
   - User and assistant avatars
   - Source citations (when available)

3. **Input Area** (Bottom)
   - Text input field for your questions
   - Send button

### Asking Questions

1. **Type Your Question**
   - Click in the text input field at the bottom
   - Type your question or message
   - Be specific and clear for best results

2. **Send Your Message**
   - Press Enter or click the Send button
   - Your message will appear in the chat

3. **Wait for Response**
   - You'll see a typing indicator (animated dots) while the AI processes your question
   - The AI retrieves relevant information from the document knowledge base
   - A response will appear with a smooth typing animation

4. **Review the Response**
   - Read the AI's response
   - Check the source citations to see which documents were used
   - Each message shows a timestamp

### Understanding Responses

**Message Components**:
- **User Messages**: Your questions appear on the right with your avatar
- **Assistant Messages**: AI responses appear on the left with the assistant avatar
- **Timestamps**: Each message shows when it was sent
- **Sources**: When available, responses include citations showing which documents were referenced

**Response Quality**:
- Responses are based on the documents uploaded to the system
- The AI retrieves the most relevant information to answer your question
- If no relevant information is found, the AI will let you know
- You can rephrase your question or ask follow-up questions for clarification

### Tips for Better Responses

1. **Be Specific**: Ask clear, specific questions
   - ❌ "Tell me about the product"
   - ✅ "What are the key features of the product mentioned in the user manual?"

2. **Provide Context**: Reference specific topics or documents when relevant
   - ✅ "According to the installation guide, what are the system requirements?"

3. **Ask Follow-up Questions**: Build on previous responses
   - ✅ "Can you explain that in more detail?"
   - ✅ "What about the other option you mentioned?"

4. **Break Down Complex Questions**: Split complex queries into smaller questions
   - Instead of asking multiple things at once, ask them one at a time

---

## Session Management

Sessions help you organize your conversations by topic or purpose. Each session maintains its own chat history and context.

### Creating a New Session

1. **Click "New Chat"**
   - Find the "New Chat" button in the sidebar
   - Click it to create a new session

2. **Start Chatting**
   - Your new session is now active
   - The chat area will be empty
   - Start asking questions in your new session

### Switching Between Sessions

1. **View Your Sessions**
   - Look at the sidebar to see your list of sessions
   - Sessions are sorted by most recently updated

2. **Select a Session**
   - Click on any session in the list
   - Or use the session selector dropdown at the top
   - The chat area will load that session's history

3. **Continue the Conversation**
   - All previous messages in that session will be displayed
   - Continue asking questions in the context of that conversation

### Renaming Sessions

1. **Edit Session Title**
   - Find the session title at the top of the chat area
   - Click on the title to edit it
   - Enter a descriptive name (e.g., "Product Documentation Q&A")
   - Press Enter or click outside to save

2. **Why Rename Sessions?**
   - Makes it easier to find specific conversations later
   - Helps organize sessions by topic or project
   - Default titles are "New Chat" which isn't very descriptive

### Deleting Sessions

1. **Select the Session**
   - Switch to the session you want to delete

2. **Delete the Session**
   - Look for the delete button (usually near the session title)
   - Click the delete button
   - Confirm the deletion when prompted

3. **What Happens**
   - The session and all its messages are permanently deleted
   - You'll be switched to another session or a new session
   - This action cannot be undone

**Warning**: Deleting a session permanently removes all messages in that session. Make sure you don't need the conversation history before deleting.

### Session Best Practices

1. **Organize by Topic**
   - Create separate sessions for different topics or projects
   - Example: "HR Policies", "Technical Documentation", "Product Features"

2. **Use Descriptive Names**
   - Rename sessions with meaningful titles
   - Include dates or project names if relevant

3. **Clean Up Old Sessions**
   - Periodically delete sessions you no longer need
   - Keeps your session list manageable

4. **Leverage Context**
   - The AI remembers the conversation within a session
   - Use this to ask follow-up questions without repeating context
   - Start a new session when changing topics significantly

---

## Tips and Best Practices

### Getting the Most Out of the Chatbot

1. **Understand the Knowledge Base**
   - The AI can only answer questions based on uploaded documents
   - If you need information that's not in the documents, the AI won't be able to help
   - Contact an administrator to request additional documents be uploaded

2. **Use Natural Language**
   - You don't need to use special commands or syntax
   - Ask questions as you would to a human assistant
   - The AI understands context and conversational language

3. **Iterate and Refine**
   - If the first response isn't quite what you need, ask follow-up questions
   - Rephrase your question if the AI doesn't understand
   - Provide more context or be more specific

4. **Check Sources**
   - Review the source citations to verify information
   - Sources tell you which documents the information came from
   - This helps you assess the reliability and relevance of responses

5. **Maintain Context Within Sessions**
   - The AI remembers the conversation within a session
   - You can refer to previous messages: "Can you elaborate on that?"
   - Context is not shared between different sessions

### Security Best Practices

1. **Protect Your Password**
   - Use a strong, unique password
   - Don't share your password with others
   - Change your password if you suspect it's been compromised

2. **Log Out When Done**
   - Always log out when using a shared or public computer
   - Use the logout button in the sidebar

3. **Be Careful with "Remember Me"**
   - Only use "Remember me" on your personal devices
   - Don't use it on public or shared computers

4. **Report Issues**
   - If you notice suspicious activity on your account, contact an administrator
   - Report any security concerns immediately

---

## Troubleshooting

### Common Issues and Solutions

#### "No relevant information found"

**Problem**: The AI can't find information to answer your question.

**Solutions**:
- Rephrase your question using different words
- Make your question more specific
- Check if the information exists in the uploaded documents
- Contact an administrator to request relevant documents be added

#### Chat is slow or unresponsive

**Problem**: Messages take a long time to send or responses are delayed.

**Solutions**:
- Check your internet connection
- Refresh the page and try again
- The system may be processing a complex query - wait a moment
- If the problem persists, contact an administrator

#### Session history not loading

**Problem**: When you switch sessions, the messages don't appear.

**Solutions**:
- Refresh the page
- Log out and log back in
- Check your internet connection
- If the problem continues, contact an administrator

#### Can't create new sessions

**Problem**: The "New Chat" button doesn't work.

**Solutions**:
- Refresh the page
- Check if you've reached any session limits (unlikely)
- Log out and log back in
- Contact an administrator if the issue persists

#### Logged out unexpectedly

**Problem**: You're suddenly logged out while using the application.

**Possible Causes**:
- Your session expired (24 hours of inactivity, or 7 days with "Remember me")
- You logged in from another device or browser
- There was a system update or maintenance

**Solutions**:
- Simply log back in
- Use "Remember me" if you want longer sessions
- Save important information before long periods of inactivity

#### Password reset email not received

**Problem**: You requested a password reset but didn't receive the email.

**Solutions**:
- Check your spam/junk folder
- Wait a few minutes - emails can be delayed
- Verify you entered the correct email address
- Request another reset link
- Contact an administrator if you still don't receive it

### Getting Help

If you encounter issues not covered in this guide:

1. **Check the Application Logs**
   - Administrators can check logs for error details

2. **Contact an Administrator**
   - Provide details about the issue
   - Include what you were trying to do when the problem occurred
   - Mention any error messages you saw

3. **Try Basic Troubleshooting**
   - Refresh the page
   - Clear your browser cache
   - Try a different browser
   - Log out and log back in

---

## Frequently Asked Questions

### Can I use the chatbot on mobile devices?

Yes, the application is responsive and works on mobile browsers. However, the experience is optimized for desktop use.

### How long is my chat history stored?

Your chat history is stored indefinitely unless you delete sessions manually. All messages are securely stored in the database.

### Can other users see my chat sessions?

No, your chat sessions are private. Only you and administrators can view your sessions. Administrators may need to access sessions for support or monitoring purposes.

### Can I export my chat history?

Currently, users cannot export their own chat history. Contact an administrator if you need an export of your conversations.

### What happens if I forget to log out?

Your session will automatically expire after 24 hours of inactivity (or 7 days if you used "Remember me"). For security, always log out when using shared computers.

### Can I change my email address?

Currently, you cannot change your email address yourself. Contact an administrator if you need to update your email.

### How do I delete my account?

Contact an administrator to request account deletion. Note that this will permanently delete all your chat sessions and data.

---

## Conclusion

You're now ready to use the RAG Chatbot effectively! Remember:

- Keep your password secure
- Organize your sessions by topic
- Ask clear, specific questions
- Check source citations
- Log out when done on shared computers

If you have questions or need help, don't hesitate to contact an administrator.

Happy chatting! 🤖
