"""
Admin Page - Document Management Interface

This page provides an administrative interface for managing documents in the RAG system.
Administrators can upload new documents, view all uploaded documents, and delete documents.
"""

import streamlit as st
import logging
from datetime import datetime, timedelta
from typing import Dict, List
import os
import json

from config.settings import settings
from services.vector_store import VectorStoreManager
from services.document_service import DocumentService
from services.database_manager import DatabaseManager
from services.user_service import UserService
from services.session_service import SessionService
from services.database_manager import DatabaseManager
from utils.helpers import (
    setup_logging,
    format_error_message,
    ValidationError,
    DocumentProcessingError,
    VectorStoreError
)
from utils.auth_guard import require_admin, logout, get_current_user_email
from utils.styles import inject_custom_css

# Configure logging
setup_logging('logs/app.log', logging.INFO)

logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="Admin - Document Management",
    page_icon="📁",
    layout="wide",
    initial_sidebar_state="expanded"
)


def initialize_services():
    """
    Initialize document management services.
    
    Returns:
        Tuple of (document_service, initialization_success)
    """
    try:
        # Validate settings
        settings.validate()
        
        # Initialize vector store
        vector_store = VectorStoreManager(
            persist_directory=settings.VECTOR_STORE_PATH
        )
        vector_store.initialize()
        
        # Initialize document service
        document_service = DocumentService(vector_store=vector_store)
        
        logger.info("Admin services initialized successfully")
        return document_service, True
        
    except Exception as e:
        logger.error(f"Failed to initialize admin services: {str(e)}")
        return None, False


def initialize_session_state():
    """Initialize Streamlit session state variables for admin page."""
    # Initialize document service
    if 'admin_document_service' not in st.session_state:
        document_service, success = initialize_services()
        st.session_state.admin_document_service = document_service
        st.session_state.admin_services_initialized = success
    
    # Initialize upload status
    if 'upload_status' not in st.session_state:
        st.session_state.upload_status = None
    
    # Initialize delete confirmation
    if 'delete_confirm' not in st.session_state:
        st.session_state.delete_confirm = None


def format_file_size(size_bytes: int) -> str:
    """
    Format file size in human-readable format.
    
    Args:
        size_bytes: File size in bytes
        
    Returns:
        Formatted string (e.g., "1.5 MB")
    """
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} TB"


def format_timestamp(timestamp_str: str) -> str:
    """
    Format ISO timestamp to readable format.
    
    Args:
        timestamp_str: ISO format timestamp string
        
    Returns:
        Formatted date string
    """
    try:
        dt = datetime.fromisoformat(timestamp_str)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except:
        return timestamp_str


def display_sidebar():
    """Display sidebar with statistics and information."""
    with st.sidebar:
        st.title("📁 Document Management")
        st.markdown("---")
        
        # User information
        st.subheader("👤 User Info")
        user_email = get_current_user_email()
        user_role = st.session_state.get('role', 'admin')
        
        st.write(f"**Email:** {user_email}")
        st.write(f"**Role:** {user_role.capitalize()}")
        
        # Logout button
        if st.button("🚪 Logout", use_container_width=True, key="admin_logout"):
            logout()
            st.success("Logged out successfully!")
            st.switch_page("pages/Login.py")
        
        st.markdown("---")
        
        # System status
        st.subheader("System Status")
        
        if st.session_state.admin_services_initialized:
            st.success("✅ System Ready")
        else:
            st.error("❌ System Error")
            st.error("Failed to initialize services.")
        
        st.markdown("---")
        
        # Statistics
        st.subheader("Statistics")
        
        if st.session_state.admin_services_initialized:
            try:
                stats = st.session_state.admin_document_service.get_document_stats()
                st.metric("Total Documents", stats['total_documents'])
                st.metric("Total Chunks", stats['total_chunks'])
                st.metric("Storage Used", f"{stats['total_size_mb']} MB")
            except Exception as e:
                logger.error(f"Failed to get statistics: {str(e)}")
                st.warning("Unable to load statistics")
        
        st.markdown("---")
        
        # Information
        st.subheader("Supported Formats")
        st.info(
            f"**File Types:** {', '.join(settings.SUPPORTED_FILE_TYPES)}\n\n"
            f"**Max Size:** {settings.MAX_FILE_SIZE_MB} MB"
        )


def display_upload_section():
    """Display document upload section."""
    st.header("📤 Upload Documents")
    
    if not st.session_state.admin_services_initialized:
        st.error("System is not properly initialized. Please check your configuration.")
        return
    
    # File uploader
    uploaded_file = st.file_uploader(
        "Choose a document to upload",
        type=['pdf', 'txt', 'docx'],
        help=f"Supported formats: PDF, TXT, DOCX (Max size: {settings.MAX_FILE_SIZE_MB}MB)"
    )
    
    # Upload button and status
    col1, col2 = st.columns([1, 4])
    
    with col1:
        upload_button = st.button("📤 Upload", type="primary", use_container_width=True)
    
    with col2:
        # Display upload status messages
        if st.session_state.upload_status:
            status = st.session_state.upload_status
            if status['type'] == 'success':
                st.success(status['message'])
            elif status['type'] == 'error':
                st.error(status['message'])
            elif status['type'] == 'warning':
                st.warning(status['message'])
    
    # Handle upload
    if upload_button:
        if uploaded_file is None:
            st.session_state.upload_status = {
                'type': 'warning',
                'message': 'Please select a file to upload.'
            }
            st.rerun()
        else:
            try:
                with st.spinner("Processing document..."):
                    # Upload document
                    result = st.session_state.admin_document_service.upload_document(
                        file=uploaded_file,
                        filename=uploaded_file.name
                    )
                    
                    st.session_state.upload_status = {
                        'type': 'success',
                        'message': f"✅ {result['message']}"
                    }
                    
                    logger.info(f"Document uploaded successfully: {uploaded_file.name}")
                    st.rerun()
                    
            except ValidationError as e:
                # Validation errors
                error_msg = format_error_message(e, user_friendly=True)
                st.session_state.upload_status = {
                    'type': 'error',
                    'message': f"❌ {error_msg}"
                }
                logger.error(f"Validation error during upload: {str(e)}")
                st.rerun()
                
            except DocumentProcessingError as e:
                # Document processing errors
                error_msg = format_error_message(e, user_friendly=True)
                st.session_state.upload_status = {
                    'type': 'error',
                    'message': f"❌ {error_msg}"
                }
                logger.error(f"Document processing error: {str(e)}")
                st.rerun()
                
            except VectorStoreError as e:
                # Vector store errors
                error_msg = format_error_message(e, user_friendly=True)
                st.session_state.upload_status = {
                    'type': 'error',
                    'message': f"❌ {error_msg}"
                }
                logger.error(f"Vector store error during upload: {str(e)}")
                st.rerun()
                
            except Exception as e:
                # Unexpected errors
                error_msg = format_error_message(e, user_friendly=True)
                st.session_state.upload_status = {
                    'type': 'error',
                    'message': f"❌ {error_msg}"
                }
                logger.error(f"Unexpected error during document upload: {str(e)}", exc_info=True)
                st.rerun()


def display_document_list():
    """Display list of uploaded documents with management actions."""
    st.header("📚 Document Library")
    
    if not st.session_state.admin_services_initialized:
        st.error("System is not properly initialized. Please check your configuration.")
        return
    
    try:
        # Get list of documents
        documents = st.session_state.admin_document_service.list_documents()
        
        if not documents:
            st.info("No documents uploaded yet. Upload your first document above to get started!")
            return
        
        # Sort documents by upload timestamp (newest first)
        documents.sort(key=lambda x: x['upload_timestamp'], reverse=True)
        
        # Display documents in a table-like format
        for doc in documents:
            with st.container():
                col1, col2, col3, col4, col5 = st.columns([3, 2, 1, 1, 1])
                
                with col1:
                    st.markdown(f"**📄 {doc['filename']}**")
                
                with col2:
                    st.text(format_timestamp(doc['upload_timestamp']))
                
                with col3:
                    st.text(format_file_size(doc['file_size']))
                
                with col4:
                    st.text(f"{doc['chunk_count']} chunks")
                
                with col5:
                    # Delete button with unique key
                    delete_key = f"delete_{doc['doc_id']}"
                    if st.button("🗑️ Delete", key=delete_key, use_container_width=True):
                        st.session_state.delete_confirm = doc['doc_id']
                        st.rerun()
                
                st.divider()
        
        # Handle delete confirmation dialog
        if st.session_state.delete_confirm:
            display_delete_confirmation(st.session_state.delete_confirm)
            
    except Exception as e:
        logger.error(f"Error displaying document list: {str(e)}")
        st.error("Failed to load document list. Please try refreshing the page.")


def display_delete_confirmation(doc_id: str):
    """
    Display delete confirmation dialog.
    
    Args:
        doc_id: Document ID to delete
    """
    # Find document details
    documents = st.session_state.admin_document_service.list_documents()
    doc = next((d for d in documents if d['doc_id'] == doc_id), None)
    
    if not doc:
        st.session_state.delete_confirm = None
        st.rerun()
        return
    
    # Display confirmation dialog
    st.warning(f"⚠️ Are you sure you want to delete **{doc['filename']}**?")
    st.caption("This action cannot be undone. The document and all its embeddings will be permanently removed.")
    
    col1, col2, col3 = st.columns([1, 1, 3])
    
    with col1:
        if st.button("✅ Confirm Delete", type="primary", use_container_width=True):
            try:
                with st.spinner("Deleting document..."):
                    # Delete document
                    st.session_state.admin_document_service.delete_document(doc_id)
                    
                    st.session_state.upload_status = {
                        'type': 'success',
                        'message': f"✅ Document '{doc['filename']}' deleted successfully."
                    }
                    
                    logger.info(f"Document deleted successfully: {doc['filename']}")
                    
            except ValidationError as e:
                # Validation errors
                error_msg = format_error_message(e, user_friendly=True)
                st.session_state.upload_status = {
                    'type': 'error',
                    'message': f"❌ {error_msg}"
                }
                logger.error(f"Validation error during delete: {str(e)}")
                
            except DocumentProcessingError as e:
                # Document processing errors (partial deletion)
                error_msg = format_error_message(e, user_friendly=True)
                st.session_state.upload_status = {
                    'type': 'warning',
                    'message': f"⚠️ {error_msg}"
                }
                logger.error(f"Document processing error during delete: {str(e)}")
                
            except VectorStoreError as e:
                # Vector store errors
                error_msg = format_error_message(e, user_friendly=True)
                st.session_state.upload_status = {
                    'type': 'error',
                    'message': f"❌ {error_msg}"
                }
                logger.error(f"Vector store error during delete: {str(e)}")
                
            except Exception as e:
                # Unexpected errors
                error_msg = format_error_message(e, user_friendly=True)
                st.session_state.upload_status = {
                    'type': 'error',
                    'message': f"❌ {error_msg}"
                }
                logger.error(f"Unexpected error deleting document: {str(e)}", exc_info=True)
            
            finally:
                st.session_state.delete_confirm = None
                st.rerun()
    
    with col2:
        if st.button("❌ Cancel", use_container_width=True):
            st.session_state.delete_confirm = None
            st.rerun()


def display_user_management_tab():
    """Display the user management tab."""
    st.header("👥 User Management")
    
    # Initialize user management session state
    if 'user_search' not in st.session_state:
        st.session_state.user_search = ""
    if 'user_role_filter' not in st.session_state:
        st.session_state.user_role_filter = "All"
    if 'user_to_delete' not in st.session_state:
        st.session_state.user_to_delete = None
    if 'user_management_message' not in st.session_state:
        st.session_state.user_management_message = None
    
    # Display status message if any
    if st.session_state.user_management_message:
        msg = st.session_state.user_management_message
        if msg['type'] == 'success':
            st.success(msg['text'])
        elif msg['type'] == 'error':
            st.error(msg['text'])
        elif msg['type'] == 'warning':
            st.warning(msg['text'])
        st.session_state.user_management_message = None
    
    # Search and filter controls
    col1, col2, col3 = st.columns([3, 2, 1])
    
    with col1:
        search_term = st.text_input(
            "🔍 Search by email",
            value=st.session_state.user_search,
            placeholder="Enter email to search...",
            key="user_search_input"
        )
        if search_term != st.session_state.user_search:
            st.session_state.user_search = search_term
            st.rerun()
    
    with col2:
        role_filter = st.selectbox(
            "Filter by role",
            options=["All", "user", "admin"],
            index=["All", "user", "admin"].index(st.session_state.user_role_filter),
            key="user_role_filter_select"
        )
        if role_filter != st.session_state.user_role_filter:
            st.session_state.user_role_filter = role_filter
            st.rerun()
    
    with col3:
        if st.button("🔄 Refresh", use_container_width=True, key="documents_refresh"):
            st.rerun()
    
    st.markdown("---")
    
    # Fetch users
    try:
        search_email = st.session_state.user_search if st.session_state.user_search else None
        role_filter_value = st.session_state.user_role_filter if st.session_state.user_role_filter != "All" else None
        
        users, total_count = UserService.get_all_users(
            page=1,
            page_size=100,
            search_email=search_email,
            role_filter=role_filter_value
        )
        
        if not users:
            st.info("No users found matching the criteria.")
            return
        
        # Display user count
        st.caption(f"Showing {len(users)} of {total_count} users")
        
        # Display users in a table-like format
        for user in users:
            with st.container():
                # User info row
                col1, col2, col3, col4 = st.columns([3, 2, 2, 2])
                
                with col1:
                    # Display user email and name
                    status_icon = "✅" if user['is_active'] else "❌"
                    role_badge = "🔑 Admin" if user['role'] == 'admin' else "👤 User"
                    st.markdown(f"{status_icon} **{user['email']}**")
                    st.caption(f"{user['full_name']} • {role_badge}")
                
                with col2:
                    st.text("Registered:")
                    st.caption(format_timestamp(user['created_at'].isoformat() if hasattr(user['created_at'], 'isoformat') else str(user['created_at'])))
                
                with col3:
                    st.text("Last Login:")
                    if user['last_login']:
                        st.caption(format_timestamp(user['last_login'].isoformat() if hasattr(user['last_login'], 'isoformat') else str(user['last_login'])))
                    else:
                        st.caption("Never")
                
                with col4:
                    st.text("Actions:")
                    # Create action buttons in a sub-column layout
                    action_col1, action_col2, action_col3 = st.columns(3)
                    
                    with action_col1:
                        # Role change button
                        new_role = "user" if user['role'] == 'admin' else "admin"
                        role_icon = "👤" if new_role == "user" else "🔑"
                        if st.button(
                            role_icon,
                            key=f"role_{user['user_id']}",
                            help=f"Change to {new_role}",
                            use_container_width=True
                        ):
                            try:
                                UserService.update_user_role(user['user_id'], new_role)
                                st.session_state.user_management_message = {
                                    'type': 'success',
                                    'text': f"✅ Changed {user['email']} role to {new_role}"
                                }
                                logger.info(f"Changed user {user['email']} role to {new_role}")
                                st.rerun()
                            except Exception as e:
                                st.session_state.user_management_message = {
                                    'type': 'error',
                                    'text': f"❌ Failed to change role: {str(e)}"
                                }
                                logger.error(f"Failed to change user role: {e}")
                                st.rerun()
                    
                    with action_col2:
                        # Activate/Deactivate button
                        if user['is_active']:
                            if st.button(
                                "🚫",
                                key=f"deactivate_{user['user_id']}",
                                help="Deactivate user",
                                use_container_width=True
                            ):
                                try:
                                    UserService.deactivate_user(user['user_id'])
                                    st.session_state.user_management_message = {
                                        'type': 'success',
                                        'text': f"✅ Deactivated user {user['email']}"
                                    }
                                    logger.info(f"Deactivated user {user['email']}")
                                    st.rerun()
                                except Exception as e:
                                    st.session_state.user_management_message = {
                                        'type': 'error',
                                        'text': f"❌ Failed to deactivate: {str(e)}"
                                    }
                                    logger.error(f"Failed to deactivate user: {e}")
                                    st.rerun()
                        else:
                            if st.button(
                                "✅",
                                key=f"activate_{user['user_id']}",
                                help="Activate user",
                                use_container_width=True
                            ):
                                try:
                                    UserService.activate_user(user['user_id'])
                                    st.session_state.user_management_message = {
                                        'type': 'success',
                                        'text': f"✅ Activated user {user['email']}"
                                    }
                                    logger.info(f"Activated user {user['email']}")
                                    st.rerun()
                                except Exception as e:
                                    st.session_state.user_management_message = {
                                        'type': 'error',
                                        'text': f"❌ Failed to activate: {str(e)}"
                                    }
                                    logger.error(f"Failed to activate user: {e}")
                                    st.rerun()
                    
                    with action_col3:
                        # Delete button
                        if st.button(
                            "🗑️",
                            key=f"delete_{user['user_id']}",
                            help="Delete user",
                            use_container_width=True
                        ):
                            st.session_state.user_to_delete = user
                            st.rerun()
                
                st.divider()
        
        # Handle delete confirmation
        if st.session_state.user_to_delete:
            display_user_delete_confirmation(st.session_state.user_to_delete)
    
    except Exception as e:
        logger.error(f"Error loading users: {e}")
        st.error(f"Failed to load users: {str(e)}")


def display_user_delete_confirmation(user: Dict):
    """Display user delete confirmation dialog."""
    st.warning(f"⚠️ Are you sure you want to delete user **{user['email']}**?")
    st.caption("This action cannot be undone. All user data including chat sessions and messages will be permanently deleted.")
    
    col1, col2, col3 = st.columns([1, 1, 3])
    
    with col1:
        if st.button("✅ Confirm Delete", type="primary", use_container_width=True):
            try:
                UserService.delete_user(user['user_id'])
                st.session_state.user_management_message = {
                    'type': 'success',
                    'text': f"✅ User {user['email']} deleted successfully"
                }
                logger.info(f"Deleted user {user['email']}")
            except Exception as e:
                st.session_state.user_management_message = {
                    'type': 'error',
                    'text': f"❌ Failed to delete user: {str(e)}"
                }
                logger.error(f"Failed to delete user: {e}")
            finally:
                st.session_state.user_to_delete = None
                st.rerun()
    
    with col2:
        if st.button("❌ Cancel", use_container_width=True):
            st.session_state.user_to_delete = None
            st.rerun()


def display_session_viewer_tab():
    """Display the admin chat session viewer tab."""
    st.header("💬 Chat Session Viewer")
    
    # Initialize session state for viewer
    if 'session_viewer_user_filter' not in st.session_state:
        st.session_state.session_viewer_user_filter = ""
    if 'selected_session_id' not in st.session_state:
        st.session_state.selected_session_id = None
    
    # Search and filter controls
    col1, col2 = st.columns([4, 1])
    
    with col1:
        user_filter = st.text_input(
            "🔍 Filter by user email",
            value=st.session_state.session_viewer_user_filter,
            placeholder="Enter email to filter sessions...",
            key="session_viewer_filter_input"
        )
        if user_filter != st.session_state.session_viewer_user_filter:
            st.session_state.session_viewer_user_filter = user_filter
            st.session_state.selected_session_id = None
            st.rerun()
    
    with col2:
        if st.button("🔄 Refresh", use_container_width=True, key="session_viewer_refresh"):
            st.rerun()
    
    st.markdown("---")
    
    try:
        # Get all sessions
        user_email = st.session_state.session_viewer_user_filter if st.session_state.session_viewer_user_filter else None
        sessions, total_count = SessionService.get_all_sessions(
            page=1,
            page_size=100,
            user_email=user_email
        )
        
        if not sessions:
            st.info("No sessions found matching the criteria.")
            return
        
        # Display session count
        st.caption(f"Showing {len(sessions)} of {total_count} sessions")
        
        # Two-column layout: session list and message viewer
        col1, col2 = st.columns([1, 2])
        
        with col1:
            st.subheader("📋 Sessions")
            
            # Display sessions as selectable items
            for session in sessions:
                with st.container():
                    # Create a button for each session
                    session_label = f"{session['title'][:30]}..."
                    user_label = f"{session['user_email']}"
                    
                    is_selected = st.session_state.selected_session_id == session['session_id']
                    
                    button_type = "primary" if is_selected else "secondary"
                    
                    if st.button(
                        f"{'▶️' if is_selected else '📄'} {session_label}",
                        key=f"session_{session['session_id']}",
                        use_container_width=True,
                        type=button_type
                    ):
                        st.session_state.selected_session_id = session['session_id']
                        st.rerun()
                    
                    st.caption(f"👤 {user_label}")
                    st.caption(f"💬 {session['message_count']} messages • {format_timestamp(session['updated_at'].isoformat() if hasattr(session['updated_at'], 'isoformat') else str(session['updated_at']))}")
                    st.divider()
        
        with col2:
            st.subheader("💬 Messages")
            
            if st.session_state.selected_session_id:
                # Get session details
                selected_session = next(
                    (s for s in sessions if s['session_id'] == st.session_state.selected_session_id),
                    None
                )
                
                if selected_session:
                    # Display session info
                    st.info(
                        f"**Session:** {selected_session['title']}\n\n"
                        f"**User:** {selected_session['user_name']} ({selected_session['user_email']})\n\n"
                        f"**Created:** {format_timestamp(selected_session['created_at'].isoformat() if hasattr(selected_session['created_at'], 'isoformat') else str(selected_session['created_at']))}\n\n"
                        f"**Last Updated:** {format_timestamp(selected_session['updated_at'].isoformat() if hasattr(selected_session['updated_at'], 'isoformat') else str(selected_session['updated_at']))}"
                    )
                    
                    # Export button
                    col_a, col_b = st.columns([3, 1])
                    with col_b:
                        if st.button("📥 Export", use_container_width=True, key="export_session"):
                            # Get messages for export
                            messages = SessionService.get_session_messages(st.session_state.selected_session_id)
                            
                            # Create export data
                            export_data = {
                                'session_id': selected_session['session_id'],
                                'title': selected_session['title'],
                                'user_email': selected_session['user_email'],
                                'user_name': selected_session['user_name'],
                                'created_at': str(selected_session['created_at']),
                                'updated_at': str(selected_session['updated_at']),
                                'messages': [
                                    {
                                        'role': msg['role'],
                                        'content': msg['content'],
                                        'created_at': str(msg['created_at']),
                                        'sources': msg.get('sources')
                                    }
                                    for msg in messages
                                ]
                            }
                            
                            # Convert to JSON
                            json_str = json.dumps(export_data, indent=2)
                            
                            # Provide download button
                            st.download_button(
                                label="💾 Download JSON",
                                data=json_str,
                                file_name=f"session_{selected_session['session_id'][:8]}.json",
                                mime="application/json",
                                use_container_width=True
                            )
                    
                    st.markdown("---")
                    
                    # Get and display messages
                    messages = SessionService.get_session_messages(st.session_state.selected_session_id)
                    
                    if messages:
                        # Display messages in a scrollable container
                        for msg in messages:
                            role_icon = "👤" if msg['role'] == 'user' else "🤖"
                            role_label = "User" if msg['role'] == 'user' else "Assistant"
                            
                            with st.container():
                                st.markdown(f"**{role_icon} {role_label}** • {format_timestamp(msg['created_at'].isoformat() if hasattr(msg['created_at'], 'isoformat') else str(msg['created_at']))}")
                                st.markdown(msg['content'])
                                
                                # Display sources if available
                                if msg.get('sources'):
                                    with st.expander("📚 Sources"):
                                        for source in msg['sources']:
                                            st.caption(f"• {source}")
                                
                                st.divider()
                    else:
                        st.info("No messages in this session.")
                else:
                    st.warning("Selected session not found.")
            else:
                st.info("👈 Select a session from the list to view messages")
    
    except Exception as e:
        logger.error(f"Error loading sessions: {e}")
        st.error(f"Failed to load sessions: {str(e)}")


def display_system_monitoring_tab():
    """Display the system monitoring tab."""
    st.header("🖥️ System Monitoring")
    
    # Refresh button
    col1, col2 = st.columns([4, 1])
    with col2:
        if st.button("🔄 Refresh", use_container_width=True, key="system_refresh"):
            st.rerun()
    
    st.markdown("---")
    
    # Database Status
    st.subheader("💾 Database Status")
    
    try:
        # Check database health
        db_healthy = DatabaseManager.health_check()
        
        col1, col2 = st.columns(2)
        
        with col1:
            if db_healthy:
                st.success("✅ Database Connection: Healthy")
            else:
                st.error("❌ Database Connection: Failed")
        
        with col2:
            # Get connection pool info
            conn_info = DatabaseManager.get_connection_info()
            if conn_info['status'] == 'initialized':
                st.info(f"🔗 Active Connections: {conn_info['checked_out_connections']}/{conn_info['total_connections']}")
            else:
                st.warning("⚠️ Database not initialized")
        
        # Display connection pool details
        if conn_info['status'] == 'initialized':
            with st.expander("Connection Pool Details"):
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Pool Size", conn_info['pool_size'])
                    st.metric("Checked In", conn_info['checked_in_connections'])
                
                with col2:
                    st.metric("Checked Out", conn_info['checked_out_connections'])
                    st.metric("Overflow", conn_info['overflow_connections'])
                
                with col3:
                    st.metric("Total Connections", conn_info['total_connections'])
    
    except Exception as e:
        logger.error(f"Error checking database status: {e}")
        st.error(f"Failed to check database status: {str(e)}")
    
    st.markdown("---")
    
    # Vector Store Status
    st.subheader("🔍 Vector Store Status")
    
    try:
        if st.session_state.admin_services_initialized:
            stats = st.session_state.admin_document_service.get_document_stats()
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Total Documents", stats['total_documents'])
            
            with col2:
                st.metric("Total Chunks", stats['total_chunks'])
            
            with col3:
                st.metric("Storage Used", f"{stats['total_size_mb']} MB")
            
            st.success("✅ Vector Store: Operational")
        else:
            st.warning("⚠️ Vector Store: Not initialized")
    
    except Exception as e:
        logger.error(f"Error checking vector store status: {e}")
        st.error(f"Failed to check vector store status: {str(e)}")
    
    st.markdown("---")
    
    # System Configuration
    st.subheader("⚙️ System Configuration")
    
    with st.expander("View Configuration"):
        col1, col2 = st.columns(2)
        
        with col1:
            st.text("Database Settings:")
            st.caption(f"Pool Size: {settings.DATABASE_POOL_SIZE}")
            st.caption(f"Max Overflow: {settings.DATABASE_MAX_OVERFLOW}")
            st.caption(f"Pool Timeout: {settings.DATABASE_POOL_TIMEOUT}s")
            
            st.text("\nSession Settings:")
            st.caption(f"Timeout: {settings.SESSION_TIMEOUT_HOURS} hours")
            st.caption(f"Remember Me: {settings.SESSION_REMEMBER_ME_DAYS} days")
        
        with col2:
            st.text("Security Settings:")
            st.caption(f"Password Min Length: {settings.PASSWORD_MIN_LENGTH}")
            st.caption(f"Max Login Attempts: {settings.MAX_LOGIN_ATTEMPTS}")
            st.caption(f"Lockout Duration: {settings.ACCOUNT_LOCKOUT_MINUTES} min")
            
            st.text("\nLLM Settings:")
            st.caption(f"Provider: {settings.LLM_PROVIDER}")
            st.caption(f"Model: {settings.LLM_MODEL}")
    
    st.markdown("---")
    
    # Recent Error Logs
    st.subheader("📋 Recent Error Logs")
    
    try:
        # Read last 50 lines from log file
        log_file = 'logs/app.log'
        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                lines = f.readlines()
                # Get last 50 lines
                recent_lines = lines[-50:] if len(lines) > 50 else lines
                
                # Filter for ERROR and WARNING lines
                error_lines = [line for line in recent_lines if 'ERROR' in line or 'WARNING' in line]
                
                if error_lines:
                    # Display in a text area
                    log_text = ''.join(error_lines[-20:])  # Last 20 error/warning lines
                    st.text_area(
                        "Recent Errors and Warnings",
                        value=log_text,
                        height=200,
                        disabled=True
                    )
                else:
                    st.success("✅ No recent errors or warnings")
        else:
            st.info("Log file not found")
    
    except Exception as e:
        logger.error(f"Error reading log file: {e}")
        st.error(f"Failed to read log file: {str(e)}")
    
    st.markdown("---")
    
    # System Health Indicators
    st.subheader("🏥 System Health")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        # Overall health based on database and vector store
        if db_healthy and st.session_state.admin_services_initialized:
            st.success("✅ Overall Status: Healthy")
        elif db_healthy or st.session_state.admin_services_initialized:
            st.warning("⚠️ Overall Status: Degraded")
        else:
            st.error("❌ Overall Status: Critical")
    
    with col2:
        # API Status (check if we can make a simple call)
        try:
            # Just check if settings are configured
            if settings.LLM_PROVIDER and (settings.OPENAI_API_KEY or settings.GEMINI_API_KEY):
                st.success("✅ API: Configured")
            else:
                st.warning("⚠️ API: Not configured")
        except:
            st.error("❌ API: Error")
    
    with col3:
        # Storage status
        try:
            import shutil
            disk_usage = shutil.disk_usage('.')
            free_gb = disk_usage.free / (1024**3)
            if free_gb > 10:
                st.success(f"✅ Storage: {free_gb:.1f} GB free")
            elif free_gb > 5:
                st.warning(f"⚠️ Storage: {free_gb:.1f} GB free")
            else:
                st.error(f"❌ Storage: {free_gb:.1f} GB free")
        except:
            st.info("Storage: Unknown")


def display_analytics_tab():
    """Display the session analytics tab."""
    st.header("📊 Session Analytics")
    
    # Date range selector
    col1, col2 = st.columns([3, 1])
    
    with col1:
        days = st.selectbox(
            "Time Period",
            options=[7, 14, 30, 60, 90],
            index=2,
            format_func=lambda x: f"Last {x} days"
        )
    
    with col2:
        if st.button("🔄 Refresh", use_container_width=True, key="analytics_refresh"):
            st.rerun()
    
    st.markdown("---")
    
    try:
        # Get analytics data
        analytics = SessionService.get_session_analytics(days=days)
        user_stats = UserService.get_user_statistics()
        
        # Display key metrics
        st.subheader("📈 Key Metrics")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                label="Total Users",
                value=user_stats['total_users'],
                delta=f"+{user_stats['recent_registrations']} this month"
            )
        
        with col2:
            st.metric(
                label="Active Sessions",
                value=analytics['active_sessions']
            )
        
        with col3:
            st.metric(
                label="Total Messages",
                value=analytics['total_messages']
            )
        
        with col4:
            st.metric(
                label="Avg Session Duration",
                value=f"{analytics['avg_session_duration_minutes']:.1f} min"
            )
        
        st.markdown("---")
        
        # Messages per day chart
        st.subheader("📅 Messages Per Day")
        
        if analytics['messages_per_day']:
            # Prepare data for chart
            dates = [item['date'] for item in analytics['messages_per_day']]
            counts = [item['count'] for item in analytics['messages_per_day']]
            
            # Create a simple bar chart using Streamlit
            import pandas as pd
            chart_data = pd.DataFrame({
                'Date': dates,
                'Messages': counts
            })
            st.bar_chart(chart_data.set_index('Date'))
        else:
            st.info("No message data available for the selected period.")
        
        st.markdown("---")
        
        # Most active users
        st.subheader("🏆 Most Active Users")
        
        if analytics['most_active_users']:
            for idx, user in enumerate(analytics['most_active_users'], 1):
                col1, col2, col3 = st.columns([1, 4, 2])
                
                with col1:
                    # Medal emoji for top 3
                    if idx == 1:
                        st.markdown("🥇")
                    elif idx == 2:
                        st.markdown("🥈")
                    elif idx == 3:
                        st.markdown("🥉")
                    else:
                        st.markdown(f"**{idx}.**")
                
                with col2:
                    st.markdown(f"**{user['email']}**")
                    st.caption(user['full_name'])
                
                with col3:
                    st.metric("Messages", user['message_count'])
                
                if idx < len(analytics['most_active_users']):
                    st.divider()
        else:
            st.info("No user activity data available for the selected period.")
        
        st.markdown("---")
        
        # Additional statistics
        st.subheader("📊 Additional Statistics")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("Total Sessions (Period)", analytics['total_sessions'])
            st.metric("Active Users (7 days)", user_stats['recent_logins'])
        
        with col2:
            st.metric("Admin Users", user_stats['admin_users'])
            st.metric("New Registrations (30 days)", user_stats['recent_registrations'])
    
    except Exception as e:
        logger.error(f"Error loading analytics: {e}")
        st.error(f"Failed to load analytics: {str(e)}")


@require_admin
def main():
    """Main admin page function."""
    # Initialize database
    try:
        DatabaseManager.initialize()
    except Exception as e:
        logger.error(f"Database initialization failed: {str(e)}")
        # Continue anyway - might already be initialized
    
    # Inject custom CSS
    inject_custom_css()
    
    # Initialize session state
    initialize_session_state()
    
    # Display sidebar
    display_sidebar()
    
    # Main content area
    st.title("🔧 Admin Dashboard")
    
    # Create tabs for different admin functions
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📁 Documents",
        "👥 Users",
        "📊 Analytics",
        "🖥️ System",
        "💬 Sessions"
    ])
    
    with tab1:
        display_document_management_tab()
    
    with tab2:
        display_user_management_tab()
    
    with tab3:
        display_analytics_tab()
    
    with tab4:
        display_system_monitoring_tab()
    
    with tab5:
        display_session_viewer_tab()


def display_document_management_tab():
    """Display the document management tab (existing functionality)."""
    st.header("📁 Document Management")
    
    # Display error if services failed to initialize
    if not st.session_state.admin_services_initialized:
        st.error(
            "⚠️ Failed to initialize the document management system. "
            "Please ensure your OpenAI API key is configured in the .env file."
        )
        st.info(
            "To set up the system:\n"
            "1. Copy `.env.example` to `.env`\n"
            "2. Add your OpenAI API key\n"
            "3. Restart the application"
        )
        return
    
    # Upload section
    display_upload_section()
    
    st.markdown("---")
    
    # Document list section
    display_document_list()


if __name__ == "__main__":
    # Ensure logs directory exists
    os.makedirs('logs', exist_ok=True)
    
    # Run the application
    main()
