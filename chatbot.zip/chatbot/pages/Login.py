"""
Login Page - User Authentication Interface

This page provides a login interface for users to authenticate with their email and password.
Includes "Remember me" functionality, password reset link, and registration link.
"""

import streamlit as st
import logging
from typing import Optional

from config.settings import settings
from services.auth_service import AuthService, AuthenticationError, AccountLockedError
from services.database_manager import DatabaseManager
from utils.auth_guard import set_user_session, is_authenticated
from utils.helpers import setup_logging
from utils.styles import inject_custom_css

# Configure logging
setup_logging('logs/app.log', logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="Login - RAG Chatbot",
    page_icon="🔐",
    layout="centered",
    initial_sidebar_state="collapsed"
)


def initialize_session_state():
    """Initialize session state variables for login page."""
    if 'login_error' not in st.session_state:
        st.session_state.login_error = None
    
    if 'login_success' not in st.session_state:
        st.session_state.login_success = None


def display_login_form():
    """Display the login form with email, password, and remember me checkbox."""
    st.title("🔐 Login")
    st.markdown("Welcome back! Please log in to continue.")
    st.markdown("---")
    
    # Display any error messages
    if st.session_state.login_error:
        st.error(st.session_state.login_error)
    
    # Display any success messages (e.g., from registration)
    if st.session_state.login_success:
        st.success(st.session_state.login_success)
        st.session_state.login_success = None
    
    # Login form
    with st.form("login_form", clear_on_submit=False):
        email = st.text_input(
            "Email Address",
            placeholder="your.email@example.com",
            help="Enter your registered email address"
        )
        
        password = st.text_input(
            "Password",
            type="password",
            placeholder="Enter your password",
            help="Enter your account password"
        )
        
        remember_me = st.checkbox(
            "Remember me",
            help=f"Keep me logged in for {settings.SESSION_REMEMBER_ME_DAYS} days"
        )
        
        st.markdown("")  # Add spacing
        
        # Submit button
        submit_button = st.form_submit_button(
            "🔓 Login",
            type="primary",
            use_container_width=True
        )
        
        if submit_button:
            handle_login(email, password, remember_me)
    
    # Additional links
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("🔑 Forgot password?", use_container_width=True):
            st.switch_page("pages/PasswordReset.py")
    
    with col2:
        if st.button("📝 Create account", use_container_width=True):
            st.switch_page("pages/Register.py")


def handle_login(email: str, password: str, remember_me: bool):
    """
    Handle login form submission.
    
    Args:
        email: User's email address
        password: User's password
        remember_me: Whether to extend session timeout
    """
    # Clear previous errors
    st.session_state.login_error = None
    
    # Validate inputs
    if not email or not email.strip():
        st.session_state.login_error = "Please enter your email address"
        st.rerun()
        return
    
    if not password:
        st.session_state.login_error = "Please enter your password"
        st.rerun()
        return
    
    try:
        # Authenticate user
        user_data = AuthService.authenticate_user(email.strip(), password)
        
        # Set user session
        set_user_session(user_data, remember_me)
        
        logger.info(f"User logged in successfully: {email}")
        
        # Determine redirect based on role
        redirect_page = determine_redirect_page(user_data['role'])
        
        # Clear any stored redirect
        if 'redirect_after_login' in st.session_state:
            del st.session_state['redirect_after_login']
        
        # Redirect to appropriate page
        st.switch_page(redirect_page)
        
    except AuthenticationError as e:
        # Invalid credentials
        st.session_state.login_error = str(e)
        logger.warning(f"Failed login attempt for email: {email}")
        st.rerun()
        
    except AccountLockedError as e:
        # Account is locked
        st.session_state.login_error = str(e)
        logger.warning(f"Login attempt for locked account: {email}")
        st.rerun()
        
    except ValueError as e:
        # Account inactive or other validation error
        st.session_state.login_error = str(e)
        logger.warning(f"Login validation error for email: {email} - {str(e)}")
        st.rerun()
        
    except Exception as e:
        # Unexpected error
        st.session_state.login_error = "An unexpected error occurred. Please try again."
        logger.error(f"Unexpected error during login: {str(e)}", exc_info=True)
        st.rerun()


def determine_redirect_page(role: str) -> str:
    """
    Determine which page to redirect to based on user role.
    
    Args:
        role: User's role (user or admin)
        
    Returns:
        str: Page path to redirect to
    """
    # Check if there's a stored redirect page
    if 'redirect_after_login' in st.session_state:
        redirect_page = st.session_state['redirect_after_login']
        # Validate the redirect page exists
        if redirect_page in ['Home.py', 'pages/Admin.py']:
            return redirect_page
    
    # Default redirect based on role
    if role == 'admin':
        return "pages/Admin.py"
    else:
        return "Home.py"


def main():
    """Main login page function."""
    # Initialize database
    try:
        DatabaseManager.initialize()
    except Exception as e:
        logger.error(f"Database initialization failed: {str(e)}")
        # Continue anyway - might already be initialized
    
    # Inject custom CSS
    inject_custom_css()
    
    # Initialize session state
    initialize_session_state()
    
    # Check if already authenticated
    if is_authenticated():
        # User is already logged in, redirect to appropriate page
        role = st.session_state.get('role', 'user')
        redirect_page = determine_redirect_page(role)
        st.info("You are already logged in. Redirecting...")
        st.switch_page(redirect_page)
        return
    
    # Display login form
    display_login_form()
    
    # Add some spacing and branding
    st.markdown("---")
    st.markdown(
        "<div style='text-align: center; color: gray;'>"
        "RAG Chatbot - Secure Document Intelligence"
        "</div>",
        unsafe_allow_html=True
    )


if __name__ == "__main__":
    # Ensure logs directory exists
    import os
    os.makedirs('logs', exist_ok=True)
    
    # Run the application
    main()
