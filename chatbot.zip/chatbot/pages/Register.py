"""
Registration Page - New User Account Creation

This page provides a registration interface for new users to create an account.
Includes password strength indicator, email validation, and terms of service acceptance.
"""

import streamlit as st
import logging
import re
from typing import Tuple

from config.settings import settings
from services.auth_service import AuthService
from services.database_manager import DatabaseManager
from utils.helpers import setup_logging
from utils.styles import inject_custom_css

# Configure logging
setup_logging('logs/app.log', logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="Register - RAG Chatbot",
    page_icon="📝",
    layout="centered",
    initial_sidebar_state="collapsed"
)


def initialize_session_state():
    """Initialize session state variables for registration page."""
    if 'registration_error' not in st.session_state:
        st.session_state.registration_error = None


def calculate_password_strength(password: str) -> Tuple[int, str, str]:
    """
    Calculate password strength and return score, label, and color.
    
    Args:
        password: Password to evaluate
        
    Returns:
        Tuple[int, str, str]: (score 0-100, label, color)
    """
    if not password:
        return 0, "No password", "red"
    
    score = 0
    feedback = []
    
    # Length check (up to 40 points)
    length = len(password)
    if length >= 8:
        score += min(length * 2, 40)
    else:
        feedback.append(f"At least {settings.PASSWORD_MIN_LENGTH} characters")
    
    # Uppercase letter (20 points)
    if re.search(r'[A-Z]', password):
        score += 20
    else:
        feedback.append("One uppercase letter")
    
    # Lowercase letter (20 points)
    if re.search(r'[a-z]', password):
        score += 20
    else:
        feedback.append("One lowercase letter")
    
    # Number (20 points)
    if re.search(r'\d', password):
        score += 20
    else:
        feedback.append("One number")
    
    # Special character (bonus 10 points)
    if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        score += 10
    
    # Determine label and color
    if score < 40:
        label = "Weak"
        color = "red"
    elif score < 70:
        label = "Fair"
        color = "orange"
    elif score < 90:
        label = "Good"
        color = "yellow"
    else:
        label = "Strong"
        color = "green"
    
    return score, label, color


def display_password_strength_indicator(password: str):
    """
    Display a real-time password strength indicator.
    
    Args:
        password: Current password value
    """
    score, label, color = calculate_password_strength(password)
    
    # Create progress bar
    progress_html = f"""
    <div style="margin: 10px 0;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
            <span style="font-size: 14px; font-weight: 500;">Password Strength:</span>
            <span style="font-size: 14px; font-weight: 600; color: {color};">{label}</span>
        </div>
        <div style="width: 100%; background-color: #e0e0e0; border-radius: 10px; height: 8px;">
            <div style="width: {score}%; background-color: {color}; border-radius: 10px; height: 8px; transition: width 0.3s;"></div>
        </div>
    </div>
    """
    st.markdown(progress_html, unsafe_allow_html=True)
    
    # Show requirements if password is weak
    if score < 100:
        is_valid, error_msg = AuthService.validate_password_strength(password)
        if not is_valid and password:
            st.caption(f"⚠️ {error_msg}")


def display_registration_form():
    """Display the registration form with all required fields."""
    st.title("📝 Create Account")
    st.markdown("Join us to start your personalized chat experience.")
    st.markdown("---")
    
    # Display any error messages
    if st.session_state.registration_error:
        st.error(st.session_state.registration_error)
    
    # Registration form
    with st.form("registration_form", clear_on_submit=False):
        full_name = st.text_input(
            "Full Name",
            placeholder="John Doe",
            help="Enter your full name"
        )
        
        email = st.text_input(
            "Email Address",
            placeholder="your.email@example.com",
            help="Enter a valid email address"
        )
        
        password = st.text_input(
            "Password",
            type="password",
            placeholder="Create a strong password",
            help=f"Minimum {settings.PASSWORD_MIN_LENGTH} characters with uppercase, lowercase, and number"
        )
        
        # Password strength indicator (outside form for real-time update)
        password_confirm = st.text_input(
            "Confirm Password",
            type="password",
            placeholder="Re-enter your password",
            help="Must match the password above"
        )
        
        st.markdown("")  # Add spacing
        
        # Terms of service checkbox
        terms_accepted = st.checkbox(
            "I agree to the Terms of Service and Privacy Policy",
            help="You must accept the terms to create an account"
        )
        
        st.markdown("")  # Add spacing
        
        # Submit button
        submit_button = st.form_submit_button(
            "✅ Create Account",
            type="primary",
            use_container_width=True
        )
        
        if submit_button:
            handle_registration(
                full_name,
                email,
                password,
                password_confirm,
                terms_accepted
            )
    
    # Show password strength indicator outside form for real-time updates
    if 'temp_password' in st.session_state and st.session_state.temp_password:
        display_password_strength_indicator(st.session_state.temp_password)
    
    # Additional links
    st.markdown("---")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("Already have an account?")
    
    with col2:
        if st.button("🔐 Login", use_container_width=True):
            st.switch_page("pages/Login.py")


def handle_registration(
    full_name: str,
    email: str,
    password: str,
    password_confirm: str,
    terms_accepted: bool
):
    """
    Handle registration form submission.
    
    Args:
        full_name: User's full name
        email: User's email address
        password: User's password
        password_confirm: Password confirmation
        terms_accepted: Whether user accepted terms
    """
    # Clear previous errors
    st.session_state.registration_error = None
    
    # Validate inputs
    if not full_name or not full_name.strip():
        st.session_state.registration_error = "Please enter your full name"
        st.rerun()
        return
    
    if not email or not email.strip():
        st.session_state.registration_error = "Please enter your email address"
        st.rerun()
        return
    
    # Validate email format
    email_valid, email_error = AuthService.validate_email(email.strip())
    if not email_valid:
        st.session_state.registration_error = email_error
        st.rerun()
        return
    
    if not password:
        st.session_state.registration_error = "Please enter a password"
        st.rerun()
        return
    
    # Validate password strength
    password_valid, password_error = AuthService.validate_password_strength(password)
    if not password_valid:
        st.session_state.registration_error = password_error
        st.rerun()
        return
    
    if not password_confirm:
        st.session_state.registration_error = "Please confirm your password"
        st.rerun()
        return
    
    # Check password match
    if password != password_confirm:
        st.session_state.registration_error = "Passwords do not match"
        st.rerun()
        return
    
    # Check terms acceptance
    if not terms_accepted:
        st.session_state.registration_error = "You must accept the Terms of Service to create an account"
        st.rerun()
        return
    
    try:
        # Register user
        result = AuthService.register_user(
            email=email.strip(),
            password=password,
            full_name=full_name.strip(),
            role="user"
        )
        
        logger.info(f"New user registered: {email}")
        
        # Set success message in login page session state
        st.session_state.login_success = "Account created successfully! Please log in."
        
        # Redirect to login page
        st.switch_page("pages/Login.py")
        
    except ValueError as e:
        # Validation or duplicate email error
        error_message = str(e)
        
        # Handle duplicate email with user-friendly message
        if "already registered" in error_message.lower():
            st.session_state.registration_error = "This email is already registered. Please use a different email or log in."
        else:
            st.session_state.registration_error = error_message
        
        logger.warning(f"Registration failed for email: {email} - {error_message}")
        st.rerun()
        
    except Exception as e:
        # Unexpected error
        st.session_state.registration_error = "An unexpected error occurred. Please try again."
        logger.error(f"Unexpected error during registration: {str(e)}", exc_info=True)
        st.rerun()


def main():
    """Main registration page function."""
    # Initialize database
    try:
        DatabaseManager.initialize()
    except Exception as e:
        logger.error(f"Database initialization failed: {str(e)}")
        # Continue anyway - might already be initialized
    
    # Inject custom CSS
    inject_custom_css()
    
    # Initialize session state
    initialize_session_state()
    
    # Display registration form
    display_registration_form()
    
    # Add some spacing and branding
    st.markdown("---")
    st.markdown(
        "<div style='text-align: center; color: gray;'>"
        "RAG Chatbot - Secure Document Intelligence"
        "</div>",
        unsafe_allow_html=True
    )


if __name__ == "__main__":
    # Ensure logs directory exists
    import os
    os.makedirs('logs', exist_ok=True)
    
    # Run the application
    main()
