"""
Password Reset Page - Request and Reset Password

This page provides a two-step password reset process:
1. Request reset: Enter email to receive reset token
2. Reset password: Enter token and new password to reset
"""

import streamlit as st
import logging
import re
from typing import Tuple
from urllib.parse import parse_qs

from config.settings import settings
from services.auth_service import AuthService, InvalidTokenError
from services.email_service import email_service
from services.database_manager import DatabaseManager
from utils.helpers import setup_logging
from utils.styles import inject_custom_css

# Configure logging
setup_logging('logs/app.log', logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="Password Reset - RAG Chatbot",
    page_icon="🔑",
    layout="centered",
    initial_sidebar_state="collapsed"
)


def initialize_session_state():
    """Initialize session state variables for password reset page."""
    if 'reset_error' not in st.session_state:
        st.session_state.reset_error = None
    
    if 'reset_success' not in st.session_state:
        st.session_state.reset_success = None
    
    if 'reset_step' not in st.session_state:
        st.session_state.reset_step = 'request'  # 'request' or 'reset'
    
    if 'reset_email_sent' not in st.session_state:
        st.session_state.reset_email_sent = False


def calculate_password_strength(password: str) -> Tuple[int, str, str]:
    """
    Calculate password strength and return score, label, and color.
    
    Args:
        password: Password to evaluate
        
    Returns:
        Tuple[int, str, str]: (score 0-100, label, color)
    """
    if not password:
        return 0, "No password", "red"
    
    score = 0
    
    # Length check (up to 40 points)
    length = len(password)
    if length >= 8:
        score += min(length * 2, 40)
    
    # Uppercase letter (20 points)
    if re.search(r'[A-Z]', password):
        score += 20
    
    # Lowercase letter (20 points)
    if re.search(r'[a-z]', password):
        score += 20
    
    # Number (20 points)
    if re.search(r'\d', password):
        score += 20
    
    # Special character (bonus 10 points)
    if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        score += 10
    
    # Determine label and color
    if score < 40:
        label = "Weak"
        color = "red"
    elif score < 70:
        label = "Fair"
        color = "orange"
    elif score < 90:
        label = "Good"
        color = "yellow"
    else:
        label = "Strong"
        color = "green"
    
    return score, label, color


def display_password_strength_indicator(password: str):
    """
    Display a real-time password strength indicator.
    
    Args:
        password: Current password value
    """
    score, label, color = calculate_password_strength(password)
    
    # Create progress bar
    progress_html = f"""
    <div style="margin: 10px 0;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
            <span style="font-size: 14px; font-weight: 500;">Password Strength:</span>
            <span style="font-size: 14px; font-weight: 600; color: {color};">{label}</span>
        </div>
        <div style="width: 100%; background-color: #e0e0e0; border-radius: 10px; height: 8px;">
            <div style="width: {score}%; background-color: {color}; border-radius: 10px; height: 8px; transition: width 0.3s;"></div>
        </div>
    </div>
    """
    st.markdown(progress_html, unsafe_allow_html=True)
    
    # Show requirements if password is weak
    if score < 100 and password:
        is_valid, error_msg = AuthService.validate_password_strength(password)
        if not is_valid:
            st.caption(f"⚠️ {error_msg}")


def display_reset_request_form():
    """Display the password reset request form (Step 1)."""
    st.title("🔑 Reset Password")
    st.markdown("Enter your email address and we'll send you a link to reset your password.")
    st.markdown("---")
    
    # Display any error messages
    if st.session_state.reset_error:
        st.error(st.session_state.reset_error)
    
    # Display success message if email was sent
    if st.session_state.reset_email_sent:
        st.success(
            "✅ Password reset instructions have been sent to your email address. "
            "Please check your inbox and follow the link to reset your password."
        )
        st.info(
            f"The reset link will expire in {settings.RESET_TOKEN_EXPIRY_HOURS} hour(s). "
            "If you don't receive the email, please check your spam folder."
        )
        st.markdown("---")
        
        # Option to enter token manually
        st.markdown("### Already have a reset token?")
        if st.button("Enter Reset Token", use_container_width=True):
            st.session_state.reset_step = 'reset'
            st.session_state.reset_email_sent = False
            st.rerun()
    else:
        # Reset request form
        with st.form("reset_request_form", clear_on_submit=False):
            email = st.text_input(
                "Email Address",
                placeholder="your.email@example.com",
                help="Enter the email address associated with your account"
            )
            
            st.markdown("")  # Add spacing
            
            # Submit button
            submit_button = st.form_submit_button(
                "📧 Send Reset Link",
                type="primary",
                use_container_width=True
            )
            
            if submit_button:
                handle_reset_request(email)
        
        st.markdown("---")
        
        # Option to enter token manually if already received
        st.markdown("### Already have a reset token?")
        if st.button("Enter Reset Token", use_container_width=True):
            st.session_state.reset_step = 'reset'
            st.rerun()
    
    # Back to login link
    st.markdown("---")
    if st.button("← Back to Login", use_container_width=True):
        st.switch_page("pages/Login.py")


def display_reset_form():
    """Display the password reset form (Step 2)."""
    st.title("🔑 Reset Your Password")
    st.markdown("Enter your reset token and choose a new password.")
    st.markdown("---")
    
    # Display any error messages
    if st.session_state.reset_error:
        st.error(st.session_state.reset_error)
    
    # Display any success messages
    if st.session_state.reset_success:
        st.success(st.session_state.reset_success)
        st.markdown("---")
        if st.button("Go to Login", type="primary", use_container_width=True):
            st.switch_page("pages/Login.py")
        return
    
    # Reset form
    with st.form("reset_form", clear_on_submit=False):
        token = st.text_input(
            "Reset Token",
            placeholder="Enter the token from your email",
            help="Copy the token from the reset email you received"
        )
        
        new_password = st.text_input(
            "New Password",
            type="password",
            placeholder="Create a strong password",
            help=f"Minimum {settings.PASSWORD_MIN_LENGTH} characters with uppercase, lowercase, and number"
        )
        
        confirm_password = st.text_input(
            "Confirm New Password",
            type="password",
            placeholder="Re-enter your new password",
            help="Must match the password above"
        )
        
        st.markdown("")  # Add spacing
        
        # Submit button
        submit_button = st.form_submit_button(
            "✅ Reset Password",
            type="primary",
            use_container_width=True
        )
        
        if submit_button:
            handle_password_reset(token, new_password, confirm_password)
    
    # Show password strength indicator for the new password
    if new_password:
        display_password_strength_indicator(new_password)
    
    # Additional options
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("← Request New Token", use_container_width=True):
            st.session_state.reset_step = 'request'
            st.session_state.reset_error = None
            st.session_state.reset_email_sent = False
            st.rerun()
    
    with col2:
        if st.button("Back to Login", use_container_width=True):
            st.switch_page("pages/Login.py")


def handle_reset_request(email: str):
    """
    Handle password reset request form submission.
    
    Args:
        email: User's email address
    """
    # Clear previous messages
    st.session_state.reset_error = None
    st.session_state.reset_email_sent = False
    
    # Validate input
    if not email or not email.strip():
        st.session_state.reset_error = "Please enter your email address"
        st.rerun()
        return
    
    # Validate email format
    email_valid, email_error = AuthService.validate_email(email.strip())
    if not email_valid:
        st.session_state.reset_error = email_error
        st.rerun()
        return
    
    try:
        # Create reset token
        token = AuthService.create_password_reset_token(email.strip())
        
        # Always show success message (don't reveal if email exists)
        # This prevents user enumeration attacks
        if token:
            # Send reset email
            email_sent = email_service.send_password_reset_email(
                email=email.strip(),
                reset_token=token
            )
            
            if email_sent:
                logger.info(f"Password reset email sent to: {email}")
            else:
                logger.warning(f"Failed to send password reset email to: {email}")
        else:
            # Token is None (user doesn't exist), but we don't reveal this
            logger.info(f"Password reset requested for non-existent email: {email}")
        
        # Always show success message
        st.session_state.reset_email_sent = True
        st.rerun()
        
    except Exception as e:
        # Log error but show generic message
        logger.error(f"Error processing password reset request: {str(e)}", exc_info=True)
        st.session_state.reset_error = "An error occurred. Please try again."
        st.rerun()


def handle_password_reset(token: str, new_password: str, confirm_password: str):
    """
    Handle password reset form submission.
    
    Args:
        token: Reset token
        new_password: New password
        confirm_password: Password confirmation
    """
    # Clear previous messages
    st.session_state.reset_error = None
    st.session_state.reset_success = None
    
    # Validate inputs
    if not token or not token.strip():
        st.session_state.reset_error = "Please enter your reset token"
        st.rerun()
        return
    
    if not new_password:
        st.session_state.reset_error = "Please enter a new password"
        st.rerun()
        return
    
    # Validate password strength
    password_valid, password_error = AuthService.validate_password_strength(new_password)
    if not password_valid:
        st.session_state.reset_error = password_error
        st.rerun()
        return
    
    if not confirm_password:
        st.session_state.reset_error = "Please confirm your new password"
        st.rerun()
        return
    
    # Check password match
    if new_password != confirm_password:
        st.session_state.reset_error = "Passwords do not match"
        st.rerun()
        return
    
    try:
        # Reset password
        success = AuthService.reset_password(token.strip(), new_password)
        
        if success:
            logger.info("Password reset successfully")
            st.session_state.reset_success = (
                "✅ Your password has been reset successfully! "
                "You can now log in with your new password."
            )
            st.rerun()
        else:
            st.session_state.reset_error = "Failed to reset password. Please try again."
            st.rerun()
        
    except InvalidTokenError as e:
        # Invalid or expired token
        error_message = str(e)
        st.session_state.reset_error = error_message
        logger.warning(f"Invalid token used for password reset: {error_message}")
        st.rerun()
        
    except ValueError as e:
        # Password validation error
        st.session_state.reset_error = str(e)
        st.rerun()
        
    except Exception as e:
        # Unexpected error
        st.session_state.reset_error = "An unexpected error occurred. Please try again."
        logger.error(f"Unexpected error during password reset: {str(e)}", exc_info=True)
        st.rerun()


def check_url_token():
    """Check if a reset token was provided in the URL query parameters."""
    try:
        # Get query parameters from URL
        query_params = st.query_params
        
        if 'token' in query_params:
            token = query_params['token']
            if token:
                # Switch to reset form step
                st.session_state.reset_step = 'reset'
                # Store token in session state for pre-filling
                st.session_state.url_token = token
                logger.info("Reset token found in URL")
    except Exception as e:
        logger.error(f"Error checking URL token: {str(e)}")


def main():
    """Main password reset page function."""
    # Initialize database
    try:
        DatabaseManager.initialize()
    except Exception as e:
        logger.error(f"Database initialization failed: {str(e)}")
        # Continue anyway - might already be initialized
    
    # Inject custom CSS
    inject_custom_css()
    
    # Initialize session state
    initialize_session_state()
    
    # Check for token in URL
    check_url_token()
    
    # Display appropriate form based on step
    if st.session_state.reset_step == 'request':
        display_reset_request_form()
    else:
        display_reset_form()
    
    # Add some spacing and branding
    st.markdown("---")
    st.markdown(
        "<div style='text-align: center; color: gray;'>"
        "RAG Chatbot - Secure Document Intelligence"
        "</div>",
        unsafe_allow_html=True
    )


if __name__ == "__main__":
    # Ensure logs directory exists
    import os
    os.makedirs('logs', exist_ok=True)
    
    # Run the application
    main()
