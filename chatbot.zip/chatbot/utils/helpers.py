"""
Error handling utilities and helper functions.

This module provides centralized error handling utilities, custom exceptions,
and helper functions for consistent error management across the application.
"""

import logging
import functools
from typing import Callable, Any, Optional
from datetime import datetime


logger = logging.getLogger(__name__)


# Custom Exception Classes
class ValidationError(Exception):
    """Raised when input validation fails."""
    pass


class DocumentProcessingError(Exception):
    """Raised when document processing fails."""
    pass


class VectorStoreError(Exception):
    """Raised when vector store operations fail."""
    pass


class LLMError(Exception):
    """Raised when LLM API calls fail."""
    pass


class ConfigurationError(Exception):
    """Raised when configuration is invalid or missing."""
    pass


def setup_logging(log_file: str = 'logs/app.log', log_level: int = logging.INFO) -> None:
    """
    Set up Python logging configuration with file and console output.
    
    Args:
        log_file: Path to the log file
        log_level: Logging level (default: INFO)
    """
    import os
    
    # Ensure logs directory exists
    log_dir = os.path.dirname(log_file)
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)
    
    # Configure logging format
    log_format = '[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'
    date_format = '%Y-%m-%d %H:%M:%S'
    
    # Configure root logger
    logging.basicConfig(
        level=log_level,
        format=log_format,
        datefmt=date_format,
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler()
        ],
        force=True  # Override any existing configuration
    )
    
    logger.info(f"Logging configured: {log_file}")


def log_exception(func: Callable) -> Callable:
    """
    Decorator to log exceptions with context information.
    
    This decorator catches exceptions, logs them with full context including
    function name, arguments, and timestamp, then re-raises the exception.
    
    Args:
        func: Function to wrap with exception logging
        
    Returns:
        Wrapped function with exception logging
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            # Log exception with context
            logger.error(
                f"Exception in {func.__name__}: {type(e).__name__}: {str(e)}",
                exc_info=True,
                extra={
                    'function': func.__name__,
                    'function_args': str(args)[:200],  # Limit arg length in logs
                    'function_kwargs': str(kwargs)[:200],
                    'error_timestamp': datetime.now().isoformat()
                }
            )
            raise
    return wrapper


def handle_errors(
    default_return: Any = None,
    error_message: str = "An error occurred",
    log_error: bool = True
) -> Callable:
    """
    Decorator to handle errors gracefully with custom error messages.
    
    This decorator catches exceptions and returns a default value instead of
    raising, while optionally logging the error. Useful for non-critical operations.
    
    Args:
        default_return: Value to return if an exception occurs
        error_message: Custom error message to log
        log_error: Whether to log the error (default: True)
        
    Returns:
        Wrapped function with error handling
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                if log_error:
                    logger.error(
                        f"{error_message} in {func.__name__}: {type(e).__name__}: {str(e)}",
                        exc_info=True
                    )
                return default_return
        return wrapper
    return decorator


def validate_not_empty(value: str, field_name: str = "Field") -> str:
    """
    Validate that a string value is not empty.
    
    Args:
        value: String value to validate
        field_name: Name of the field for error message
        
    Returns:
        The validated string value
        
    Raises:
        ValidationError: If value is None or empty
    """
    if value is None or not value.strip():
        raise ValidationError(f"{field_name} cannot be empty")
    return value.strip()


def validate_file_format(filename: str, supported_formats: list) -> str:
    """
    Validate that a file has a supported format.
    
    Args:
        filename: Name of the file to validate
        supported_formats: List of supported file extensions (e.g., ['.pdf', '.txt'])
        
    Returns:
        The file extension
        
    Raises:
        ValidationError: If file format is not supported
    """
    from pathlib import Path
    
    file_ext = Path(filename).suffix.lower()
    if file_ext not in supported_formats:
        raise ValidationError(
            f"Unsupported file format '{file_ext}'. "
            f"Supported formats: {', '.join(supported_formats)}"
        )
    return file_ext


def validate_file_size(file_size: int, max_size_mb: int) -> None:
    """
    Validate that a file size is within limits.
    
    Args:
        file_size: File size in bytes
        max_size_mb: Maximum allowed size in megabytes
        
    Raises:
        ValidationError: If file size exceeds limit
    """
    max_size_bytes = max_size_mb * 1024 * 1024
    if file_size > max_size_bytes:
        actual_size_mb = file_size / (1024 * 1024)
        raise ValidationError(
            f"File size ({actual_size_mb:.2f}MB) exceeds maximum limit of {max_size_mb}MB"
        )


def format_error_message(error: Exception, user_friendly: bool = True) -> str:
    """
    Format an exception into a user-friendly or detailed error message.
    
    Args:
        error: Exception to format
        user_friendly: If True, return simplified message; if False, include details
        
    Returns:
        Formatted error message string
    """
    error_type = type(error).__name__
    error_msg = str(error)
    
    if user_friendly:
        # Map technical errors to user-friendly messages
        if isinstance(error, ValidationError):
            return f"Validation Error: {error_msg}"
        elif isinstance(error, DocumentProcessingError):
            return "Failed to process the document. Please ensure the file is not corrupted."
        elif isinstance(error, VectorStoreError):
            return "Database error occurred. Please try again."
        elif isinstance(error, LLMError):
            return "AI service error. Please try again in a moment."
        elif isinstance(error, ConfigurationError):
            return "System configuration error. Please contact support."
        elif "rate limit" in error_msg.lower():
            return "Service rate limit reached. Please wait a moment and try again."
        elif "api key" in error_msg.lower():
            return "API authentication error. Please check your configuration."
        elif "timeout" in error_msg.lower():
            return "Request timed out. Please try again."
        else:
            return "An unexpected error occurred. Please try again."
    else:
        # Return detailed error message for logging
        return f"{error_type}: {error_msg}"


def retry_on_failure(
    max_attempts: int = 2,
    delay_seconds: float = 1.0,
    exceptions: tuple = (Exception,)
) -> Callable:
    """
    Decorator to retry a function on failure with exponential backoff.
    
    Args:
        max_attempts: Maximum number of retry attempts
        delay_seconds: Initial delay between retries in seconds
        exceptions: Tuple of exception types to catch and retry
        
    Returns:
        Wrapped function with retry logic
    """
    import time
    
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            attempt = 1
            current_delay = delay_seconds
            
            while attempt <= max_attempts:
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    if attempt == max_attempts:
                        logger.error(
                            f"Failed after {max_attempts} attempts in {func.__name__}: {str(e)}"
                        )
                        raise
                    
                    logger.warning(
                        f"Attempt {attempt}/{max_attempts} failed in {func.__name__}: {str(e)}. "
                        f"Retrying in {current_delay}s..."
                    )
                    
                    time.sleep(current_delay)
                    current_delay *= 2  # Exponential backoff
                    attempt += 1
            
        return wrapper
    return decorator


def safe_execute(func: Callable, *args, **kwargs) -> tuple[bool, Any, Optional[Exception]]:
    """
    Safely execute a function and return success status, result, and any exception.
    
    This is useful for operations where you want to handle errors without raising.
    
    Args:
        func: Function to execute
        *args: Positional arguments for the function
        **kwargs: Keyword arguments for the function
        
    Returns:
        Tuple of (success: bool, result: Any, error: Optional[Exception])
    """
    try:
        result = func(*args, **kwargs)
        return True, result, None
    except Exception as e:
        logger.error(f"Error in safe_execute for {func.__name__}: {str(e)}")
        return False, None, e
