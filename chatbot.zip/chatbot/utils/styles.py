"""
Custom CSS Styles for RAG Chatbot Application

This module provides centralized CSS styling for all UI components including:
- Login/Registration pages
- Password strength indicator
- Typing indicator animation
- Session selector and chat UI
- Admin dashboard tabs and tables
- Responsive design for all pages
"""


def get_custom_css() -> str:
    """
    Get the complete custom CSS for the application.
    
    Returns:
        str: CSS styles as a string
    """
    return """
    <style>
    /* ========================================
       GLOBAL STYLES
       ======================================== */
    
    /* Smooth transitions for all elements */
    * {
        transition: all 0.3s ease;
    }
    
    /* Custom scrollbar styling */
    ::-webkit-scrollbar {
        width: 10px;
        height: 10px;
    }
    
    ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb {
        background: #888;
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: #555;
    }
    
    /* ========================================
       AUTHENTICATION PAGES (Login/Register/Password Reset)
       ======================================== */
    
    /* Form container styling */
    .auth-container {
        max-width: 500px;
        margin: 0 auto;
        padding: 2rem;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    }
    
    /* Form input styling */
    .stTextInput > div > div > input,
    .stTextArea > div > div > textarea {
        border-radius: 8px;
        border: 2px solid #e0e0e0;
        padding: 12px;
        font-size: 16px;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }
    
    .stTextInput > div > div > input:focus,
    .stTextArea > div > div > textarea:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }
    
    /* Button styling */
    .stButton > button {
        border-radius: 8px;
        padding: 12px 24px;
        font-weight: 600;
        font-size: 16px;
        transition: all 0.3s ease;
        border: none;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    }
    
    .stButton > button[kind="primary"] {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
    }
    
    .stButton > button[kind="primary"]:hover {
        background: linear-gradient(135deg, #5568d3 0%, #653a8b 100%);
    }
    
    /* Form submit button */
    .stForm button[type="submit"] {
        width: 100%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        padding: 14px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 16px;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .stForm button[type="submit"]:hover {
        background: linear-gradient(135deg, #5568d3 0%, #653a8b 100%);
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    }
    
    /* ========================================
       PASSWORD STRENGTH INDICATOR
       ======================================== */
    
    .password-strength-container {
        margin: 15px 0;
        padding: 10px;
        background: #f8f9fa;
        border-radius: 8px;
    }
    
    .password-strength-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 8px;
        font-size: 14px;
    }
    
    .password-strength-label {
        font-weight: 500;
        color: #333;
    }
    
    .password-strength-value {
        font-weight: 600;
    }
    
    .password-strength-value.weak {
        color: #dc3545;
    }
    
    .password-strength-value.fair {
        color: #fd7e14;
    }
    
    .password-strength-value.good {
        color: #ffc107;
    }
    
    .password-strength-value.strong {
        color: #28a745;
    }
    
    .password-strength-bar {
        width: 100%;
        height: 8px;
        background-color: #e0e0e0;
        border-radius: 10px;
        overflow: hidden;
    }
    
    .password-strength-fill {
        height: 100%;
        border-radius: 10px;
        transition: width 0.3s ease, background-color 0.3s ease;
    }
    
    .password-strength-fill.weak {
        background-color: #dc3545;
    }
    
    .password-strength-fill.fair {
        background-color: #fd7e14;
    }
    
    .password-strength-fill.good {
        background-color: #ffc107;
    }
    
    .password-strength-fill.strong {
        background-color: #28a745;
    }
    
    .password-requirements {
        margin-top: 10px;
        font-size: 12px;
        color: #666;
    }
    
    .password-requirements ul {
        margin: 5px 0;
        padding-left: 20px;
    }
    
    .password-requirements li {
        margin: 3px 0;
    }
    
    .password-requirements .met {
        color: #28a745;
    }
    
    .password-requirements .unmet {
        color: #dc3545;
    }
    
    /* ========================================
       TYPING INDICATOR ANIMATION
       ======================================== */
    
    .typing-indicator {
        display: flex;
        align-items: center;
        padding: 10px 15px;
        background: #f0f2f6;
        border-radius: 18px;
        width: fit-content;
        margin: 10px 0;
    }
    
    .typing-indicator span {
        height: 10px;
        width: 10px;
        margin: 0 3px;
        background-color: #888;
        border-radius: 50%;
        display: inline-block;
        animation: typing-bounce 1.4s infinite ease-in-out;
    }
    
    .typing-indicator span:nth-child(1) {
        animation-delay: 0s;
    }
    
    .typing-indicator span:nth-child(2) {
        animation-delay: 0.2s;
    }
    
    .typing-indicator span:nth-child(3) {
        animation-delay: 0.4s;
    }
    
    @keyframes typing-bounce {
        0%, 60%, 100% {
            transform: translateY(0);
            opacity: 0.7;
        }
        30% {
            transform: translateY(-10px);
            opacity: 1;
        }
    }
    
    /* ========================================
       CHAT UI ENHANCEMENTS
       ======================================== */
    
    /* Message container */
    .stChatMessage {
        animation: message-fade-in 0.3s ease-in;
        margin-bottom: 1rem;
    }
    
    @keyframes message-fade-in {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    /* Message sending feedback */
    .message-sending {
        opacity: 0.7;
        transition: opacity 0.3s ease;
    }
    
    /* User avatar styling */
    .stChatMessage [data-testid="chatAvatarIcon-user"] {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    
    .stChatMessage [data-testid="chatAvatarIcon-assistant"] {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    }
    
    /* Message timestamp */
    .message-timestamp {
        font-size: 12px;
        color: #888;
        margin-top: 5px;
        font-style: italic;
    }
    
    /* Sources display */
    .message-sources {
        margin-top: 10px;
        padding: 10px;
        background: #f8f9fa;
        border-left: 3px solid #667eea;
        border-radius: 5px;
        font-size: 13px;
    }
    
    .message-sources-title {
        font-weight: 600;
        color: #667eea;
        margin-bottom: 5px;
    }
    
    /* ========================================
       SESSION SELECTOR
       ======================================== */
    
    .session-selector-container {
        background: #ffffff;
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 20px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    }
    
    .session-selector-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
    }
    
    .session-selector-title {
        font-weight: 600;
        font-size: 16px;
        color: #333;
    }
    
    .session-item {
        padding: 12px;
        margin: 8px 0;
        background: #f8f9fa;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.2s ease;
        border-left: 3px solid transparent;
    }
    
    .session-item:hover {
        background: #e9ecef;
        border-left-color: #667eea;
        transform: translateX(5px);
    }
    
    .session-item.active {
        background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
        border-left-color: #667eea;
        font-weight: 600;
    }
    
    .session-item-title {
        font-weight: 500;
        color: #333;
        margin-bottom: 5px;
    }
    
    .session-item-meta {
        font-size: 12px;
        color: #666;
    }
    
    /* ========================================
       ADMIN DASHBOARD
       ======================================== */
    
    /* Tab styling */
    .stTabs [data-baseweb="tab-list"] {
        gap: 10px;
        background: #f8f9fa;
        padding: 10px;
        border-radius: 10px;
    }
    
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        padding: 0 24px;
        background: white;
        border-radius: 8px;
        font-weight: 500;
        border: 2px solid transparent;
        transition: all 0.3s ease;
    }
    
    .stTabs [data-baseweb="tab"]:hover {
        background: #e9ecef;
        border-color: #667eea;
    }
    
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white !important;
        border-color: transparent;
    }
    
    /* Table styling */
    .admin-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0 10px;
    }
    
    .admin-table-row {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        transition: all 0.3s ease;
        margin-bottom: 10px;
        padding: 15px;
    }
    
    .admin-table-row:hover {
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        transform: translateY(-2px);
    }
    
    .admin-table-header {
        font-weight: 600;
        color: #333;
        padding: 10px 15px;
        background: #f8f9fa;
        border-radius: 8px;
        margin-bottom: 10px;
    }
    
    /* Metric cards */
    .metric-card {
        background: white;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        transition: all 0.3s ease;
    }
    
    .metric-card:hover {
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        transform: translateY(-5px);
    }
    
    .metric-value {
        font-size: 32px;
        font-weight: 700;
        color: #667eea;
        margin: 10px 0;
    }
    
    .metric-label {
        font-size: 14px;
        color: #666;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    
    .metric-delta {
        font-size: 14px;
        font-weight: 600;
        margin-top: 5px;
    }
    
    .metric-delta.positive {
        color: #28a745;
    }
    
    .metric-delta.negative {
        color: #dc3545;
    }
    
    /* Status indicators */
    .status-badge {
        display: inline-block;
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .status-badge.success {
        background: #d4edda;
        color: #155724;
    }
    
    .status-badge.warning {
        background: #fff3cd;
        color: #856404;
    }
    
    .status-badge.error {
        background: #f8d7da;
        color: #721c24;
    }
    
    .status-badge.info {
        background: #d1ecf1;
        color: #0c5460;
    }
    
    /* Action buttons in tables */
    .action-button {
        padding: 8px 16px;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        border: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .action-button:hover {
        transform: scale(1.05);
    }
    
    .action-button.primary {
        background: #667eea;
        color: white;
    }
    
    .action-button.danger {
        background: #dc3545;
        color: white;
    }
    
    .action-button.success {
        background: #28a745;
        color: white;
    }
    
    /* ========================================
       CHARTS AND VISUALIZATIONS
       ======================================== */
    
    .chart-container {
        background: white;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        margin: 20px 0;
    }
    
    .chart-title {
        font-size: 18px;
        font-weight: 600;
        color: #333;
        margin-bottom: 15px;
    }
    
    /* ========================================
       ALERTS AND NOTIFICATIONS
       ======================================== */
    
    .stAlert {
        border-radius: 10px;
        border-left: 4px solid;
        padding: 15px;
        margin: 15px 0;
        animation: alert-slide-in 0.3s ease;
    }
    
    @keyframes alert-slide-in {
        from {
            opacity: 0;
            transform: translateX(-20px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    
    .stSuccess {
        border-left-color: #28a745;
        background: #d4edda;
    }
    
    .stError {
        border-left-color: #dc3545;
        background: #f8d7da;
    }
    
    .stWarning {
        border-left-color: #ffc107;
        background: #fff3cd;
    }
    
    .stInfo {
        border-left-color: #17a2b8;
        background: #d1ecf1;
    }
    
    /* ========================================
       RESPONSIVE DESIGN
       ======================================== */
    
    /* Tablet and below */
    @media (max-width: 768px) {
        .auth-container {
            padding: 1.5rem;
            margin: 1rem;
        }
        
        .stButton > button {
            width: 100%;
            margin: 5px 0;
        }
        
        .metric-card {
            margin-bottom: 15px;
        }
        
        .admin-table-row {
            padding: 10px;
        }
        
        .session-item {
            padding: 10px;
        }
        
        /* Stack columns on mobile */
        .stColumns {
            flex-direction: column;
        }
        
        .stColumn {
            width: 100% !important;
            margin-bottom: 10px;
        }
    }
    
    /* Mobile */
    @media (max-width: 480px) {
        .auth-container {
            padding: 1rem;
            margin: 0.5rem;
        }
        
        .stButton > button {
            font-size: 14px;
            padding: 10px 20px;
        }
        
        .metric-value {
            font-size: 24px;
        }
        
        .metric-label {
            font-size: 12px;
        }
        
        .typing-indicator span {
            height: 8px;
            width: 8px;
        }
        
        .stTabs [data-baseweb="tab"] {
            padding: 0 12px;
            font-size: 14px;
        }
    }
    
    /* ========================================
       LOADING STATES
       ======================================== */
    
    .loading-spinner {
        display: inline-block;
        width: 20px;
        height: 20px;
        border: 3px solid rgba(102, 126, 234, 0.3);
        border-radius: 50%;
        border-top-color: #667eea;
        animation: spinner-rotate 1s linear infinite;
    }
    
    @keyframes spinner-rotate {
        to {
            transform: rotate(360deg);
        }
    }
    
    /* ========================================
       SIDEBAR ENHANCEMENTS
       ======================================== */
    
    .sidebar-section {
        background: white;
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 15px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
    }
    
    .sidebar-section-title {
        font-weight: 600;
        font-size: 16px;
        color: #333;
        margin-bottom: 10px;
        padding-bottom: 10px;
        border-bottom: 2px solid #f0f2f6;
    }
    
    /* ========================================
       EXPANDER STYLING
       ======================================== */
    
    .streamlit-expanderHeader {
        background: #f8f9fa;
        border-radius: 8px;
        padding: 12px;
        font-weight: 500;
        transition: all 0.3s ease;
    }
    
    .streamlit-expanderHeader:hover {
        background: #e9ecef;
    }
    
    /* ========================================
       FILE UPLOADER STYLING
       ======================================== */
    
    .stFileUploader {
        border: 2px dashed #667eea;
        border-radius: 10px;
        padding: 20px;
        background: #f8f9fa;
        transition: all 0.3s ease;
    }
    
    .stFileUploader:hover {
        border-color: #5568d3;
        background: #e9ecef;
    }
    
    /* ========================================
       DIVIDER STYLING
       ======================================== */
    
    hr {
        margin: 2rem 0;
        border: none;
        height: 2px;
        background: linear-gradient(90deg, transparent, #667eea, transparent);
    }
    
    /* ========================================
       CUSTOM ANIMATIONS
       ======================================== */
    
    @keyframes pulse {
        0%, 100% {
            opacity: 1;
        }
        50% {
            opacity: 0.5;
        }
    }
    
    .pulse {
        animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }
    
    @keyframes slide-up {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .slide-up {
        animation: slide-up 0.5s ease;
    }
    
    /* ========================================
       ACCESSIBILITY IMPROVEMENTS
       ======================================== */
    
    /* Focus indicators */
    button:focus,
    input:focus,
    textarea:focus,
    select:focus {
        outline: 3px solid rgba(102, 126, 234, 0.5);
        outline-offset: 2px;
    }
    
    /* High contrast mode support */
    @media (prefers-contrast: high) {
        .stButton > button {
            border: 2px solid currentColor;
        }
        
        .typing-indicator span {
            background-color: #000;
        }
    }
    
    /* Reduced motion support */
    @media (prefers-reduced-motion: reduce) {
        * {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
        }
    }
    
    </style>
    """


def inject_custom_css():
    """
    Inject custom CSS into the Streamlit app.
    This function should be called in each page's main function.
    """
    import streamlit as st
    st.markdown(get_custom_css(), unsafe_allow_html=True)
