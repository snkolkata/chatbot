"""
Utilities package for the RAG Chatbot application.
"""

from .helpers import (
    ValidationError,
    DocumentProcessingError,
    VectorStoreError,
    LLMError,
    ConfigurationError,
    setup_logging,
    log_exception,
    handle_errors,
    validate_not_empty,
    validate_file_format,
    validate_file_size,
    format_error_message,
    retry_on_failure,
    safe_execute
)

from .auth_guard import (
    AuthenticationError,
    AuthorizationError,
    AccountLockedError,
    SessionExpiredError,
    is_authenticated,
    is_admin,
    get_current_user_id,
    get_current_user_email,
    get_current_user_role,
    check_session_timeout,
    update_last_activity,
    clear_session,
    set_user_session,
    require_auth,
    require_admin,
    require_active_account,
    get_session_info
)

__all__ = [
    # Helper utilities
    'ValidationError',
    'DocumentProcessingError',
    'VectorStoreError',
    'LLMError',
    'ConfigurationError',
    'setup_logging',
    'log_exception',
    'handle_errors',
    'validate_not_empty',
    'validate_file_format',
    'validate_file_size',
    'format_error_message',
    'retry_on_failure',
    'safe_execute',
    # Authentication guards
    'AuthenticationError',
    'AuthorizationError',
    'AccountLockedError',
    'SessionExpiredError',
    'is_authenticated',
    'is_admin',
    'get_current_user_id',
    'get_current_user_email',
    'get_current_user_role',
    'check_session_timeout',
    'update_last_activity',
    'clear_session',
    'set_user_session',
    'require_auth',
    'require_admin',
    'require_active_account',
    'get_session_info'
]
