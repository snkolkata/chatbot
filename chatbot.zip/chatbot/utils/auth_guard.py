"""
Authentication middleware and guards for protecting routes and checking permissions.

This module provides decorators and helper functions for:
- Requiring authentication on protected pages
- Requiring admin role for admin-only pages
- Checking authentication status
- Checking admin role
- Session timeout validation
"""

import streamlit as st
import logging
from functools import wraps
from typing import Callable, Optional
from datetime import datetime, timedelta
from config.settings import settings


logger = logging.getLogger(__name__)


# Custom Exception Classes
class AuthenticationError(Exception):
    """Raised when authentication fails."""
    pass


class AuthorizationError(Exception):
    """Raised when user lacks permissions."""
    pass


class AccountLockedError(Exception):
    """Raised when account is locked."""
    pass


class SessionExpiredError(Exception):
    """Raised when session has expired."""
    pass


def is_authenticated() -> bool:
    """
    Check if the current user is authenticated.
    
    Returns:
        bool: True if user is authenticated, False otherwise
    """
    return 'user_id' in st.session_state and st.session_state.get('user_id') is not None


def is_admin() -> bool:
    """
    Check if the current user has admin role.
    
    Returns:
        bool: True if user is authenticated and has admin role, False otherwise
    """
    if not is_authenticated():
        return False
    return st.session_state.get('role') == 'admin'


def get_current_user_id() -> Optional[str]:
    """
    Get the current authenticated user's ID.
    
    Returns:
        Optional[str]: User ID if authenticated, None otherwise
    """
    if is_authenticated():
        return st.session_state.get('user_id')
    return None


def get_current_user_email() -> Optional[str]:
    """
    Get the current authenticated user's email.
    
    Returns:
        Optional[str]: User email if authenticated, None otherwise
    """
    if is_authenticated():
        return st.session_state.get('email')
    return None


def get_current_user_role() -> Optional[str]:
    """
    Get the current authenticated user's role.
    
    Returns:
        Optional[str]: User role if authenticated, None otherwise
    """
    if is_authenticated():
        return st.session_state.get('role')
    return None


def check_session_timeout() -> bool:
    """
    Check if the current session has timed out.
    
    Validates the session against the configured timeout period.
    If "remember_me" is enabled, uses extended timeout.
    
    Returns:
        bool: True if session is valid, False if timed out
    """
    if not is_authenticated():
        return False
    
    last_activity = st.session_state.get('last_activity')
    if last_activity is None:
        # No last activity timestamp, consider session invalid
        return False
    
    # Determine timeout duration based on remember_me setting
    remember_me = st.session_state.get('remember_me', False)
    if remember_me:
        timeout_duration = timedelta(days=settings.SESSION_REMEMBER_ME_DAYS)
    else:
        timeout_duration = timedelta(hours=settings.SESSION_TIMEOUT_HOURS)
    
    # Check if session has expired
    current_time = datetime.now()
    if isinstance(last_activity, str):
        # Parse string timestamp if needed
        try:
            last_activity = datetime.fromisoformat(last_activity)
        except (ValueError, TypeError):
            logger.error(f"Invalid last_activity timestamp format: {last_activity}")
            return False
    
    time_elapsed = current_time - last_activity
    
    if time_elapsed > timeout_duration:
        logger.info(f"Session timed out for user {get_current_user_id()}")
        return False
    
    return True


def update_last_activity() -> None:
    """
    Update the last activity timestamp for the current session.
    
    This should be called on each page load or user interaction to keep
    the session alive.
    """
    if is_authenticated():
        st.session_state['last_activity'] = datetime.now()


def clear_session() -> None:
    """
    Clear all session data for logout or session expiration.
    
    Removes all authentication-related data from session state.
    Also clears chat-related session data.
    """
    keys_to_clear = [
        'user_id',
        'email',
        'full_name',
        'role',
        'is_active',
        'last_activity',
        'remember_me',
        'authenticated',
        'current_session_id',
        'messages',
        'user_sessions',
        'rag_service',
        'document_service',
        'services_initialized',
        'last_error',
        'admin_document_service',
        'admin_services_initialized',
        'upload_status',
        'delete_confirm'
    ]
    
    for key in keys_to_clear:
        if key in st.session_state:
            del st.session_state[key]
    
    logger.info("Session cleared")


def set_user_session(user_data: dict, remember_me: bool = False) -> None:
    """
    Set user session data after successful authentication.
    
    Args:
        user_data: Dictionary containing user information (user_id, email, full_name, role, is_active)
        remember_me: Whether to extend session timeout
    """
    st.session_state['user_id'] = str(user_data.get('user_id'))
    st.session_state['email'] = user_data.get('email')
    st.session_state['full_name'] = user_data.get('full_name')
    st.session_state['role'] = user_data.get('role', 'user')
    st.session_state['is_active'] = user_data.get('is_active', True)
    st.session_state['remember_me'] = remember_me
    st.session_state['authenticated'] = True
    st.session_state['last_activity'] = datetime.now()
    
    logger.info(f"Session created for user: {user_data.get('email')}")


def require_auth(func: Callable) -> Callable:
    """
    Decorator to require authentication for a page or function.
    
    If the user is not authenticated or session has expired, redirects to login page.
    Updates last activity timestamp on successful authentication check.
    
    Usage:
        @require_auth
        def my_protected_page():
            st.write("This page requires authentication")
    
    Args:
        func: Function to wrap with authentication requirement
        
    Returns:
        Wrapped function with authentication check
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        # Check if user is authenticated
        if not is_authenticated():
            logger.warning("Unauthenticated access attempt")
            st.error("⚠️ You must be logged in to access this page.")
            st.info("Redirecting to login page...")
            
            # Store the attempted page for redirect after login
            if 'redirect_after_login' not in st.session_state:
                st.session_state['redirect_after_login'] = st.session_state.get('current_page', 'Home.py')
            
            # Redirect to login page
            st.switch_page("pages/Login.py")
            return
        
        # Check session timeout
        if not check_session_timeout():
            logger.warning(f"Session expired for user {get_current_user_id()}")
            st.error("⏱️ Your session has expired. Please log in again.")
            logout()
            st.switch_page("pages/Login.py")
            return
        
        # Update last activity timestamp
        update_last_activity()
        
        # Execute the protected function
        return func(*args, **kwargs)
    
    return wrapper


def require_admin(func: Callable) -> Callable:
    """
    Decorator to require admin role for a page or function.
    
    If the user is not authenticated, redirects to login page.
    If the user is authenticated but not an admin, shows access denied error.
    Updates last activity timestamp on successful authorization check.
    
    Usage:
        @require_admin
        def admin_dashboard():
            st.write("This page requires admin privileges")
    
    Args:
        func: Function to wrap with admin requirement
        
    Returns:
        Wrapped function with admin authorization check
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        # Check if user is authenticated
        if not is_authenticated():
            logger.warning("Unauthenticated access attempt to admin page")
            st.error("⚠️ You must be logged in to access this page.")
            st.info("Redirecting to login page...")
            
            # Store the attempted page for redirect after login
            if 'redirect_after_login' not in st.session_state:
                st.session_state['redirect_after_login'] = st.session_state.get('current_page', 'Admin.py')
            
            # Redirect to login page
            st.switch_page("pages/Login.py")
            return
        
        # Check session timeout
        if not check_session_timeout():
            logger.warning(f"Session expired for user {get_current_user_id()}")
            st.error("⏱️ Your session has expired. Please log in again.")
            logout()
            st.switch_page("pages/Login.py")
            return
        
        # Check if user has admin role
        if not is_admin():
            logger.warning(f"Unauthorized admin access attempt by user {get_current_user_id()}")
            st.error("🚫 Access Denied")
            st.warning("You do not have permission to access this page. Admin privileges are required.")
            
            # Provide a way to go back
            if st.button("← Go to Home"):
                st.switch_page("Home.py")
            
            st.stop()
            return
        
        # Update last activity timestamp
        update_last_activity()
        
        # Execute the protected function
        return func(*args, **kwargs)
    
    return wrapper


def require_active_account(func: Callable) -> Callable:
    """
    Decorator to require an active (non-deactivated) account.
    
    Checks if the user's account is active. If deactivated, shows error and logs out.
    
    Usage:
        @require_active_account
        def my_page():
            st.write("This page requires an active account")
    
    Args:
        func: Function to wrap with active account requirement
        
    Returns:
        Wrapped function with active account check
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not is_authenticated():
            st.switch_page("pages/Login.py")
            return
        
        is_active = st.session_state.get('is_active', True)
        if not is_active:
            logger.warning(f"Deactivated account access attempt by user {get_current_user_id()}")
            st.error("🚫 Account Deactivated")
            st.warning("Your account has been deactivated. Please contact support for assistance.")
            logout()
            st.stop()
            return
        
        return func(*args, **kwargs)
    
    return wrapper


def logout() -> None:
    """
    Perform complete logout operation.
    
    This function:
    1. Logs the logout event
    2. Clears all session state data
    3. No database cleanup needed as sessions are managed by updated_at timestamps
    """
    user_email = get_current_user_email()
    user_id = get_current_user_id()
    
    if user_email:
        logger.info(f"User {user_email} (ID: {user_id}) logging out")
    
    # Clear all session data
    clear_session()
    
    logger.info("Logout completed successfully")


def get_session_info() -> dict:
    """
    Get information about the current session.
    
    Returns:
        dict: Dictionary containing session information
    """
    if not is_authenticated():
        return {
            'authenticated': False,
            'user_id': None,
            'email': None,
            'role': None,
            'session_valid': False
        }
    
    return {
        'authenticated': True,
        'user_id': get_current_user_id(),
        'email': get_current_user_email(),
        'role': get_current_user_role(),
        'is_admin': is_admin(),
        'session_valid': check_session_timeout(),
        'last_activity': st.session_state.get('last_activity'),
        'remember_me': st.session_state.get('remember_me', False)
    }
