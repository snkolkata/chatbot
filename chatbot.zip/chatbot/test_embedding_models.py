"""Test different Gemini embedding models"""
import os
from dotenv import load_dotenv
from langchain_google_genai import GoogleGenerativeAIEmbeddings

load_dotenv(override=True)
api_key = os.getenv('GEMINI_API_KEY')

models_to_test = [
    "models/text-embedding-004",
    "models/embedding-001", 
    "models/embedding-gecko-001"
]

print("Testing Gemini Embedding Models")
print("="*60)

for model in models_to_test:
    print(f"\nTesting: {model}")
    try:
        embeddings = GoogleGenerativeAIEmbeddings(
            model=model,
            google_api_key=api_key
        )
        result = embeddings.embed_query("test")
        print(f"  ✓ SUCCESS! Dimension: {len(result)}")
    except Exception as e:
        error_msg = str(e)
        if "429" in error_msg or "quota" in error_msg.lower():
            print(f"  ✗ QUOTA EXCEEDED")
        elif "404" in error_msg or "not found" in error_msg.lower():
            print(f"  ✗ MODEL NOT FOUND")
        else:
            print(f"  ✗ ERROR: {error_msg[:100]}")

print("\n" + "="*60)
