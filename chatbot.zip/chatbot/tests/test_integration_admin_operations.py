"""
Integration tests for admin operations.
Tests user role changes, user deletion with cascade, and session viewing.
Requirements: 3.3, 3.4, 7.2
"""
import pytest
from datetime import datetime
from unittest.mock import patch, MagicMock
import uuid

from services.user_service import UserService
from services.session_service import SessionService
from services.models import User, ChatSession, ChatMessage


@pytest.fixture
def mock_db_session():
    """Create a mock database session for integration tests."""
    session = MagicMock()
    session.commit = MagicMock()
    session.rollback = MagicMock()
    session.close = MagicMock()
    session.add = MagicMock()
    session.delete = MagicMock()
    session.flush = MagicMock()
    return session


@pytest.fixture
def sample_user():
    """Create a sample regular user for testing."""
    user = User(
        user_id=str(uuid.uuid4()),
        email="user@example.com",
        password_hash="hashed_password",
        full_name="Regular User",
        role="user",
        is_active=True,
        failed_login_attempts=0,
        account_locked_until=None,
        created_at=datetime.utcnow(),
        last_login=datetime.utcnow()
    )
    return user


@pytest.fixture
def sample_admin():
    """Create a sample admin user for testing."""
    admin = User(
        user_id=str(uuid.uuid4()),
        email="admin@example.com",
        password_hash="hashed_password",
        full_name="Admin User",
        role="admin",
        is_active=True,
        failed_login_attempts=0,
        account_locked_until=None,
        created_at=datetime.utcnow(),
        last_login=datetime.utcnow()
    )
    return admin


class TestUserRoleChanges:
    """Test admin operations for changing user roles."""
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_promote_user_to_admin(self, mock_get_session, mock_db_session, sample_user):
        """Test promoting a regular user to admin role."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Verify initial role
        assert sample_user.role == "user"
        
        # Promote to admin
        result = UserService.update_user_role(sample_user.user_id, "admin")
        
        assert result is True
        assert sample_user.role == "admin"
        mock_db_session.commit.assert_called()
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_demote_admin_to_user(self, mock_get_session, mock_db_session, sample_admin):
        """Test demoting an admin to regular user role."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_admin
        
        # Verify initial role
        assert sample_admin.role == "admin"
        
        # Demote to user
        result = UserService.update_user_role(sample_admin.user_id, "user")
        
        assert result is True
        assert sample_admin.role == "user"
        mock_db_session.commit.assert_called()
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_role_change_invalid_role(self, mock_get_session, mock_db_session, sample_user):
        """Test that invalid role changes are rejected."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Attempt to set invalid role
        with pytest.raises(ValueError, match="Invalid role"):
            UserService.update_user_role(sample_user.user_id, "superuser")
        
        # Verify role unchanged
        assert sample_user.role == "user"
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_get_all_users_with_role_filter(self, mock_get_session, mock_db_session, sample_user, sample_admin):
        """Test filtering users by role."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Mock query chain for admin filter
        mock_query = MagicMock()
        mock_query.filter.return_value = mock_query
        mock_query.count.return_value = 1
        mock_query.order_by.return_value.offset.return_value.limit.return_value.all.return_value = [sample_admin]
        mock_db_session.query.return_value = mock_query
        
        # Get admin users
        admins, total = UserService.get_all_users(role_filter="admin")
        
        assert len(admins) == 1
        assert total == 1
        assert admins[0]["role"] == "admin"
        assert admins[0]["email"] == "admin@example.com"


class TestUserActivationDeactivation:
    """Test admin operations for activating/deactivating users."""
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_deactivate_user_account(self, mock_get_session, mock_db_session, sample_user):
        """Test deactivating a user account."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Verify user is active
        assert sample_user.is_active is True
        
        # Deactivate user
        result = UserService.deactivate_user(sample_user.user_id)
        
        assert result is True
        assert sample_user.is_active is False
        mock_db_session.commit.assert_called()
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_activate_user_account(self, mock_get_session, mock_db_session, sample_user):
        """Test activating a deactivated user account."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Set user as inactive
        sample_user.is_active = False
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Activate user
        result = UserService.activate_user(sample_user.user_id)
        
        assert result is True
        assert sample_user.is_active is True
        mock_db_session.commit.assert_called()


class TestUserDeletionWithCascade:
    """Test user deletion with cascade to sessions and messages."""
    
    @patch('services.user_service.DatabaseManager.get_session')
    @patch('services.session_service.DatabaseManager.get_session')
    def test_delete_user_cascades_to_sessions(
        self, mock_session_get_session, mock_user_get_session, 
        mock_db_session, sample_user
    ):
        """Test that deleting a user cascades to delete their sessions."""
        # Setup mocks
        mock_user_get_session.return_value.__enter__.return_value = mock_db_session
        mock_session_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create user sessions
        session_1 = ChatSession(
            session_id=str(uuid.uuid4()),
            user_id=sample_user.user_id,
            title="Session 1",
            is_active=True,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        session_2 = ChatSession(
            session_id=str(uuid.uuid4()),
            user_id=sample_user.user_id,
            title="Session 2",
            is_active=True,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        # Step 1: Verify user has sessions
        mock_query = MagicMock()
        mock_query.outerjoin.return_value = mock_query
        mock_query.filter.return_value = mock_query
        mock_query.group_by.return_value = mock_query
        mock_query.order_by.return_value = mock_query
        mock_query.all.return_value = [(session_1, 5), (session_2, 3)]
        mock_db_session.query.return_value = mock_query
        
        sessions_before = SessionService.get_user_sessions(sample_user.user_id)
        assert len(sessions_before) == 2
        
        # Step 2: Delete user
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        result = UserService.delete_user(sample_user.user_id)
        
        assert result is True
        mock_db_session.delete.assert_called_once_with(sample_user)
        mock_db_session.commit.assert_called()
        
        # Step 3: Verify sessions would be deleted (cascade handled by database)
        # In real database, CASCADE DELETE would remove sessions automatically
        # Here we verify the user deletion was called
        assert mock_db_session.delete.called
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_delete_user_with_no_sessions(self, mock_get_session, mock_db_session, sample_user):
        """Test deleting a user with no sessions."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Delete user
        result = UserService.delete_user(sample_user.user_id)
        
        assert result is True
        mock_db_session.delete.assert_called_once_with(sample_user)
        mock_db_session.commit.assert_called()
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_delete_nonexistent_user(self, mock_get_session, mock_db_session):
        """Test deleting a non-existent user returns False."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Attempt to delete non-existent user
        result = UserService.delete_user("non-existent-id")
        
        assert result is False
        mock_db_session.delete.assert_not_called()


class TestSessionViewing:
    """Test admin operations for viewing user sessions."""
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_admin_view_user_sessions(self, mock_get_session, mock_db_session, sample_user):
        """Test admin viewing all sessions for a specific user."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create user sessions
        session_1 = ChatSession(
            session_id=str(uuid.uuid4()),
            user_id=sample_user.user_id,
            title="Python Questions",
            is_active=True,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        session_2 = ChatSession(
            session_id=str(uuid.uuid4()),
            user_id=sample_user.user_id,
            title="JavaScript Questions",
            is_active=True,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        # Mock query to return sessions
        mock_query = MagicMock()
        mock_query.outerjoin.return_value = mock_query
        mock_query.filter.return_value = mock_query
        mock_query.group_by.return_value = mock_query
        mock_query.order_by.return_value = mock_query
        mock_query.all.return_value = [(session_1, 10), (session_2, 5)]
        mock_db_session.query.return_value = mock_query
        
        # Get user sessions
        sessions = SessionService.get_user_sessions(sample_user.user_id)
        
        assert len(sessions) == 2
        assert sessions[0]["session_id"] == session_1.session_id
        assert sessions[0]["title"] == "Python Questions"
        assert sessions[0]["message_count"] == 10
        assert sessions[1]["session_id"] == session_2.session_id
        assert sessions[1]["title"] == "JavaScript Questions"
        assert sessions[1]["message_count"] == 5
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_admin_view_session_messages(self, mock_get_session, mock_db_session):
        """Test admin viewing messages in a specific session."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create session messages
        session_id = str(uuid.uuid4())
        messages = [
            ChatMessage(
                message_id=str(uuid.uuid4()),
                session_id=session_id,
                role="user",
                content="What is Python?",
                sources=None,
                created_at=datetime.utcnow()
            ),
            ChatMessage(
                message_id=str(uuid.uuid4()),
                session_id=session_id,
                role="assistant",
                content="Python is a high-level programming language...",
                sources=[{"document": "python_guide.pdf", "page": 1}],
                created_at=datetime.utcnow()
            ),
            ChatMessage(
                message_id=str(uuid.uuid4()),
                session_id=session_id,
                role="user",
                content="Can you give me an example?",
                sources=None,
                created_at=datetime.utcnow()
            )
        ]
        
        # Mock query to return messages
        mock_db_session.query.return_value.filter.return_value.order_by.return_value.all.return_value = messages
        
        # Get session messages
        retrieved_messages = SessionService.get_session_messages(session_id)
        
        assert len(retrieved_messages) == 3
        assert retrieved_messages[0]["role"] == "user"
        assert retrieved_messages[0]["content"] == "What is Python?"
        assert retrieved_messages[1]["role"] == "assistant"
        assert retrieved_messages[1]["sources"] is not None
        assert retrieved_messages[2]["role"] == "user"
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_admin_get_all_users(self, mock_get_session, mock_db_session, sample_user, sample_admin):
        """Test admin retrieving all users with pagination."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create additional users
        user_2 = User(
            user_id=str(uuid.uuid4()),
            email="user2@example.com",
            password_hash="hashed_password",
            full_name="User Two",
            role="user",
            is_active=True,
            failed_login_attempts=0,
            account_locked_until=None,
            created_at=datetime.utcnow(),
            last_login=None
        )
        
        # Mock query chain
        mock_query = MagicMock()
        mock_query.count.return_value = 3
        mock_query.order_by.return_value.offset.return_value.limit.return_value.all.return_value = [
            sample_admin, sample_user, user_2
        ]
        mock_db_session.query.return_value = mock_query
        
        # Get all users
        users, total = UserService.get_all_users(page=1, page_size=50)
        
        assert len(users) == 3
        assert total == 3
        assert users[0]["role"] == "admin"
        assert users[1]["email"] == "user@example.com"
        assert users[2]["email"] == "user2@example.com"
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_admin_search_users_by_email(self, mock_get_session, mock_db_session, sample_user):
        """Test admin searching for users by email."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Mock query chain with filter
        mock_query = MagicMock()
        mock_query.filter.return_value = mock_query
        mock_query.count.return_value = 1
        mock_query.order_by.return_value.offset.return_value.limit.return_value.all.return_value = [sample_user]
        mock_db_session.query.return_value = mock_query
        
        # Search for users
        users, total = UserService.get_all_users(search_email="user@example")
        
        assert len(users) == 1
        assert total == 1
        assert users[0]["email"] == "user@example.com"


class TestCompleteAdminWorkflow:
    """Test complete admin workflow with multiple operations."""
    
    @patch('services.user_service.DatabaseManager.get_session')
    @patch('services.session_service.DatabaseManager.get_session')
    def test_complete_admin_user_management_workflow(
        self, mock_session_get_session, mock_user_get_session, 
        mock_db_session, sample_user
    ):
        """Test complete workflow: view user, change role, view sessions, delete user."""
        # Setup mocks
        mock_user_get_session.return_value.__enter__.return_value = mock_db_session
        mock_session_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Step 1: Admin views user details
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        user_data = UserService.get_user_by_id(sample_user.user_id)
        
        assert user_data is not None
        assert user_data["email"] == "user@example.com"
        assert user_data["role"] == "user"
        
        # Step 2: Admin views user's sessions
        session_1 = ChatSession(
            session_id=str(uuid.uuid4()),
            user_id=sample_user.user_id,
            title="Session 1",
            is_active=True,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        mock_query = MagicMock()
        mock_query.outerjoin.return_value = mock_query
        mock_query.filter.return_value = mock_query
        mock_query.group_by.return_value = mock_query
        mock_query.order_by.return_value = mock_query
        mock_query.all.return_value = [(session_1, 5)]
        mock_db_session.query.return_value = mock_query
        
        sessions = SessionService.get_user_sessions(sample_user.user_id)
        
        assert len(sessions) == 1
        assert sessions[0]["message_count"] == 5
        
        # Step 3: Admin views session messages
        messages = [
            ChatMessage(
                message_id=str(uuid.uuid4()),
                session_id=session_1.session_id,
                role="user",
                content="Test message",
                sources=None,
                created_at=datetime.utcnow()
            )
        ]
        
        mock_db_session.query.return_value.filter.return_value.order_by.return_value.all.return_value = messages
        
        session_messages = SessionService.get_session_messages(session_1.session_id)
        
        assert len(session_messages) == 1
        assert session_messages[0]["content"] == "Test message"
        
        # Step 4: Admin changes user role
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        role_change_result = UserService.update_user_role(sample_user.user_id, "admin")
        
        assert role_change_result is True
        assert sample_user.role == "admin"
        
        # Step 5: Admin deactivates user
        deactivate_result = UserService.deactivate_user(sample_user.user_id)
        
        assert deactivate_result is True
        assert sample_user.is_active is False
        
        # Step 6: Admin deletes user
        delete_result = UserService.delete_user(sample_user.user_id)
        
        assert delete_result is True
        mock_db_session.delete.assert_called_with(sample_user)
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_admin_get_user_statistics(self, mock_get_session, mock_db_session):
        """Test admin retrieving user statistics."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create sophisticated mock for different query types
        query_call_count = [0]
        
        def query_side_effect(*args):
            query_call_count[0] += 1
            call_num = query_call_count[0]
            
            mock = MagicMock()
            mock.filter.return_value = mock
            mock.join.return_value = mock
            mock.group_by.return_value = mock
            mock.order_by.return_value = mock
            mock.limit.return_value = mock
            
            # Return different values for different queries
            if call_num <= 7:  # Scalar queries
                mock.scalar.return_value = 100 if call_num == 1 else 50
            else:  # Most active users query
                mock.all.return_value = [
                    ("user1@example.com", "User One", 150),
                    ("user2@example.com", "User Two", 100)
                ]
            
            return mock
        
        mock_db_session.query.side_effect = query_side_effect
        
        # Get statistics
        stats = UserService.get_user_statistics()
        
        assert stats is not None
        assert "total_users" in stats
        assert "active_users" in stats
        assert "admin_users" in stats
        assert "most_active_users" in stats
        assert len(stats["most_active_users"]) == 2
