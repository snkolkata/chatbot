"""
Integration tests for document deletion and cleanup.

Tests Requirements: 5.3
"""

import pytest
import os
from io import BytesIO

from utils.helpers import ValidationError


class TestDocumentDeletion:
    """Test end-to-end document deletion flow."""
    
    def test_delete_document_success(self, document_service):
        """Test successful deletion of a document."""
        # Upload a document
        file = BytesIO(b"Test document for deletion.")
        file.name = "delete_test.txt"
        result = document_service.upload_document(file, "delete_test.txt")
        doc_id = result['doc_id']
        
        # Verify document exists
        documents = document_service.list_documents()
        assert len(documents) == 1
        
        # Delete the document
        delete_result = document_service.delete_document(doc_id)
        assert delete_result is True
        
        # Verify document is removed
        documents = document_service.list_documents()
        assert len(documents) == 0
    
    def test_delete_nonexistent_document(self, document_service):
        """Test deleting a document that doesn't exist."""
        with pytest.raises(ValidationError) as exc_info:
            document_service.delete_document("nonexistent_id")
        
        assert "not found" in str(exc_info.value).lower()
    
    def test_delete_removes_physical_file(self, document_service, test_settings):
        """Test that deletion removes the physical file."""
        # Upload a document
        file = BytesIO(b"Test document content.")
        file.name = "file_test.txt"
        result = document_service.upload_document(file, "file_test.txt")
        doc_id = result['doc_id']
        
        # Get file path
        documents = document_service.list_documents()
        file_path = documents[0]['file_path']
        
        # Verify file exists
        assert os.path.exists(file_path)
        
        # Delete document
        document_service.delete_document(doc_id)
        
        # Verify file is removed
        assert not os.path.exists(file_path)
    
    def test_delete_removes_from_vector_store(self, document_service, rag_service):
        """Test that deletion removes embeddings from vector store."""
        # Upload a document
        file = BytesIO(b"Document content for vector store test.")
        file.name = "vector_test.txt"
        result = document_service.upload_document(file, "vector_test.txt")
        doc_id = result['doc_id']
        
        # Query should find the document
        query_result = rag_service.query("vector store test")
        assert query_result['chunk_count'] > 0
        
        # Delete the document
        document_service.delete_document(doc_id)
        
        # Query should not find the document
        query_result = rag_service.query("vector store test")
        assert query_result['chunk_count'] == 0
    
    def test_delete_one_of_multiple_documents(self, document_service):
        """Test deleting one document when multiple exist."""
        # Upload multiple documents
        file1 = BytesIO(b"First document content.")
        file1.name = "doc1.txt"
        result1 = document_service.upload_document(file1, "doc1.txt")
        
        file2 = BytesIO(b"Second document content.")
        file2.name = "doc2.txt"
        result2 = document_service.upload_document(file2, "doc2.txt")
        
        # Verify both exist
        documents = document_service.list_documents()
        assert len(documents) == 2
        
        # Delete first document
        document_service.delete_document(result1['doc_id'])
        
        # Verify only second document remains
        documents = document_service.list_documents()
        assert len(documents) == 1
        assert documents[0]['filename'] == "doc2.txt"
    
    def test_delete_and_reupload_same_filename(self, document_service):
        """Test deleting a document and uploading a new one with the same filename."""
        # Upload a document
        file1 = BytesIO(b"Original content.")
        file1.name = "reupload_test.txt"
        result1 = document_service.upload_document(file1, "reupload_test.txt")
        
        # Delete the document
        document_service.delete_document(result1['doc_id'])
        
        # Upload a new document with the same filename
        file2 = BytesIO(b"New content.")
        file2.name = "reupload_test.txt"
        result2 = document_service.upload_document(file2, "reupload_test.txt")
        
        # Verify new document exists
        documents = document_service.list_documents()
        assert len(documents) == 1
        assert documents[0]['filename'] == "reupload_test.txt"
        assert documents[0]['doc_id'] != result1['doc_id']
