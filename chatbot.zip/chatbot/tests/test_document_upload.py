"""
Integration tests for document upload flow.

Tests Requirements: 3.2, 3.3
"""

import pytest
from io import BytesIO
from unittest.mock import patch

from utils.helpers import ValidationError, DocumentProcessingError


class TestDocumentUpload:
    """Test end-to-end document upload flow."""
    
    def test_upload_txt_document_success(self, document_service, sample_txt_file):
        """Test successful upload of a TXT document."""
        # Upload document
        result = document_service.upload_document(
            file=sample_txt_file,
            filename="test_document.txt"
        )
        
        # Verify upload result
        assert result['success'] is True
        assert 'doc_id' in result
        assert result['filename'] == "test_document.txt"
        assert result['chunk_count'] > 0
        
        # Verify document is in metadata
        documents = document_service.list_documents()
        assert len(documents) == 1
        assert documents[0]['filename'] == "test_document.txt"
    
    def test_upload_invalid_file_format(self, document_service):
        """Test upload with invalid file format."""
        invalid_file = BytesIO(b"test content")
        invalid_file.name = "test.xyz"
        
        with pytest.raises(ValidationError) as exc_info:
            document_service.upload_document(
                file=invalid_file,
                filename="test.xyz"
            )
        
        assert "Unsupported file format" in str(exc_info.value)
    
    def test_upload_file_too_large(self, document_service, test_settings):
        """Test upload with file exceeding size limit."""
        # Create a file larger than the limit
        large_content = b"x" * (test_settings.MAX_FILE_SIZE_MB * 1024 * 1024 + 1)
        large_file = BytesIO(large_content)
        large_file.name = "large_file.txt"
        
        with pytest.raises(ValidationError) as exc_info:
            document_service.upload_document(
                file=large_file,
                filename="large_file.txt"
            )
        
        assert "exceeds maximum limit" in str(exc_info.value)
    
    def test_upload_multiple_documents(self, document_service):
        """Test uploading multiple documents."""
        # Upload first document
        file1 = BytesIO(b"First document content for testing.")
        file1.name = "doc1.txt"
        result1 = document_service.upload_document(file1, "doc1.txt")
        
        # Upload second document
        file2 = BytesIO(b"Second document content for testing.")
        file2.name = "doc2.txt"
        result2 = document_service.upload_document(file2, "doc2.txt")
        
        # Verify both documents are stored
        documents = document_service.list_documents()
        assert len(documents) == 2
        
        filenames = [doc['filename'] for doc in documents]
        assert "doc1.txt" in filenames
        assert "doc2.txt" in filenames
    
    def test_document_chunking(self, document_service):
        """Test that documents are properly chunked."""
        # Create a longer document that will be split into chunks
        long_content = b"This is a test. " * 200  # Create content that exceeds chunk size
        file = BytesIO(long_content)
        file.name = "long_doc.txt"
        
        result = document_service.upload_document(file, "long_doc.txt")
        
        # Verify chunks were created
        assert result['chunk_count'] > 1
        
        # Verify chunks are in vector store
        documents = document_service.list_documents()
        assert documents[0]['chunk_count'] == result['chunk_count']
