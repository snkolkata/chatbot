"""
Unit tests for SessionService.
Tests session CRUD operations, message storage, and context retrieval.
"""
import pytest
from datetime import datetime
from unittest.mock import MagicMock, patch
import uuid

from services.session_service import SessionService
from services.models import User, ChatSession, ChatMessage


@pytest.fixture
def mock_db_session():
    """Create a mock database session."""
    session = MagicMock()
    session.commit = MagicMock()
    session.rollback = MagicMock()
    session.close = MagicMock()
    session.add = MagicMock()
    session.delete = MagicMock()
    return session


@pytest.fixture
def sample_user():
    """Create a sample user for testing."""
    user = User(
        user_id=str(uuid.uuid4()),
        email="test@example.com",
        password_hash="hashed_password",
        full_name="Test User",
        role="user",
        is_active=True,
        failed_login_attempts=0,
        account_locked_until=None,
        created_at=datetime.utcnow(),
        last_login=None
    )
    return user


@pytest.fixture
def sample_session(sample_user):
    """Create a sample chat session for testing."""
    session = ChatSession(
        session_id=str(uuid.uuid4()),
        user_id=sample_user.user_id,
        title="Test Chat",
        is_active=True,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow()
    )
    return session


@pytest.fixture
def sample_message(sample_session):
    """Create a sample chat message for testing."""
    message = ChatMessage(
        message_id=str(uuid.uuid4()),
        session_id=sample_session.session_id,
        role="user",
        content="Test message content",
        sources=None,
        created_at=datetime.utcnow()
    )
    return message


class TestCreateSession:
    """Test create_session functionality."""
    
    @patch('services.session_service.DatabaseManager.get_session')
    @patch('services.session_service.ChatSession')
    def test_create_session_success(self, mock_chat_session_class, mock_get_session, mock_db_session, sample_user):
        """Test successful session creation."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Mock the ChatSession instance
        mock_session_instance = MagicMock()
        mock_session_instance.session_id = str(uuid.uuid4())
        mock_chat_session_class.return_value = mock_session_instance
        
        # Create session
        session_id = SessionService.create_session(sample_user.user_id, "New Chat")
        
        assert session_id is not None
        mock_db_session.add.assert_called_once()
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_create_session_user_not_found(self, mock_get_session, mock_db_session):
        """Test session creation with non-existent user."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Create session
        session_id = SessionService.create_session("non-existent-id")
        
        assert session_id is None
    
    @patch('services.session_service.DatabaseManager.get_session')
    @patch('services.session_service.ChatSession')
    def test_create_session_default_title(self, mock_chat_session_class, mock_get_session, mock_db_session, sample_user):
        """Test session creation with default title."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Mock the ChatSession instance
        mock_session_instance = MagicMock()
        mock_session_instance.session_id = str(uuid.uuid4())
        mock_chat_session_class.return_value = mock_session_instance
        
        # Create session without title
        session_id = SessionService.create_session(sample_user.user_id)
        
        assert session_id is not None


class TestGetUserSessions:
    """Test get_user_sessions functionality."""
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_get_user_sessions_success(self, mock_get_session, mock_db_session, sample_user, sample_session):
        """Test successful retrieval of user sessions."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Mock query chain
        mock_query = MagicMock()
        mock_query.outerjoin.return_value = mock_query
        mock_query.filter.return_value = mock_query
        mock_query.group_by.return_value = mock_query
        mock_query.order_by.return_value = mock_query
        mock_query.all.return_value = [(sample_session, 5)]
        mock_db_session.query.return_value = mock_query
        
        # Get sessions
        sessions = SessionService.get_user_sessions(sample_user.user_id)
        
        assert len(sessions) == 1
        assert sessions[0]["session_id"] == sample_session.session_id
        assert sessions[0]["title"] == sample_session.title
        assert sessions[0]["message_count"] == 5
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_get_user_sessions_empty(self, mock_get_session, mock_db_session, sample_user):
        """Test retrieval when user has no sessions."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Mock query chain to return empty list
        mock_query = MagicMock()
        mock_query.outerjoin.return_value = mock_query
        mock_query.filter.return_value = mock_query
        mock_query.group_by.return_value = mock_query
        mock_query.order_by.return_value = mock_query
        mock_query.all.return_value = []
        mock_db_session.query.return_value = mock_query
        
        # Get sessions
        sessions = SessionService.get_user_sessions(sample_user.user_id)
        
        assert len(sessions) == 0


class TestGetActiveSession:
    """Test get_active_session functionality."""
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_get_active_session_success(self, mock_get_session, mock_db_session, sample_session):
        """Test successful retrieval of active session."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.order_by.return_value.first.return_value = sample_session
        
        # Mock message count query
        mock_db_session.query.return_value.filter.return_value.scalar.return_value = 3
        
        # Get active session
        session = SessionService.get_active_session(sample_session.user_id)
        
        assert session is not None
        assert session["session_id"] == sample_session.session_id
        assert session["message_count"] == 3
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_get_active_session_none(self, mock_get_session, mock_db_session, sample_user):
        """Test retrieval when no sessions exist."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.order_by.return_value.first.return_value = None
        
        # Get active session
        session = SessionService.get_active_session(sample_user.user_id)
        
        assert session is None


class TestSetActiveSession:
    """Test set_active_session functionality."""
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_set_active_session_success(self, mock_get_session, mock_db_session, sample_session):
        """Test successful setting of active session."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_session
        
        # Set active session
        result = SessionService.set_active_session(sample_session.user_id, sample_session.session_id)
        
        assert result is True
        assert sample_session.updated_at is not None
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_set_active_session_not_found(self, mock_get_session, mock_db_session):
        """Test setting active session with non-existent session."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Set active session
        result = SessionService.set_active_session("user-id", "session-id")
        
        assert result is False


class TestUpdateSessionTitle:
    """Test update_session_title functionality."""
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_update_session_title_success(self, mock_get_session, mock_db_session, sample_session):
        """Test successful session title update."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_session
        
        # Update title
        result = SessionService.update_session_title(sample_session.session_id, "Updated Title")
        
        assert result is True
        assert sample_session.title == "Updated Title"
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_update_session_title_not_found(self, mock_get_session, mock_db_session):
        """Test title update with non-existent session."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Update title
        result = SessionService.update_session_title("non-existent-id", "New Title")
        
        assert result is False


class TestDeleteSession:
    """Test delete_session functionality with cascade."""
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_delete_session_success(self, mock_get_session, mock_db_session, sample_session):
        """Test successful session deletion."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_session
        mock_db_session.query.return_value.filter.return_value.scalar.return_value = 10
        
        # Delete session
        result = SessionService.delete_session(sample_session.session_id)
        
        assert result is True
        mock_db_session.delete.assert_called_once_with(sample_session)
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_delete_session_not_found(self, mock_get_session, mock_db_session):
        """Test deletion with non-existent session."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Delete session
        result = SessionService.delete_session("non-existent-id")
        
        assert result is False


class TestAddMessage:
    """Test add_message functionality."""
    
    @patch('services.session_service.DatabaseManager.get_session')
    @patch('services.session_service.ChatMessage')
    def test_add_message_success(self, mock_chat_message_class, mock_get_session, mock_db_session, sample_session):
        """Test successful message addition."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_session
        
        # Mock the ChatMessage instance
        mock_message_instance = MagicMock()
        mock_message_instance.message_id = str(uuid.uuid4())
        mock_chat_message_class.return_value = mock_message_instance
        
        # Add message
        message_id = SessionService.add_message(
            sample_session.session_id,
            "user",
            "Test message"
        )
        
        assert message_id is not None
        mock_db_session.add.assert_called_once()
    
    @patch('services.session_service.DatabaseManager.get_session')
    @patch('services.session_service.ChatMessage')
    def test_add_message_with_sources(self, mock_chat_message_class, mock_get_session, mock_db_session, sample_session):
        """Test message addition with sources."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_session
        
        # Mock the ChatMessage instance
        mock_message_instance = MagicMock()
        mock_message_instance.message_id = str(uuid.uuid4())
        mock_chat_message_class.return_value = mock_message_instance
        
        # Add message with sources
        sources = [{"document": "doc1.txt", "page": 1}]
        message_id = SessionService.add_message(
            sample_session.session_id,
            "assistant",
            "Response with sources",
            sources
        )
        
        assert message_id is not None
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_add_message_invalid_role(self, mock_get_session, mock_db_session, sample_session):
        """Test message addition with invalid role."""
        # Attempt to add message with invalid role
        with pytest.raises(ValueError, match="Invalid role"):
            SessionService.add_message(
                sample_session.session_id,
                "invalid_role",
                "Test message"
            )
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_add_message_session_not_found(self, mock_get_session, mock_db_session):
        """Test message addition with non-existent session."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Add message
        message_id = SessionService.add_message("non-existent-id", "user", "Test")
        
        assert message_id is None


class TestGetSessionMessages:
    """Test get_session_messages functionality."""
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_get_session_messages_success(self, mock_get_session, mock_db_session, sample_message):
        """Test successful retrieval of session messages."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.order_by.return_value.all.return_value = [
            sample_message
        ]
        
        # Get messages
        messages = SessionService.get_session_messages(sample_message.session_id)
        
        assert len(messages) == 1
        assert messages[0]["message_id"] == sample_message.message_id
        assert messages[0]["role"] == sample_message.role
        assert messages[0]["content"] == sample_message.content
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_get_session_messages_empty(self, mock_get_session, mock_db_session):
        """Test retrieval when session has no messages."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.order_by.return_value.all.return_value = []
        
        # Get messages
        messages = SessionService.get_session_messages("session-id")
        
        assert len(messages) == 0


class TestGetSessionContext:
    """Test get_session_context functionality for RAG."""
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_get_session_context_success(self, mock_get_session, mock_db_session):
        """Test successful retrieval of session context."""
        # Create multiple messages
        messages = [
            ChatMessage(
                message_id=str(uuid.uuid4()),
                session_id="session-id",
                role="user",
                content=f"Message {i}",
                sources=None,
                created_at=datetime.utcnow()
            )
            for i in range(5)
        ]
        
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.order_by.return_value.limit.return_value.all.return_value = messages
        
        # Get context
        context = SessionService.get_session_context("session-id", max_messages=10)
        
        assert len(context) == 5
        assert all("role" in msg and "content" in msg for msg in context)
        assert "message_id" not in context[0]  # Simplified format
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_get_session_context_limited(self, mock_get_session, mock_db_session):
        """Test context retrieval with message limit."""
        # Create multiple messages
        messages = [
            ChatMessage(
                message_id=str(uuid.uuid4()),
                session_id="session-id",
                role="user",
                content=f"Message {i}",
                sources=None,
                created_at=datetime.utcnow()
            )
            for i in range(3)
        ]
        
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.order_by.return_value.limit.return_value.all.return_value = messages
        
        # Get context with limit
        context = SessionService.get_session_context("session-id", max_messages=3)
        
        assert len(context) == 3
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_get_session_context_empty(self, mock_get_session, mock_db_session):
        """Test context retrieval when session has no messages."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.order_by.return_value.limit.return_value.all.return_value = []
        
        # Get context
        context = SessionService.get_session_context("session-id")
        
        assert len(context) == 0
