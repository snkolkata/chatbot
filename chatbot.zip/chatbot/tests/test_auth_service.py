"""
Unit tests for AuthService.
Tests password hashing, registration, login, and password reset functionality.
"""
import pytest
from datetime import datetime, timedelta
from unittest.mock import Mock, patch, MagicMock
import uuid

from services.auth_service import (
    AuthService,
    AuthenticationError,
    AccountLockedError,
    InvalidTokenError
)
from services.models import User, PasswordResetToken
from services.database_manager import DatabaseManager
from config.settings import settings


@pytest.fixture
def mock_db_session():
    """Create a mock database session."""
    session = MagicMock()
    session.commit = MagicMock()
    session.rollback = MagicMock()
    session.close = MagicMock()
    session.flush = MagicMock()
    session.add = MagicMock()
    return session


@pytest.fixture
def sample_user():
    """Create a sample user for testing."""
    user = User(
        user_id=str(uuid.uuid4()),
        email="test@example.com",
        password_hash=AuthService.hash_password("TestPass123"),
        full_name="Test User",
        role="user",
        is_active=True,
        failed_login_attempts=0,
        account_locked_until=None,
        created_at=datetime.utcnow(),
        last_login=None
    )
    return user


class TestPasswordHashing:
    """Test password hashing and verification."""
    
    def test_hash_password(self):
        """Test password hashing produces valid hash."""
        password = "TestPassword123"
        hashed = AuthService.hash_password(password)
        
        assert hashed is not None
        assert isinstance(hashed, str)
        assert len(hashed) > 0
        assert hashed != password
    
    def test_verify_password_correct(self):
        """Test password verification with correct password."""
        password = "TestPassword123"
        hashed = AuthService.hash_password(password)
        
        assert AuthService.verify_password(password, hashed) is True
    
    def test_verify_password_incorrect(self):
        """Test password verification with incorrect password."""
        password = "TestPassword123"
        wrong_password = "WrongPassword456"
        hashed = AuthService.hash_password(password)
        
        assert AuthService.verify_password(wrong_password, hashed) is False
    
    def test_hash_password_different_hashes(self):
        """Test that same password produces different hashes (due to salt)."""
        password = "TestPassword123"
        hash1 = AuthService.hash_password(password)
        hash2 = AuthService.hash_password(password)
        
        assert hash1 != hash2
        assert AuthService.verify_password(password, hash1) is True
        assert AuthService.verify_password(password, hash2) is True


class TestPasswordValidation:
    """Test password strength validation."""
    
    def test_validate_password_valid(self):
        """Test validation with valid password."""
        valid, error = AuthService.validate_password_strength("TestPass123")
        assert valid is True
        assert error == ""
    
    def test_validate_password_too_short(self):
        """Test validation with password too short."""
        valid, error = AuthService.validate_password_strength("Test1")
        assert valid is False
        assert "at least" in error.lower()
    
    def test_validate_password_no_uppercase(self):
        """Test validation with no uppercase letter."""
        valid, error = AuthService.validate_password_strength("testpass123")
        assert valid is False
        assert "uppercase" in error.lower()
    
    def test_validate_password_no_lowercase(self):
        """Test validation with no lowercase letter."""
        valid, error = AuthService.validate_password_strength("TESTPASS123")
        assert valid is False
        assert "lowercase" in error.lower()
    
    def test_validate_password_no_number(self):
        """Test validation with no number."""
        valid, error = AuthService.validate_password_strength("TestPassword")
        assert valid is False
        assert "number" in error.lower()


class TestEmailValidation:
    """Test email validation."""
    
    def test_validate_email_valid(self):
        """Test validation with valid email."""
        valid, error = AuthService.validate_email("test@example.com")
        assert valid is True
        assert error == ""
    
    def test_validate_email_invalid_format(self):
        """Test validation with invalid email format."""
        valid, error = AuthService.validate_email("invalid-email")
        assert valid is False
        assert "invalid" in error.lower()
    
    def test_validate_email_empty(self):
        """Test validation with empty email."""
        valid, error = AuthService.validate_email("")
        assert valid is False
        assert "required" in error.lower()
    
    def test_validate_email_none(self):
        """Test validation with None email."""
        valid, error = AuthService.validate_email(None)
        assert valid is False


class TestUserRegistration:
    """Test user registration functionality."""
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_register_user_success(self, mock_get_session, mock_db_session, sample_user):
        """Test successful user registration."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Mock the new user creation
        def add_side_effect(user):
            user.user_id = str(uuid.uuid4())
        mock_db_session.add.side_effect = add_side_effect
        
        # Register user
        result = AuthService.register_user(
            email="newuser@example.com",
            password="TestPass123",
            full_name="New User"
        )
        
        assert result is not None
        assert "user_id" in result
        assert result["email"] == "newuser@example.com"
        assert result["role"] == "user"
        assert "message" in result
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_register_user_duplicate_email(self, mock_get_session, mock_db_session, sample_user):
        """Test registration with duplicate email."""
        # Setup mock to return existing user
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Attempt to register with duplicate email
        with pytest.raises(ValueError, match="already registered"):
            AuthService.register_user(
                email="test@example.com",
                password="TestPass123",
                full_name="Test User"
            )
    
    def test_register_user_invalid_email(self):
        """Test registration with invalid email."""
        with pytest.raises(ValueError, match="Invalid email"):
            AuthService.register_user(
                email="invalid-email",
                password="TestPass123",
                full_name="Test User"
            )
    
    def test_register_user_weak_password(self):
        """Test registration with weak password."""
        with pytest.raises(ValueError, match="Password"):
            AuthService.register_user(
                email="test@example.com",
                password="weak",
                full_name="Test User"
            )
    
    def test_register_user_empty_name(self):
        """Test registration with empty name."""
        with pytest.raises(ValueError, match="Full name"):
            AuthService.register_user(
                email="test@example.com",
                password="TestPass123",
                full_name=""
            )


class TestAuthentication:
    """Test user authentication and login."""
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_authenticate_user_success(self, mock_get_session, mock_db_session, sample_user):
        """Test successful user authentication."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Authenticate user
        result = AuthService.authenticate_user("test@example.com", "TestPass123")
        
        assert result is not None
        assert result["user_id"] == sample_user.user_id
        assert result["email"] == sample_user.email
        assert result["role"] == sample_user.role
        assert sample_user.failed_login_attempts == 0
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_authenticate_user_wrong_password(self, mock_get_session, mock_db_session, sample_user):
        """Test authentication with wrong password."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Attempt authentication with wrong password
        with pytest.raises(AuthenticationError, match="Invalid email or password"):
            AuthService.authenticate_user("test@example.com", "WrongPassword123")
        
        # Verify failed attempt was recorded
        assert sample_user.failed_login_attempts == 1
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_authenticate_user_nonexistent(self, mock_get_session, mock_db_session):
        """Test authentication with non-existent user."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Attempt authentication
        with pytest.raises(AuthenticationError, match="Invalid email or password"):
            AuthService.authenticate_user("nonexistent@example.com", "TestPass123")
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_authenticate_user_inactive(self, mock_get_session, mock_db_session, sample_user):
        """Test authentication with inactive user."""
        # Setup mock with inactive user
        sample_user.is_active = False
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Attempt authentication
        with pytest.raises(ValueError, match="inactive"):
            AuthService.authenticate_user("test@example.com", "TestPass123")


class TestAccountLockout:
    """Test account lockout functionality."""
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_account_lockout_after_max_attempts(self, mock_get_session, mock_db_session, sample_user):
        """Test account locks after max failed attempts."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Simulate max failed attempts
        for i in range(settings.MAX_LOGIN_ATTEMPTS):
            try:
                AuthService.authenticate_user("test@example.com", "WrongPassword123")
            except AuthenticationError:
                pass
        
        # Verify account is locked
        assert sample_user.account_locked_until is not None
        assert sample_user.account_locked_until > datetime.utcnow()
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_is_account_locked_true(self, mock_get_session, mock_db_session, sample_user):
        """Test is_account_locked returns True for locked account."""
        # Lock the account
        sample_user.account_locked_until = datetime.utcnow() + timedelta(minutes=15)
        
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Check if locked
        assert AuthService.is_account_locked("test@example.com") is True
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_is_account_locked_expired(self, mock_get_session, mock_db_session, sample_user):
        """Test is_account_locked returns False for expired lock."""
        # Set expired lock
        sample_user.account_locked_until = datetime.utcnow() - timedelta(minutes=1)
        
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Check if locked
        assert AuthService.is_account_locked("test@example.com") is False
        assert sample_user.account_locked_until is None


class TestPasswordReset:
    """Test password reset functionality."""
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_create_password_reset_token_success(self, mock_get_session, mock_db_session, sample_user):
        """Test successful password reset token creation."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Create token
        token = AuthService.create_password_reset_token("test@example.com")
        
        assert token is not None
        assert isinstance(token, str)
        assert len(token) > 0
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_create_password_reset_token_nonexistent_user(self, mock_get_session, mock_db_session):
        """Test token creation for non-existent user returns None."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Create token
        token = AuthService.create_password_reset_token("nonexistent@example.com")
        
        assert token is None
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_verify_reset_token_valid(self, mock_get_session, mock_db_session, sample_user):
        """Test verification of valid reset token."""
        # Create mock token
        reset_token = PasswordResetToken(
            token_id=str(uuid.uuid4()),
            user_id=sample_user.user_id,
            token="valid-token-123",
            expires_at=datetime.utcnow() + timedelta(hours=1),
            used=False
        )
        
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = reset_token
        
        # Verify token
        user_id = AuthService.verify_reset_token("valid-token-123")
        
        assert user_id == sample_user.user_id
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_verify_reset_token_expired(self, mock_get_session, mock_db_session, sample_user):
        """Test verification of expired reset token."""
        # Create expired token
        reset_token = PasswordResetToken(
            token_id=str(uuid.uuid4()),
            user_id=sample_user.user_id,
            token="expired-token-123",
            expires_at=datetime.utcnow() - timedelta(hours=1),
            used=False
        )
        
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = reset_token
        
        # Verify token
        with pytest.raises(InvalidTokenError, match="expired"):
            AuthService.verify_reset_token("expired-token-123")
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_verify_reset_token_used(self, mock_get_session, mock_db_session, sample_user):
        """Test verification of already used reset token."""
        # Create used token
        reset_token = PasswordResetToken(
            token_id=str(uuid.uuid4()),
            user_id=sample_user.user_id,
            token="used-token-123",
            expires_at=datetime.utcnow() + timedelta(hours=1),
            used=True
        )
        
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = reset_token
        
        # Verify token
        with pytest.raises(InvalidTokenError, match="already been used"):
            AuthService.verify_reset_token("used-token-123")
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_reset_password_success(self, mock_get_session, mock_db_session, sample_user):
        """Test successful password reset."""
        # Create valid token
        reset_token = PasswordResetToken(
            token_id=str(uuid.uuid4()),
            user_id=sample_user.user_id,
            token="valid-token-123",
            expires_at=datetime.utcnow() + timedelta(hours=1),
            used=False
        )
        
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Mock query chain for token verification
        mock_query = mock_db_session.query.return_value
        mock_query.filter.return_value.first.return_value = reset_token
        
        # Mock user query
        def query_side_effect(model):
            if model == User:
                mock_user_query = MagicMock()
                mock_user_query.filter.return_value.first.return_value = sample_user
                return mock_user_query
            return mock_query
        
        mock_db_session.query.side_effect = query_side_effect
        
        # Reset password
        result = AuthService.reset_password("valid-token-123", "NewPassword123")
        
        assert result is True
        assert reset_token.used is True
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_reset_password_weak_password(self, mock_get_session, mock_db_session):
        """Test password reset with weak password."""
        # Attempt reset with weak password
        with pytest.raises(ValueError, match="Password"):
            AuthService.reset_password("valid-token-123", "weak")
