"""
Test script to verify Google API key is properly configured and working.
"""
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

print("=" * 60)
print("API Key Configuration Test")
print("=" * 60)

# Test 1: Check environment variables
print("\n1. Environment Variables:")
gemini_key = os.getenv("GEMINI_API_KEY")
google_key = os.getenv("GOOGLE_API_KEY")

print(f"   GEMINI_API_KEY: {'✓ Set' if gemini_key else '✗ Not Set'}")
if gemini_key:
    print(f"   First 20 chars: {gemini_key[:20]}...")

print(f"   GOOGLE_API_KEY: {'✓ Set' if google_key else '✗ Not Set'}")
if google_key:
    print(f"   First 20 chars: {google_key[:20]}...")

# Test 2: Check settings module
print("\n2. Settings Module:")
try:
    from config.settings import settings
    print(f"   settings.GEMINI_API_KEY: {'✓ Loaded' if settings.GEMINI_API_KEY else '✗ Not Loaded'}")
    print(f"   settings.EMBEDDING_PROVIDER: {settings.EMBEDDING_PROVIDER}")
    print(f"   settings.EMBEDDING_MODEL: {settings.EMBEDDING_MODEL}")
except Exception as e:
    print(f"   ✗ Error loading settings: {e}")

# Test 3: Initialize embeddings
print("\n3. Google Generative AI Embeddings:")
try:
    from langchain_google_genai import GoogleGenerativeAIEmbeddings
    
    embeddings = GoogleGenerativeAIEmbeddings(
        model="models/text-embedding-004",
        google_api_key=settings.GEMINI_API_KEY
    )
    print("   ✓ Embeddings object created successfully")
    
    # Test 4: Generate a test embedding
    print("\n4. Test Embedding Generation:")
    test_text = "This is a test sentence."
    result = embeddings.embed_query(test_text)
    print(f"   ✓ Successfully generated embedding")
    print(f"   Embedding dimensions: {len(result)}")
    print(f"   First 5 values: {result[:5]}")
    
except Exception as e:
    print(f"   ✗ Error: {e}")
    import traceback
    traceback.print_exc()

# Test 5: Initialize VectorStoreManager
print("\n5. VectorStoreManager Initialization:")
try:
    from services.vector_store import VectorStoreManager
    
    vm = VectorStoreManager("./test_vector_store")
    print("   ✓ VectorStoreManager created successfully")
    print(f"   GOOGLE_API_KEY env var now set: {'✓ Yes' if os.getenv('GOOGLE_API_KEY') else '✗ No'}")
    
except Exception as e:
    print(f"   ✗ Error: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "=" * 60)
print("Test Complete!")
print("=" * 60)
