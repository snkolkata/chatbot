"""
Unit tests for UserService.
Tests user CRUD operations, role management, and user administration.
"""
import pytest
from datetime import datetime, timedelta
from unittest.mock import MagicMock, patch
import uuid

from services.user_service import UserService
from services.models import User, ChatSession, ChatMessage


@pytest.fixture
def mock_db_session():
    """Create a mock database session."""
    session = MagicMock()
    session.commit = MagicMock()
    session.rollback = MagicMock()
    session.close = MagicMock()
    session.add = MagicMock()
    session.delete = MagicMock()
    return session


@pytest.fixture
def sample_user():
    """Create a sample user for testing."""
    user = User(
        user_id=str(uuid.uuid4()),
        email="test@example.com",
        password_hash="hashed_password",
        full_name="Test User",
        role="user",
        is_active=True,
        failed_login_attempts=0,
        account_locked_until=None,
        created_at=datetime.utcnow(),
        last_login=None
    )
    return user


@pytest.fixture
def sample_admin():
    """Create a sample admin user for testing."""
    admin = User(
        user_id=str(uuid.uuid4()),
        email="admin@example.com",
        password_hash="hashed_password",
        full_name="Admin User",
        role="admin",
        is_active=True,
        failed_login_attempts=0,
        account_locked_until=None,
        created_at=datetime.utcnow(),
        last_login=datetime.utcnow()
    )
    return admin


class TestGetUserById:
    """Test get_user_by_id functionality."""
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_get_user_by_id_success(self, mock_get_session, mock_db_session, sample_user):
        """Test successful user retrieval by ID."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Get user
        result = UserService.get_user_by_id(sample_user.user_id)
        
        assert result is not None
        assert result["user_id"] == sample_user.user_id
        assert result["email"] == sample_user.email
        assert result["full_name"] == sample_user.full_name
        assert result["role"] == sample_user.role
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_get_user_by_id_not_found(self, mock_get_session, mock_db_session):
        """Test user retrieval with non-existent ID."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Get user
        result = UserService.get_user_by_id("non-existent-id")
        
        assert result is None


class TestGetUserByEmail:
    """Test get_user_by_email functionality."""
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_get_user_by_email_success(self, mock_get_session, mock_db_session, sample_user):
        """Test successful user retrieval by email."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Get user
        result = UserService.get_user_by_email("test@example.com")
        
        assert result is not None
        assert result["email"] == sample_user.email
        assert result["user_id"] == sample_user.user_id
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_get_user_by_email_not_found(self, mock_get_session, mock_db_session):
        """Test user retrieval with non-existent email."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Get user
        result = UserService.get_user_by_email("nonexistent@example.com")
        
        assert result is None


class TestGetAllUsers:
    """Test get_all_users functionality with pagination."""
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_get_all_users_basic(self, mock_get_session, mock_db_session, sample_user, sample_admin):
        """Test basic user retrieval with pagination."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Mock query chain
        mock_query = MagicMock()
        mock_query.count.return_value = 2
        mock_query.order_by.return_value.offset.return_value.limit.return_value.all.return_value = [
            sample_user, sample_admin
        ]
        mock_db_session.query.return_value = mock_query
        
        # Get users
        users, total = UserService.get_all_users(page=1, page_size=50)
        
        assert len(users) == 2
        assert total == 2
        assert users[0]["email"] == sample_user.email
        assert users[1]["email"] == sample_admin.email
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_get_all_users_with_email_search(self, mock_get_session, mock_db_session, sample_user):
        """Test user retrieval with email search filter."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Mock query chain
        mock_query = MagicMock()
        mock_query.filter.return_value = mock_query
        mock_query.count.return_value = 1
        mock_query.order_by.return_value.offset.return_value.limit.return_value.all.return_value = [sample_user]
        mock_db_session.query.return_value = mock_query
        
        # Get users with search
        users, total = UserService.get_all_users(search_email="test")
        
        assert len(users) == 1
        assert total == 1
        assert users[0]["email"] == sample_user.email
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_get_all_users_with_role_filter(self, mock_get_session, mock_db_session, sample_admin):
        """Test user retrieval with role filter."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Mock query chain
        mock_query = MagicMock()
        mock_query.filter.return_value = mock_query
        mock_query.count.return_value = 1
        mock_query.order_by.return_value.offset.return_value.limit.return_value.all.return_value = [sample_admin]
        mock_db_session.query.return_value = mock_query
        
        # Get users with role filter
        users, total = UserService.get_all_users(role_filter="admin")
        
        assert len(users) == 1
        assert total == 1
        assert users[0]["role"] == "admin"


class TestUpdateLastLogin:
    """Test update_last_login functionality."""
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_update_last_login_success(self, mock_get_session, mock_db_session, sample_user):
        """Test successful last login update."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Update last login
        result = UserService.update_last_login(sample_user.user_id)
        
        assert result is True
        assert sample_user.last_login is not None
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_update_last_login_user_not_found(self, mock_get_session, mock_db_session):
        """Test last login update with non-existent user."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Update last login
        result = UserService.update_last_login("non-existent-id")
        
        assert result is False


class TestUpdateUserRole:
    """Test update_user_role functionality."""
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_update_user_role_success(self, mock_get_session, mock_db_session, sample_user):
        """Test successful role update."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Update role
        result = UserService.update_user_role(sample_user.user_id, "admin")
        
        assert result is True
        assert sample_user.role == "admin"
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_update_user_role_invalid_role(self, mock_get_session, mock_db_session, sample_user):
        """Test role update with invalid role."""
        # Attempt to update with invalid role
        with pytest.raises(ValueError, match="Invalid role"):
            UserService.update_user_role(sample_user.user_id, "superuser")
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_update_user_role_user_not_found(self, mock_get_session, mock_db_session):
        """Test role update with non-existent user."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Update role
        result = UserService.update_user_role("non-existent-id", "admin")
        
        assert result is False


class TestDeactivateUser:
    """Test deactivate_user functionality."""
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_deactivate_user_success(self, mock_get_session, mock_db_session, sample_user):
        """Test successful user deactivation."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Deactivate user
        result = UserService.deactivate_user(sample_user.user_id)
        
        assert result is True
        assert sample_user.is_active is False
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_deactivate_user_not_found(self, mock_get_session, mock_db_session):
        """Test deactivation with non-existent user."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Deactivate user
        result = UserService.deactivate_user("non-existent-id")
        
        assert result is False


class TestActivateUser:
    """Test activate_user functionality."""
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_activate_user_success(self, mock_get_session, mock_db_session, sample_user):
        """Test successful user activation."""
        # Setup inactive user
        sample_user.is_active = False
        
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Activate user
        result = UserService.activate_user(sample_user.user_id)
        
        assert result is True
        assert sample_user.is_active is True


class TestDeleteUser:
    """Test delete_user functionality with cascade."""
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_delete_user_success(self, mock_get_session, mock_db_session, sample_user):
        """Test successful user deletion."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Delete user
        result = UserService.delete_user(sample_user.user_id)
        
        assert result is True
        mock_db_session.delete.assert_called_once_with(sample_user)
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_delete_user_not_found(self, mock_get_session, mock_db_session):
        """Test deletion with non-existent user."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Delete user
        result = UserService.delete_user("non-existent-id")
        
        assert result is False


class TestGetUserStatistics:
    """Test get_user_statistics functionality."""
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_get_user_statistics_success(self, mock_get_session, mock_db_session):
        """Test successful statistics retrieval."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create a more sophisticated mock that handles different query types
        def create_query_mock(scalar_value=0, all_value=None):
            mock = MagicMock()
            mock.scalar.return_value = scalar_value
            mock.filter.return_value = mock
            mock.join.return_value = mock
            mock.group_by.return_value = mock
            mock.order_by.return_value = mock
            mock.limit.return_value = mock
            mock.all.return_value = all_value or []
            return mock
        
        # Track query call count to return different mocks
        query_call_count = [0]
        
        def query_side_effect(*args):
            query_call_count[0] += 1
            call_num = query_call_count[0]
            
            # Return different values for different queries
            if call_num <= 7:  # First 7 are scalar queries
                return create_query_mock(scalar_value=10)
            else:  # Last one is the most active users query
                return create_query_mock(
                    all_value=[
                        ("user1@example.com", "User One", 50),
                        ("user2@example.com", "User Two", 30)
                    ]
                )
        
        mock_db_session.query.side_effect = query_side_effect
        
        # Get statistics
        stats = UserService.get_user_statistics()
        
        assert stats is not None
        assert "total_users" in stats
        assert "active_users" in stats
        assert "admin_users" in stats
        assert "most_active_users" in stats
        assert len(stats["most_active_users"]) == 2
