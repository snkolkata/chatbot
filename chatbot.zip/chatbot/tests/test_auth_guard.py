"""
Tests for authentication middleware and guards.

This module tests the authentication decorators, helper functions,
and session management functionality.
"""

import pytest
from datetime import datetime, timedelta
from unittest.mock import Mock, patch, MagicMock
from utils.auth_guard import (
    is_authenticated,
    is_admin,
    get_current_user_id,
    get_current_user_email,
    get_current_user_role,
    check_session_timeout,
    update_last_activity,
    clear_session,
    set_user_session,
    require_auth,
    require_admin,
    require_active_account,
    get_session_info,
    AuthenticationError,
    AuthorizationError,
    SessionExpiredError
)


@pytest.fixture
def mock_streamlit_session():
    """Mock Streamlit session_state for testing."""
    with patch('utils.auth_guard.st') as mock_st:
        # Create a mock session_state that behaves like a dictionary
        mock_session = {}
        mock_st.session_state = mock_session
        yield mock_st


class TestAuthenticationHelpers:
    """Test authentication helper functions."""
    
    def test_is_authenticated_when_logged_in(self, mock_streamlit_session):
        """Test is_authenticated returns True when user is logged in."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        
        assert is_authenticated() is True
    
    def test_is_authenticated_when_not_logged_in(self, mock_streamlit_session):
        """Test is_authenticated returns False when user is not logged in."""
        assert is_authenticated() is False
    
    def test_is_authenticated_when_user_id_is_none(self, mock_streamlit_session):
        """Test is_authenticated returns False when user_id is None."""
        mock_streamlit_session.session_state['user_id'] = None
        
        assert is_authenticated() is False
    
    def test_is_admin_when_user_is_admin(self, mock_streamlit_session):
        """Test is_admin returns True for admin users."""
        mock_streamlit_session.session_state['user_id'] = 'admin-user-id'
        mock_streamlit_session.session_state['role'] = 'admin'
        
        assert is_admin() is True
    
    def test_is_admin_when_user_is_not_admin(self, mock_streamlit_session):
        """Test is_admin returns False for non-admin users."""
        mock_streamlit_session.session_state['user_id'] = 'regular-user-id'
        mock_streamlit_session.session_state['role'] = 'user'
        
        assert is_admin() is False
    
    def test_is_admin_when_not_authenticated(self, mock_streamlit_session):
        """Test is_admin returns False when user is not authenticated."""
        assert is_admin() is False
    
    def test_get_current_user_id(self, mock_streamlit_session):
        """Test get_current_user_id returns user ID when authenticated."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        
        assert get_current_user_id() == 'test-user-id'
    
    def test_get_current_user_id_when_not_authenticated(self, mock_streamlit_session):
        """Test get_current_user_id returns None when not authenticated."""
        assert get_current_user_id() is None
    
    def test_get_current_user_email(self, mock_streamlit_session):
        """Test get_current_user_email returns email when authenticated."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        mock_streamlit_session.session_state['email'] = 'test@example.com'
        
        assert get_current_user_email() == 'test@example.com'
    
    def test_get_current_user_role(self, mock_streamlit_session):
        """Test get_current_user_role returns role when authenticated."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        mock_streamlit_session.session_state['role'] = 'user'
        
        assert get_current_user_role() == 'user'


class TestSessionManagement:
    """Test session management functions."""
    
    def test_set_user_session(self, mock_streamlit_session):
        """Test set_user_session stores user data correctly."""
        user_data = {
            'user_id': 'test-user-id',
            'email': 'test@example.com',
            'full_name': 'Test User',
            'role': 'user',
            'is_active': True
        }
        
        set_user_session(user_data, remember_me=False)
        
        assert mock_streamlit_session.session_state['user_id'] == 'test-user-id'
        assert mock_streamlit_session.session_state['email'] == 'test@example.com'
        assert mock_streamlit_session.session_state['full_name'] == 'Test User'
        assert mock_streamlit_session.session_state['role'] == 'user'
        assert mock_streamlit_session.session_state['is_active'] is True
        assert mock_streamlit_session.session_state['remember_me'] is False
        assert mock_streamlit_session.session_state['authenticated'] is True
        assert 'last_activity' in mock_streamlit_session.session_state
    
    def test_set_user_session_with_remember_me(self, mock_streamlit_session):
        """Test set_user_session with remember_me enabled."""
        user_data = {
            'user_id': 'test-user-id',
            'email': 'test@example.com',
            'full_name': 'Test User',
            'role': 'user'
        }
        
        set_user_session(user_data, remember_me=True)
        
        assert mock_streamlit_session.session_state['remember_me'] is True
    
    def test_clear_session(self, mock_streamlit_session):
        """Test clear_session removes all authentication data."""
        # Set up session data
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        mock_streamlit_session.session_state['email'] = 'test@example.com'
        mock_streamlit_session.session_state['role'] = 'user'
        mock_streamlit_session.session_state['authenticated'] = True
        
        clear_session()
        
        assert 'user_id' not in mock_streamlit_session.session_state
        assert 'email' not in mock_streamlit_session.session_state
        assert 'role' not in mock_streamlit_session.session_state
        assert 'authenticated' not in mock_streamlit_session.session_state
    
    def test_update_last_activity(self, mock_streamlit_session):
        """Test update_last_activity updates timestamp."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        
        update_last_activity()
        
        assert 'last_activity' in mock_streamlit_session.session_state
        assert isinstance(mock_streamlit_session.session_state['last_activity'], datetime)
    
    def test_update_last_activity_when_not_authenticated(self, mock_streamlit_session):
        """Test update_last_activity does nothing when not authenticated."""
        update_last_activity()
        
        assert 'last_activity' not in mock_streamlit_session.session_state


class TestSessionTimeout:
    """Test session timeout functionality."""
    
    def test_check_session_timeout_valid_session(self, mock_streamlit_session):
        """Test check_session_timeout returns True for valid session."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        mock_streamlit_session.session_state['last_activity'] = datetime.now()
        mock_streamlit_session.session_state['remember_me'] = False
        
        assert check_session_timeout() is True
    
    def test_check_session_timeout_expired_session(self, mock_streamlit_session):
        """Test check_session_timeout returns False for expired session."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        # Set last activity to 25 hours ago (default timeout is 24 hours)
        mock_streamlit_session.session_state['last_activity'] = datetime.now() - timedelta(hours=25)
        mock_streamlit_session.session_state['remember_me'] = False
        
        assert check_session_timeout() is False
    
    def test_check_session_timeout_with_remember_me(self, mock_streamlit_session):
        """Test check_session_timeout with remember_me uses extended timeout."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        # Set last activity to 3 days ago (remember_me timeout is 7 days)
        mock_streamlit_session.session_state['last_activity'] = datetime.now() - timedelta(days=3)
        mock_streamlit_session.session_state['remember_me'] = True
        
        assert check_session_timeout() is True
    
    def test_check_session_timeout_remember_me_expired(self, mock_streamlit_session):
        """Test check_session_timeout with remember_me expired."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        # Set last activity to 8 days ago (remember_me timeout is 7 days)
        mock_streamlit_session.session_state['last_activity'] = datetime.now() - timedelta(days=8)
        mock_streamlit_session.session_state['remember_me'] = True
        
        assert check_session_timeout() is False
    
    def test_check_session_timeout_no_last_activity(self, mock_streamlit_session):
        """Test check_session_timeout returns False when no last_activity."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        
        assert check_session_timeout() is False
    
    def test_check_session_timeout_not_authenticated(self, mock_streamlit_session):
        """Test check_session_timeout returns False when not authenticated."""
        assert check_session_timeout() is False
    
    def test_check_session_timeout_with_string_timestamp(self, mock_streamlit_session):
        """Test check_session_timeout handles string timestamps."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        mock_streamlit_session.session_state['last_activity'] = datetime.now().isoformat()
        mock_streamlit_session.session_state['remember_me'] = False
        
        assert check_session_timeout() is True


class TestRequireAuthDecorator:
    """Test require_auth decorator."""
    
    def test_require_auth_allows_authenticated_user(self, mock_streamlit_session):
        """Test require_auth allows authenticated users."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        mock_streamlit_session.session_state['last_activity'] = datetime.now()
        
        @require_auth
        def protected_function():
            return "success"
        
        result = protected_function()
        assert result == "success"
    
    def test_require_auth_blocks_unauthenticated_user(self, mock_streamlit_session):
        """Test require_auth blocks unauthenticated users."""
        mock_streamlit_session.switch_page = Mock()
        mock_streamlit_session.error = Mock()
        mock_streamlit_session.info = Mock()
        
        @require_auth
        def protected_function():
            return "success"
        
        result = protected_function()
        
        assert result is None
        mock_streamlit_session.switch_page.assert_called_once_with("pages/Login.py")
    
    def test_require_auth_blocks_expired_session(self, mock_streamlit_session):
        """Test require_auth blocks users with expired sessions."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        mock_streamlit_session.session_state['last_activity'] = datetime.now() - timedelta(hours=25)
        mock_streamlit_session.switch_page = Mock()
        mock_streamlit_session.error = Mock()
        
        @require_auth
        def protected_function():
            return "success"
        
        result = protected_function()
        
        assert result is None
        mock_streamlit_session.switch_page.assert_called_once_with("pages/Login.py")


class TestRequireAdminDecorator:
    """Test require_admin decorator."""
    
    def test_require_admin_allows_admin_user(self, mock_streamlit_session):
        """Test require_admin allows admin users."""
        mock_streamlit_session.session_state['user_id'] = 'admin-user-id'
        mock_streamlit_session.session_state['role'] = 'admin'
        mock_streamlit_session.session_state['last_activity'] = datetime.now()
        
        @require_admin
        def admin_function():
            return "admin success"
        
        result = admin_function()
        assert result == "admin success"
    
    def test_require_admin_blocks_regular_user(self, mock_streamlit_session):
        """Test require_admin blocks non-admin users."""
        mock_streamlit_session.session_state['user_id'] = 'regular-user-id'
        mock_streamlit_session.session_state['role'] = 'user'
        mock_streamlit_session.session_state['last_activity'] = datetime.now()
        mock_streamlit_session.error = Mock()
        mock_streamlit_session.warning = Mock()
        mock_streamlit_session.button = Mock(return_value=False)
        mock_streamlit_session.stop = Mock()
        
        @require_admin
        def admin_function():
            return "admin success"
        
        result = admin_function()
        
        assert result is None
        mock_streamlit_session.error.assert_called_once()
        mock_streamlit_session.stop.assert_called_once()
    
    def test_require_admin_blocks_unauthenticated_user(self, mock_streamlit_session):
        """Test require_admin blocks unauthenticated users."""
        mock_streamlit_session.switch_page = Mock()
        mock_streamlit_session.error = Mock()
        mock_streamlit_session.info = Mock()
        
        @require_admin
        def admin_function():
            return "admin success"
        
        result = admin_function()
        
        assert result is None
        mock_streamlit_session.switch_page.assert_called_once_with("pages/Login.py")


class TestRequireActiveAccountDecorator:
    """Test require_active_account decorator."""
    
    def test_require_active_account_allows_active_user(self, mock_streamlit_session):
        """Test require_active_account allows active users."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        mock_streamlit_session.session_state['is_active'] = True
        
        @require_active_account
        def protected_function():
            return "success"
        
        result = protected_function()
        assert result == "success"
    
    def test_require_active_account_blocks_deactivated_user(self, mock_streamlit_session):
        """Test require_active_account blocks deactivated users."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        mock_streamlit_session.session_state['is_active'] = False
        mock_streamlit_session.error = Mock()
        mock_streamlit_session.warning = Mock()
        mock_streamlit_session.stop = Mock()
        
        @require_active_account
        def protected_function():
            return "success"
        
        result = protected_function()
        
        assert result is None
        mock_streamlit_session.error.assert_called_once()
        mock_streamlit_session.stop.assert_called_once()


class TestGetSessionInfo:
    """Test get_session_info function."""
    
    def test_get_session_info_authenticated(self, mock_streamlit_session):
        """Test get_session_info returns correct info for authenticated user."""
        mock_streamlit_session.session_state['user_id'] = 'test-user-id'
        mock_streamlit_session.session_state['email'] = 'test@example.com'
        mock_streamlit_session.session_state['role'] = 'admin'
        mock_streamlit_session.session_state['last_activity'] = datetime.now()
        mock_streamlit_session.session_state['remember_me'] = True
        
        info = get_session_info()
        
        assert info['authenticated'] is True
        assert info['user_id'] == 'test-user-id'
        assert info['email'] == 'test@example.com'
        assert info['role'] == 'admin'
        assert info['is_admin'] is True
        assert info['session_valid'] is True
        assert info['remember_me'] is True
    
    def test_get_session_info_not_authenticated(self, mock_streamlit_session):
        """Test get_session_info returns correct info for unauthenticated user."""
        info = get_session_info()
        
        assert info['authenticated'] is False
        assert info['user_id'] is None
        assert info['email'] is None
        assert info['role'] is None
        assert info['session_valid'] is False
