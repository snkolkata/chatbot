"""Test the current setup end-to-end"""
import os
import sys
sys.path.insert(0, '.')

from dotenv import load_dotenv
load_dotenv(override=True)

from config.settings import settings
from langchain_google_genai import GoogleGenerativeAIEmbeddings

print("="*60)
print("TESTING CURRENT SETUP")
print("="*60)

print(f"\n1. Configuration:")
print(f"   API Key: {settings.GEMINI_API_KEY[:20]}...")
print(f"   Embedding Provider: {settings.EMBEDDING_PROVIDER}")
print(f"   Embedding Model: {settings.EMBEDDING_MODEL}")

print(f"\n2. Testing embedding...")
try:
    embeddings = GoogleGenerativeAIEmbeddings(
        model=settings.EMBEDDING_MODEL,
        google_api_key=settings.GEMINI_API_KEY
    )
    result = embeddings.embed_query("test")
    print(f"   ✓ SUCCESS! Dimension: {len(result)}")
    print(f"   Embeddings are working!")
except Exception as e:
    print(f"   ✗ FAILED: {str(e)[:200]}")
    
print("\n" + "="*60)
