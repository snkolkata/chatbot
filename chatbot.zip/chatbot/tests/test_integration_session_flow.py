"""
Integration tests for chat session flow.
Tests session creation, message storage, session switching, and session deletion.
Requirements: 4.1, 5.1, 5.5
"""
import pytest
from datetime import datetime
from unittest.mock import patch, MagicMock
import uuid

from services.session_service import SessionService
from services.models import User, ChatSession, ChatMessage


@pytest.fixture
def mock_db_session():
    """Create a mock database session for integration tests."""
    session = MagicMock()
    session.commit = MagicMock()
    session.rollback = MagicMock()
    session.close = MagicMock()
    session.add = MagicMock()
    session.delete = MagicMock()
    session.flush = MagicMock()
    return session


@pytest.fixture
def sample_user():
    """Create a sample user for testing."""
    user = User(
        user_id=str(uuid.uuid4()),
        email="test@example.com",
        password_hash="hashed_password",
        full_name="Test User",
        role="user",
        is_active=True,
        failed_login_attempts=0,
        account_locked_until=None,
        created_at=datetime.utcnow(),
        last_login=None
    )
    return user


class TestSessionCreationAndMessageStorage:
    """Test session creation and message storage flow."""
    
    @patch('services.session_service.DatabaseManager.get_session')
    @patch('services.session_service.ChatSession')
    @patch('services.session_service.ChatMessage')
    def test_create_session_and_add_messages(
        self, mock_chat_message_class, mock_chat_session_class, 
        mock_get_session, mock_db_session, sample_user
    ):
        """Test creating a session and adding messages to it."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Step 1: Create session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Mock ChatSession instance
        session_id = str(uuid.uuid4())
        mock_session_instance = MagicMock()
        mock_session_instance.session_id = session_id
        mock_session_instance.user_id = sample_user.user_id
        mock_session_instance.title = "Test Chat"
        mock_session_instance.is_active = True
        mock_session_instance.created_at = datetime.utcnow()
        mock_session_instance.updated_at = datetime.utcnow()
        mock_chat_session_class.return_value = mock_session_instance
        
        created_session_id = SessionService.create_session(sample_user.user_id, "Test Chat")
        
        assert created_session_id is not None
        assert created_session_id == session_id
        
        # Step 2: Add user message
        # Mock finding the session
        mock_db_session.query.return_value.filter.return_value.first.return_value = mock_session_instance
        
        # Mock ChatMessage instance
        message_id_1 = str(uuid.uuid4())
        mock_message_instance_1 = MagicMock()
        mock_message_instance_1.message_id = message_id_1
        mock_chat_message_class.return_value = mock_message_instance_1
        
        user_message_id = SessionService.add_message(
            session_id,
            "user",
            "What is the capital of France?"
        )
        
        assert user_message_id is not None
        assert user_message_id == message_id_1
        
        # Step 3: Add assistant message with sources
        message_id_2 = str(uuid.uuid4())
        mock_message_instance_2 = MagicMock()
        mock_message_instance_2.message_id = message_id_2
        mock_chat_message_class.return_value = mock_message_instance_2
        
        sources = [{"document": "geography.pdf", "page": 5}]
        assistant_message_id = SessionService.add_message(
            session_id,
            "assistant",
            "The capital of France is Paris.",
            sources
        )
        
        assert assistant_message_id is not None
        assert assistant_message_id == message_id_2
        
        # Verify session updated_at was updated
        assert mock_session_instance.updated_at is not None
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_retrieve_session_messages_in_order(self, mock_get_session, mock_db_session):
        """Test retrieving messages from a session in chronological order."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create messages
        session_id = str(uuid.uuid4())
        messages = [
            ChatMessage(
                message_id=str(uuid.uuid4()),
                session_id=session_id,
                role="user",
                content="First message",
                sources=None,
                created_at=datetime.utcnow()
            ),
            ChatMessage(
                message_id=str(uuid.uuid4()),
                session_id=session_id,
                role="assistant",
                content="First response",
                sources=[{"document": "doc1.pdf"}],
                created_at=datetime.utcnow()
            ),
            ChatMessage(
                message_id=str(uuid.uuid4()),
                session_id=session_id,
                role="user",
                content="Second message",
                sources=None,
                created_at=datetime.utcnow()
            ),
            ChatMessage(
                message_id=str(uuid.uuid4()),
                session_id=session_id,
                role="assistant",
                content="Second response",
                sources=None,
                created_at=datetime.utcnow()
            )
        ]
        
        # Mock query to return messages
        mock_db_session.query.return_value.filter.return_value.order_by.return_value.all.return_value = messages
        
        # Retrieve messages
        retrieved_messages = SessionService.get_session_messages(session_id)
        
        assert len(retrieved_messages) == 4
        assert retrieved_messages[0]["role"] == "user"
        assert retrieved_messages[0]["content"] == "First message"
        assert retrieved_messages[1]["role"] == "assistant"
        assert retrieved_messages[1]["content"] == "First response"
        assert retrieved_messages[1]["sources"] is not None
        assert retrieved_messages[2]["role"] == "user"
        assert retrieved_messages[3]["role"] == "assistant"
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_get_session_context_for_rag(self, mock_get_session, mock_db_session):
        """Test retrieving session context for RAG service."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create conversation history
        session_id = str(uuid.uuid4())
        messages = [
            ChatMessage(
                message_id=str(uuid.uuid4()),
                session_id=session_id,
                role="user",
                content="What is machine learning?",
                sources=None,
                created_at=datetime.utcnow()
            ),
            ChatMessage(
                message_id=str(uuid.uuid4()),
                session_id=session_id,
                role="assistant",
                content="Machine learning is a subset of AI...",
                sources=None,
                created_at=datetime.utcnow()
            ),
            ChatMessage(
                message_id=str(uuid.uuid4()),
                session_id=session_id,
                role="user",
                content="Can you give me an example?",
                sources=None,
                created_at=datetime.utcnow()
            )
        ]
        
        # Mock query to return messages
        mock_db_session.query.return_value.filter.return_value.order_by.return_value.limit.return_value.all.return_value = messages
        
        # Get context
        context = SessionService.get_session_context(session_id, max_messages=10)
        
        assert len(context) == 3
        # Context is returned in reverse order (most recent first for RAG)
        assert context[0]["role"] == "user"
        assert context[0]["content"] == "Can you give me an example?"
        assert context[1]["role"] == "assistant"
        assert context[2]["role"] == "user"
        assert context[2]["content"] == "What is machine learning?"
        
        # Verify simplified format (no message_id, sources, etc.)
        assert "message_id" not in context[0]
        assert "sources" not in context[0]


class TestSessionSwitching:
    """Test switching between multiple chat sessions."""
    
    @patch('services.session_service.DatabaseManager.get_session')
    @patch('services.session_service.ChatSession')
    def test_create_multiple_sessions_and_switch(
        self, mock_chat_session_class, mock_get_session, 
        mock_db_session, sample_user
    ):
        """Test creating multiple sessions and switching between them."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Step 1: Create first session
        session_id_1 = str(uuid.uuid4())
        mock_session_1 = MagicMock()
        mock_session_1.session_id = session_id_1
        mock_session_1.user_id = sample_user.user_id
        mock_session_1.title = "Session 1"
        mock_session_1.is_active = True
        mock_session_1.created_at = datetime.utcnow()
        mock_session_1.updated_at = datetime.utcnow()
        mock_chat_session_class.return_value = mock_session_1
        
        created_id_1 = SessionService.create_session(sample_user.user_id, "Session 1")
        assert created_id_1 == session_id_1
        
        # Step 2: Create second session
        session_id_2 = str(uuid.uuid4())
        mock_session_2 = MagicMock()
        mock_session_2.session_id = session_id_2
        mock_session_2.user_id = sample_user.user_id
        mock_session_2.title = "Session 2"
        mock_session_2.is_active = True
        mock_session_2.created_at = datetime.utcnow()
        mock_session_2.updated_at = datetime.utcnow()
        mock_chat_session_class.return_value = mock_session_2
        
        created_id_2 = SessionService.create_session(sample_user.user_id, "Session 2")
        assert created_id_2 == session_id_2
        
        # Step 3: Verify both sessions were created
        assert created_id_1 is not None
        assert created_id_2 is not None
        assert created_id_1 != created_id_2
        
        # Step 4: Set active session
        mock_db_session.query.return_value.filter.return_value.first.return_value = mock_session_2
        
        result = SessionService.set_active_session(sample_user.user_id, session_id_2)
        
        assert result is True
        assert mock_session_2.updated_at is not None
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_get_active_session(self, mock_get_session, mock_db_session, sample_user):
        """Test retrieving the active session for a user."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create active session
        active_session = ChatSession(
            session_id=str(uuid.uuid4()),
            user_id=sample_user.user_id,
            title="Active Session",
            is_active=True,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        # Mock finding active session
        mock_db_session.query.return_value.filter.return_value.order_by.return_value.first.return_value = active_session
        
        # Mock message count
        mock_db_session.query.return_value.filter.return_value.scalar.return_value = 10
        
        # Get active session
        session = SessionService.get_active_session(sample_user.user_id)
        
        assert session is not None
        assert session["session_id"] == active_session.session_id
        assert session["title"] == "Active Session"
        assert session["message_count"] == 10
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_update_session_title(self, mock_get_session, mock_db_session):
        """Test updating session title."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create session
        session = ChatSession(
            session_id=str(uuid.uuid4()),
            user_id=str(uuid.uuid4()),
            title="Old Title",
            is_active=True,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        # Mock finding session
        mock_db_session.query.return_value.filter.return_value.first.return_value = session
        
        # Update title
        result = SessionService.update_session_title(session.session_id, "New Title")
        
        assert result is True
        assert session.title == "New Title"


class TestSessionDeletion:
    """Test session deletion with cascade."""
    
    @patch('services.session_service.DatabaseManager.get_session')
    @patch('services.session_service.ChatSession')
    @patch('services.session_service.ChatMessage')
    def test_delete_session_with_messages(
        self, mock_chat_message_class, mock_chat_session_class,
        mock_get_session, mock_db_session, sample_user
    ):
        """Test deleting a session cascades to delete all messages."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Step 1: Create session with messages
        session_id = str(uuid.uuid4())
        mock_session = MagicMock()
        mock_session.session_id = session_id
        mock_session.user_id = sample_user.user_id
        mock_session.title = "Test Session"
        mock_session.is_active = True
        mock_session.created_at = datetime.utcnow()
        mock_session.updated_at = datetime.utcnow()
        
        # Mock finding session
        mock_db_session.query.return_value.filter.return_value.first.return_value = mock_session
        
        # Mock message count
        mock_db_session.query.return_value.filter.return_value.scalar.return_value = 10
        
        # Step 2: Delete session
        result = SessionService.delete_session(session_id)
        
        assert result is True
        mock_db_session.delete.assert_called_once_with(mock_session)
        mock_db_session.commit.assert_called()
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_delete_session_removes_from_user_list(
        self, mock_get_session, mock_db_session
    ):
        """Test that deleted session no longer appears in user's session list."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create two sessions
        session_id_1 = str(uuid.uuid4())
        session_id_2 = str(uuid.uuid4())
        
        mock_session_1 = MagicMock()
        mock_session_1.session_id = session_id_1
        mock_session_1.title = "Session 1"
        
        mock_session_2 = MagicMock()
        mock_session_2.session_id = session_id_2
        mock_session_2.title = "Session 2"
        
        # Step 1: Delete one session
        mock_db_session.query.return_value.filter.return_value.first.return_value = mock_session_1
        mock_db_session.query.return_value.filter.return_value.scalar.return_value = 5
        
        result = SessionService.delete_session(session_id_1)
        assert result is True
        
        # Verify delete was called
        mock_db_session.delete.assert_called_once_with(mock_session_1)
        mock_db_session.commit.assert_called()
    
    @patch('services.session_service.DatabaseManager.get_session')
    def test_delete_nonexistent_session(self, mock_get_session, mock_db_session):
        """Test deleting a non-existent session returns False."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Attempt to delete non-existent session
        result = SessionService.delete_session("non-existent-id")
        
        assert result is False
        mock_db_session.delete.assert_not_called()


class TestMultipleSessionsWorkflow:
    """Test complete workflow with multiple sessions."""
    
    @patch('services.session_service.DatabaseManager.get_session')
    @patch('services.session_service.ChatSession')
    @patch('services.session_service.ChatMessage')
    def test_complete_multi_session_workflow(
        self, mock_chat_message_class, mock_chat_session_class,
        mock_get_session, mock_db_session, sample_user
    ):
        """Test complete workflow: create sessions, add messages, switch, delete."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = sample_user
        
        # Step 1: Create first session
        session_id_1 = str(uuid.uuid4())
        mock_session_1 = MagicMock()
        mock_session_1.session_id = session_id_1
        mock_session_1.user_id = sample_user.user_id
        mock_session_1.title = "Python Questions"
        mock_session_1.is_active = True
        mock_session_1.created_at = datetime.utcnow()
        mock_session_1.updated_at = datetime.utcnow()
        mock_chat_session_class.return_value = mock_session_1
        
        created_id_1 = SessionService.create_session(sample_user.user_id, "Python Questions")
        assert created_id_1 == session_id_1
        
        # Step 2: Add messages to first session
        mock_db_session.query.return_value.filter.return_value.first.return_value = mock_session_1
        
        msg_id_1 = str(uuid.uuid4())
        mock_msg_1 = MagicMock()
        mock_msg_1.message_id = msg_id_1
        mock_chat_message_class.return_value = mock_msg_1
        
        user_msg_1 = SessionService.add_message(session_id_1, "user", "What is Python?")
        assert user_msg_1 == msg_id_1
        
        msg_id_2 = str(uuid.uuid4())
        mock_msg_2 = MagicMock()
        mock_msg_2.message_id = msg_id_2
        mock_chat_message_class.return_value = mock_msg_2
        
        asst_msg_1 = SessionService.add_message(session_id_1, "assistant", "Python is a programming language...")
        assert asst_msg_1 == msg_id_2
        
        # Step 3: Create second session
        session_id_2 = str(uuid.uuid4())
        mock_session_2 = MagicMock()
        mock_session_2.session_id = session_id_2
        mock_session_2.user_id = sample_user.user_id
        mock_session_2.title = "JavaScript Questions"
        mock_session_2.is_active = True
        mock_session_2.created_at = datetime.utcnow()
        mock_session_2.updated_at = datetime.utcnow()
        mock_chat_session_class.return_value = mock_session_2
        
        created_id_2 = SessionService.create_session(sample_user.user_id, "JavaScript Questions")
        assert created_id_2 == session_id_2
        
        # Step 4: Switch to second session
        mock_db_session.query.return_value.filter.return_value.first.return_value = mock_session_2
        
        result = SessionService.set_active_session(sample_user.user_id, session_id_2)
        assert result is True
        
        # Step 5: Add message to second session
        msg_id_3 = str(uuid.uuid4())
        mock_msg_3 = MagicMock()
        mock_msg_3.message_id = msg_id_3
        mock_chat_message_class.return_value = mock_msg_3
        
        user_msg_2 = SessionService.add_message(session_id_2, "user", "What is JavaScript?")
        assert user_msg_2 == msg_id_3
        
        # Step 6: Verify both sessions and messages were created
        assert created_id_1 is not None
        assert created_id_2 is not None
        assert user_msg_1 is not None
        assert asst_msg_1 is not None
        assert user_msg_2 is not None
        
        # Step 7: Delete first session
        mock_db_session.query.return_value.filter.return_value.first.return_value = mock_session_1
        mock_db_session.query.return_value.filter.return_value.scalar.return_value = 2
        
        delete_result = SessionService.delete_session(session_id_1)
        assert delete_result is True
        
        # Verify delete was called
        mock_db_session.delete.assert_called()
        mock_db_session.commit.assert_called()
