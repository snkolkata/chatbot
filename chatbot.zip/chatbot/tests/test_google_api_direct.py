"""
Direct test of Google Generative AI API key validity.
"""
import os
from dotenv import load_dotenv

load_dotenv()

api_key = os.getenv("GOOGLE_API_KEY")
print(f"Testing API Key: {api_key[:20]}..." if api_key else "No API key found")

# Test with direct Google API call
try:
    import google.generativeai as genai
    
    genai.configure(api_key=api_key)
    
    # Try to list models to verify API key works
    print("\nTesting API key by listing available models...")
    models = genai.list_models()
    
    print("✓ API Key is VALID!")
    print("\nAvailable embedding models:")
    for model in models:
        if 'embedding' in model.name.lower():
            print(f"  - {model.name}")
    
except Exception as e:
    print(f"\n✗ API Key is INVALID or there's an error:")
    print(f"  Error: {e}")
    
    print("\n" + "="*60)
    print("SOLUTION:")
    print("="*60)
    print("1. Go to: https://aistudio.google.com/app/apikey")
    print("2. Create a new API key or copy your existing one")
    print("3. Update the GOOGLE_API_KEY in your .env file")
    print("4. Make sure there are no extra spaces or quotes")
    print("="*60)
