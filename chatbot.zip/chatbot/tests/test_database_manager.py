"""
Tests for DatabaseManager functionality.
"""
import pytest
from unittest.mock import Mock, patch, MagicMock
from sqlalchemy.exc import OperationalError

from services.database_manager import DatabaseManager, Base


class TestDatabaseManager:
    """Test suite for DatabaseManager class."""
    
    def setup_method(self):
        """Reset DatabaseManager state before each test."""
        DatabaseManager._engine = None
        DatabaseManager._session_factory = None
    
    def teardown_method(self):
        """Clean up after each test."""
        if DatabaseManager._engine is not None:
            DatabaseManager.close()
    
    @patch('services.database_manager.create_engine')
    @patch('services.database_manager.sessionmaker')
    def test_initialize_success(self, mock_sessionmaker, mock_create_engine):
        """Test successful database initialization."""
        mock_engine = Mock()
        mock_create_engine.return_value = mock_engine
        mock_session_factory = Mock()
        mock_sessionmaker.return_value = mock_session_factory
        
        DatabaseManager.initialize()
        
        assert DatabaseManager._engine is not None
        assert DatabaseManager._session_factory is not None
        mock_create_engine.assert_called_once()
    
    @patch('services.database_manager.create_engine')
    def test_initialize_already_initialized(self, mock_create_engine):
        """Test that initialize warns when already initialized."""
        mock_engine = Mock()
        mock_create_engine.return_value = mock_engine
        
        DatabaseManager.initialize()
        first_engine = DatabaseManager._engine
        
        DatabaseManager.initialize()
        
        # Should still be the same engine
        assert DatabaseManager._engine is first_engine
    
    def test_get_engine_not_initialized(self):
        """Test get_engine raises error when not initialized."""
        with pytest.raises(RuntimeError, match="not initialized"):
            DatabaseManager.get_engine()
    
    @patch('services.database_manager.create_engine')
    def test_get_engine_success(self, mock_create_engine):
        """Test get_engine returns engine when initialized."""
        mock_engine = Mock()
        mock_create_engine.return_value = mock_engine
        
        DatabaseManager.initialize()
        engine = DatabaseManager.get_engine()
        
        assert engine is mock_engine
    
    def test_get_session_not_initialized(self):
        """Test get_session raises error when not initialized."""
        with pytest.raises(RuntimeError, match="not initialized"):
            with DatabaseManager.get_session() as session:
                pass
    
    @patch('services.database_manager.create_engine')
    @patch('services.database_manager.sessionmaker')
    def test_get_session_success(self, mock_sessionmaker, mock_create_engine):
        """Test get_session context manager works correctly."""
        mock_engine = Mock()
        mock_create_engine.return_value = mock_engine
        
        mock_session = Mock()
        mock_session_factory = Mock(return_value=mock_session)
        mock_sessionmaker.return_value = mock_session_factory
        
        DatabaseManager.initialize()
        
        with DatabaseManager.get_session() as session:
            assert session is mock_session
        
        mock_session.commit.assert_called_once()
        mock_session.close.assert_called_once()
    
    @patch('services.database_manager.create_engine')
    @patch('services.database_manager.sessionmaker')
    def test_get_session_rollback_on_error(self, mock_sessionmaker, mock_create_engine):
        """Test get_session rolls back on error."""
        mock_engine = Mock()
        mock_create_engine.return_value = mock_engine
        
        mock_session = Mock()
        mock_session_factory = Mock(return_value=mock_session)
        mock_sessionmaker.return_value = mock_session_factory
        
        DatabaseManager.initialize()
        
        with pytest.raises(ValueError):
            with DatabaseManager.get_session() as session:
                raise ValueError("Test error")
        
        mock_session.rollback.assert_called_once()
        mock_session.close.assert_called_once()
    
    @patch('services.database_manager.create_engine')
    def test_health_check_success(self, mock_create_engine):
        """Test health check returns True when database is accessible."""
        mock_connection = MagicMock()
        mock_result = Mock()
        mock_connection.execute.return_value = mock_result
        
        mock_engine = Mock()
        mock_engine.connect.return_value.__enter__ = Mock(return_value=mock_connection)
        mock_engine.connect.return_value.__exit__ = Mock(return_value=False)
        mock_create_engine.return_value = mock_engine
        
        DatabaseManager.initialize()
        result = DatabaseManager.health_check()
        
        assert result is True
    
    @patch('services.database_manager.create_engine')
    def test_health_check_failure(self, mock_create_engine):
        """Test health check returns False on connection error."""
        mock_engine = Mock()
        mock_engine.connect.side_effect = OperationalError("Connection failed", None, None)
        mock_create_engine.return_value = mock_engine
        
        DatabaseManager.initialize()
        result = DatabaseManager.health_check()
        
        assert result is False
    
    def test_health_check_not_initialized(self):
        """Test health check returns False when not initialized."""
        result = DatabaseManager.health_check()
        assert result is False
    
    @patch('services.database_manager.create_engine')
    def test_get_connection_info_initialized(self, mock_create_engine):
        """Test get_connection_info returns pool statistics."""
        mock_pool = Mock()
        mock_pool.size.return_value = 5
        mock_pool.checkedin.return_value = 3
        mock_pool.checkedout.return_value = 2
        mock_pool.overflow.return_value = 0
        
        mock_engine = Mock()
        mock_engine.pool = mock_pool
        mock_create_engine.return_value = mock_engine
        
        DatabaseManager.initialize()
        info = DatabaseManager.get_connection_info()
        
        assert info['status'] == 'initialized'
        assert info['pool_size'] == 5
        assert info['checked_in_connections'] == 3
        assert info['checked_out_connections'] == 2
    
    def test_get_connection_info_not_initialized(self):
        """Test get_connection_info returns not_initialized status."""
        info = DatabaseManager.get_connection_info()
        assert info['status'] == 'not_initialized'
    
    @patch('services.database_manager.create_engine')
    def test_close(self, mock_create_engine):
        """Test close disposes engine and resets state."""
        mock_engine = Mock()
        mock_create_engine.return_value = mock_engine
        
        DatabaseManager.initialize()
        DatabaseManager.close()
        
        mock_engine.dispose.assert_called_once()
        assert DatabaseManager._engine is None
        assert DatabaseManager._session_factory is None
