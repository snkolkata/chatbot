"""
Test script to verify RAG query functionality with correct API key.
"""
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Set environment variables (same as run_app.ps1)
os.environ["GEMINI_API_KEY"] = os.getenv("GEMINI_API_KEY", "")
os.environ["GOOGLE_API_KEY"] = os.getenv("GOOGLE_API_KEY", "")

print("=" * 60)
print("RAG Query Test")
print("=" * 60)

# Test 1: Check environment
print("\n1. Environment Check:")
print(f"   GOOGLE_API_KEY: {'✓ Set' if os.getenv('GOOGLE_API_KEY') else '✗ Not Set'}")

# Test 2: Initialize services
print("\n2. Initializing Services:")
try:
    from services.vector_store import VectorStoreManager
    from services.rag_service import RAGService
    from config.settings import settings
    
    print("   ✓ Imports successful")
    print(f"   GOOGLE_API_KEY in env: {'✓ Yes' if os.getenv('GOOGLE_API_KEY') else '✗ No'}")
    
    # Initialize vector store
    vector_store = VectorStoreManager(settings.VECTOR_STORE_PATH)
    vector_store.initialize()
    print("   ✓ Vector store initialized")
    
    # Initialize RAG service
    rag_service = RAGService(vector_store)
    print("   ✓ RAG service initialized")
    
except Exception as e:
    print(f"   ✗ Error: {e}")
    import traceback
    traceback.print_exc()
    exit(1)

# Test 3: Test query
print("\n3. Testing RAG Query:")
try:
    test_query = "What is the attention mechanism?"
    
    print(f"   Query: '{test_query}'")
    
    # Get relevant chunks
    chunks = rag_service.get_relevant_chunks(test_query, k=2)
    print(f"   ✓ Retrieved {len(chunks)} relevant chunks")
    
    if chunks:
        print(f"   First chunk preview: {chunks[0].page_content[:100]}...")
    
    # Generate response
    response = rag_service.query(test_query)
    print(f"   ✓ Generated response ({len(response)} characters)")
    print(f"\n   Response preview:")
    print(f"   {response[:200]}...")
    
except Exception as e:
    print(f"   ✗ Error: {e}")
    import traceback
    traceback.print_exc()
    exit(1)

print("\n" + "=" * 60)
print("✅ All Tests Passed!")
print("=" * 60)
