"""
Integration tests for complete authentication flow.
Tests registration to login flow, password reset flow, and session persistence.
Requirements: 1.2, 2.2, 10.5
"""
import pytest
from datetime import datetime, timedelta
from unittest.mock import patch, MagicMock
import uuid

from services.auth_service import AuthService, AuthenticationError, InvalidTokenError
from services.user_service import UserService
from services.models import User, PasswordResetToken
from services.database_manager import DatabaseManager


@pytest.fixture
def mock_db_session():
    """Create a mock database session for integration tests."""
    session = MagicMock()
    session.commit = MagicMock()
    session.rollback = MagicMock()
    session.close = MagicMock()
    session.add = MagicMock()
    session.delete = MagicMock()
    session.flush = MagicMock()
    return session


class TestRegistrationToLoginFlow:
    """Test complete flow from registration to login."""
    
    @patch('services.auth_service.DatabaseManager.get_session')
    @patch('services.user_service.DatabaseManager.get_session')
    def test_complete_registration_and_login_flow(self, mock_user_get_session, mock_auth_get_session, mock_db_session):
        """Test user can register and then login successfully."""
        # Setup mocks
        mock_auth_get_session.return_value.__enter__.return_value = mock_db_session
        mock_user_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Step 1: Register new user
        # Mock no existing user
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Mock user creation
        created_user = None
        def add_side_effect(user):
            nonlocal created_user
            if isinstance(user, User):
                user.user_id = str(uuid.uuid4())
                created_user = user
        mock_db_session.add.side_effect = add_side_effect
        
        # Register user
        registration_result = AuthService.register_user(
            email="newuser@example.com",
            password="TestPass123",
            full_name="New User"
        )
        
        assert registration_result is not None
        assert registration_result["email"] == "newuser@example.com"
        assert registration_result["role"] == "user"
        assert "user_id" in registration_result
        
        # Step 2: Login with registered credentials
        # Mock finding the registered user
        mock_db_session.query.return_value.filter.return_value.first.return_value = created_user
        
        # Authenticate user
        login_result = AuthService.authenticate_user("newuser@example.com", "TestPass123")
        
        assert login_result is not None
        assert login_result["email"] == "newuser@example.com"
        assert login_result["user_id"] == created_user.user_id
        assert login_result["role"] == "user"
        
        # Verify last_login was updated
        assert created_user.last_login is not None
        assert created_user.failed_login_attempts == 0
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_registration_prevents_duplicate_email(self, mock_get_session, mock_db_session):
        """Test that registration prevents duplicate email addresses."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create existing user
        existing_user = User(
            user_id=str(uuid.uuid4()),
            email="existing@example.com",
            password_hash=AuthService.hash_password("ExistingPass123"),
            full_name="Existing User",
            role="user",
            is_active=True,
            failed_login_attempts=0,
            account_locked_until=None,
            created_at=datetime.utcnow(),
            last_login=None
        )
        
        # Mock finding existing user
        mock_db_session.query.return_value.filter.return_value.first.return_value = existing_user
        
        # Attempt to register with same email
        with pytest.raises(ValueError, match="already registered"):
            AuthService.register_user(
                email="existing@example.com",
                password="NewPass123",
                full_name="New User"
            )
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_login_fails_with_wrong_password(self, mock_get_session, mock_db_session):
        """Test that login fails with incorrect password and tracks attempts."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create user
        user = User(
            user_id=str(uuid.uuid4()),
            email="test@example.com",
            password_hash=AuthService.hash_password("CorrectPass123"),
            full_name="Test User",
            role="user",
            is_active=True,
            failed_login_attempts=0,
            account_locked_until=None,
            created_at=datetime.utcnow(),
            last_login=None
        )
        
        # Mock finding user
        mock_db_session.query.return_value.filter.return_value.first.return_value = user
        
        # Attempt login with wrong password
        with pytest.raises(AuthenticationError, match="Invalid email or password"):
            AuthService.authenticate_user("test@example.com", "WrongPass123")
        
        # Verify failed attempt was tracked
        assert user.failed_login_attempts == 1


class TestPasswordResetFlow:
    """Test complete password reset flow."""
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_complete_password_reset_flow(self, mock_get_session, mock_db_session):
        """Test user can request password reset, verify token, and reset password."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create user
        user = User(
            user_id=str(uuid.uuid4()),
            email="user@example.com",
            password_hash=AuthService.hash_password("OldPass123"),
            full_name="Test User",
            role="user",
            is_active=True,
            failed_login_attempts=0,
            account_locked_until=None,
            created_at=datetime.utcnow(),
            last_login=None
        )
        
        # Step 1: Request password reset token
        mock_db_session.query.return_value.filter.return_value.first.return_value = user
        
        # Mock token creation
        created_token = None
        def add_side_effect(obj):
            nonlocal created_token
            if isinstance(obj, PasswordResetToken):
                obj.token_id = str(uuid.uuid4())
                created_token = obj
        mock_db_session.add.side_effect = add_side_effect
        
        token = AuthService.create_password_reset_token("user@example.com")
        
        assert token is not None
        assert isinstance(token, str)
        assert len(token) > 0
        
        # Step 2: Verify token is valid
        # Mock finding the token
        mock_db_session.query.return_value.filter.return_value.first.return_value = created_token
        
        user_id = AuthService.verify_reset_token(token)
        
        assert user_id == user.user_id
        
        # Step 3: Reset password with valid token
        # Mock query chain for token and user
        def query_side_effect(model):
            mock_query = MagicMock()
            if model == PasswordResetToken:
                mock_query.filter.return_value.first.return_value = created_token
            elif model == User:
                mock_query.filter.return_value.first.return_value = user
            return mock_query
        
        mock_db_session.query.side_effect = query_side_effect
        
        result = AuthService.reset_password(token, "NewPass123")
        
        assert result is True
        assert created_token.used is True
        
        # Step 4: Verify can login with new password
        # Reset query side effect
        mock_db_session.query.side_effect = None
        mock_db_session.query.return_value.filter.return_value.first.return_value = user
        
        login_result = AuthService.authenticate_user("user@example.com", "NewPass123")
        
        assert login_result is not None
        assert login_result["email"] == "user@example.com"
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_password_reset_token_expires(self, mock_get_session, mock_db_session):
        """Test that expired password reset tokens are rejected."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create expired token
        expired_token = PasswordResetToken(
            token_id=str(uuid.uuid4()),
            user_id=str(uuid.uuid4()),
            token="expired-token",
            expires_at=datetime.utcnow() - timedelta(hours=2),
            used=False
        )
        
        # Mock finding expired token
        mock_db_session.query.return_value.filter.return_value.first.return_value = expired_token
        
        # Verify token fails
        with pytest.raises(InvalidTokenError, match="expired"):
            AuthService.verify_reset_token("expired-token")
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_password_reset_token_single_use(self, mock_get_session, mock_db_session):
        """Test that password reset tokens can only be used once."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create used token
        used_token = PasswordResetToken(
            token_id=str(uuid.uuid4()),
            user_id=str(uuid.uuid4()),
            token="used-token",
            expires_at=datetime.utcnow() + timedelta(hours=1),
            used=True
        )
        
        # Mock finding used token
        mock_db_session.query.return_value.filter.return_value.first.return_value = used_token
        
        # Verify token fails
        with pytest.raises(InvalidTokenError, match="already been used"):
            AuthService.verify_reset_token("used-token")
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_password_reset_for_nonexistent_user(self, mock_get_session, mock_db_session):
        """Test password reset request for non-existent user returns None (no user enumeration)."""
        # Setup mock to return None
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        
        # Request reset for non-existent user
        token = AuthService.create_password_reset_token("nonexistent@example.com")
        
        # Should return None without revealing user doesn't exist
        assert token is None


class TestSessionPersistence:
    """Test session persistence across page loads."""
    
    @patch('services.auth_service.DatabaseManager.get_session')
    @patch('services.user_service.DatabaseManager.get_session')
    def test_user_data_persists_after_login(self, mock_user_get_session, mock_auth_get_session, mock_db_session):
        """Test that user data can be retrieved after login."""
        # Setup mocks
        mock_auth_get_session.return_value.__enter__.return_value = mock_db_session
        mock_user_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create user
        user = User(
            user_id=str(uuid.uuid4()),
            email="test@example.com",
            password_hash=AuthService.hash_password("TestPass123"),
            full_name="Test User",
            role="user",
            is_active=True,
            failed_login_attempts=0,
            account_locked_until=None,
            created_at=datetime.utcnow(),
            last_login=None
        )
        
        # Step 1: Login
        mock_db_session.query.return_value.filter.return_value.first.return_value = user
        
        login_result = AuthService.authenticate_user("test@example.com", "TestPass123")
        user_id = login_result["user_id"]
        
        # Step 2: Simulate page load - retrieve user by ID
        user_data = UserService.get_user_by_id(user_id)
        
        assert user_data is not None
        assert user_data["user_id"] == user_id
        assert user_data["email"] == "test@example.com"
        assert user_data["full_name"] == "Test User"
        assert user_data["role"] == "user"
    
    @patch('services.user_service.DatabaseManager.get_session')
    def test_last_login_timestamp_updated(self, mock_get_session, mock_db_session):
        """Test that last login timestamp is updated on login."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create user with no last login
        user = User(
            user_id=str(uuid.uuid4()),
            email="test@example.com",
            password_hash="hashed_password",
            full_name="Test User",
            role="user",
            is_active=True,
            failed_login_attempts=0,
            account_locked_until=None,
            created_at=datetime.utcnow(),
            last_login=None
        )
        
        # Mock finding user
        mock_db_session.query.return_value.filter.return_value.first.return_value = user
        
        # Update last login
        result = UserService.update_last_login(user.user_id)
        
        assert result is True
        assert user.last_login is not None
        assert isinstance(user.last_login, datetime)
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_inactive_user_cannot_login(self, mock_get_session, mock_db_session):
        """Test that inactive users cannot login."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create inactive user
        user = User(
            user_id=str(uuid.uuid4()),
            email="inactive@example.com",
            password_hash=AuthService.hash_password("TestPass123"),
            full_name="Inactive User",
            role="user",
            is_active=False,
            failed_login_attempts=0,
            account_locked_until=None,
            created_at=datetime.utcnow(),
            last_login=None
        )
        
        # Mock finding user
        mock_db_session.query.return_value.filter.return_value.first.return_value = user
        
        # Attempt login
        with pytest.raises(ValueError, match="inactive"):
            AuthService.authenticate_user("inactive@example.com", "TestPass123")


class TestAccountLockoutIntegration:
    """Test account lockout integration with authentication flow."""
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_account_locks_after_failed_attempts(self, mock_get_session, mock_db_session):
        """Test that account locks after maximum failed login attempts."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create user
        user = User(
            user_id=str(uuid.uuid4()),
            email="test@example.com",
            password_hash=AuthService.hash_password("CorrectPass123"),
            full_name="Test User",
            role="user",
            is_active=True,
            failed_login_attempts=0,
            account_locked_until=None,
            created_at=datetime.utcnow(),
            last_login=None
        )
        
        # Mock finding user
        mock_db_session.query.return_value.filter.return_value.first.return_value = user
        
        # Attempt login with wrong password multiple times
        from config.settings import settings
        for i in range(settings.MAX_LOGIN_ATTEMPTS):
            try:
                AuthService.authenticate_user("test@example.com", "WrongPass123")
            except AuthenticationError:
                pass
        
        # Verify account is locked
        assert user.account_locked_until is not None
        assert user.account_locked_until > datetime.utcnow()
        assert user.failed_login_attempts == settings.MAX_LOGIN_ATTEMPTS
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_locked_account_prevents_login(self, mock_get_session, mock_db_session):
        """Test that locked account prevents login even with correct password."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create locked user
        user = User(
            user_id=str(uuid.uuid4()),
            email="locked@example.com",
            password_hash=AuthService.hash_password("CorrectPass123"),
            full_name="Locked User",
            role="user",
            is_active=True,
            failed_login_attempts=5,
            account_locked_until=datetime.utcnow() + timedelta(minutes=15),
            created_at=datetime.utcnow(),
            last_login=None
        )
        
        # Mock finding user
        mock_db_session.query.return_value.filter.return_value.first.return_value = user
        
        # Verify account is locked
        is_locked = AuthService.is_account_locked("locked@example.com")
        assert is_locked is True
    
    @patch('services.auth_service.DatabaseManager.get_session')
    def test_account_unlocks_after_timeout(self, mock_get_session, mock_db_session):
        """Test that account automatically unlocks after lockout period."""
        # Setup mock
        mock_get_session.return_value.__enter__.return_value = mock_db_session
        
        # Create user with expired lock
        user = User(
            user_id=str(uuid.uuid4()),
            email="unlocked@example.com",
            password_hash=AuthService.hash_password("TestPass123"),
            full_name="Unlocked User",
            role="user",
            is_active=True,
            failed_login_attempts=5,
            account_locked_until=datetime.utcnow() - timedelta(minutes=1),
            created_at=datetime.utcnow(),
            last_login=None
        )
        
        # Mock finding user
        mock_db_session.query.return_value.filter.return_value.first.return_value = user
        
        # Verify account is not locked
        is_locked = AuthService.is_account_locked("unlocked@example.com")
        assert is_locked is False
        assert user.account_locked_until is None
        assert user.failed_login_attempts == 0
