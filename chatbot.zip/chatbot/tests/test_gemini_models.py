"""
Test script to find which Gemini models work with your API key.
"""
import os
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI

load_dotenv()

# Set environment variables
os.environ["GOOGLE_API_KEY"] = os.getenv("GOOGLE_API_KEY", "")

print("=" * 70)
print("Testing Gemini Models")
print("=" * 70)

# List of models to test (most relevant ones)
models_to_test = [
    "gemini-1.5-flash",
    "gemini-1.5-pro",
    "gemini-2.0-flash-exp",
    "gemini-2.5-flash",
    "gemini-2.5-pro",
    "gemini-exp-1206",
    "gemini-3-pro-preview",
]

working_models = []
failed_models = []

for model_name in models_to_test:
    print(f"\n{'='*70}")
    print(f"Testing: {model_name}")
    print(f"{'='*70}")
    
    try:
        # Initialize the model
        llm = ChatGoogleGenerativeAI(
            model=model_name,
            temperature=0.7
        )
        
        # Try a simple query
        response = llm.invoke("Say 'Hello' in one word")
        
        print(f"✅ SUCCESS - {model_name}")
        print(f"   Response: {response.content[:100]}")
        working_models.append(model_name)
        
    except Exception as e:
        error_msg = str(e)
        print(f"❌ FAILED - {model_name}")
        
        if "429" in error_msg or "quota" in error_msg.lower():
            print(f"   Error: Rate limit exceeded")
            failed_models.append((model_name, "Rate limit"))
        elif "404" in error_msg or "not found" in error_msg.lower():
            print(f"   Error: Model not found")
            failed_models.append((model_name, "Not found"))
        elif "403" in error_msg or "permission" in error_msg.lower():
            print(f"   Error: Permission denied")
            failed_models.append((model_name, "Permission denied"))
        else:
            print(f"   Error: {error_msg[:150]}")
            failed_models.append((model_name, "Other error"))

print("\n" + "=" * 70)
print("SUMMARY")
print("=" * 70)

print(f"\n✅ Working Models ({len(working_models)}):")
if working_models:
    for model in working_models:
        print(f"   - {model}")
else:
    print("   None found")

print(f"\n❌ Failed Models ({len(failed_models)}):")
if failed_models:
    for model, reason in failed_models:
        print(f"   - {model}: {reason}")
else:
    print("   None")

if working_models:
    print(f"\n{'='*70}")
    print("RECOMMENDATION")
    print("=" * 70)
    print(f"\nBest model to use: {working_models[0]}")
    print(f"\nUpdate your .env file:")
    print(f"LLM_MODEL={working_models[0]}")
    
print("\n" + "=" * 70)
