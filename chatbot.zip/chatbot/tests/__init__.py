"""Integration tests for RAG Chatbot application."""
