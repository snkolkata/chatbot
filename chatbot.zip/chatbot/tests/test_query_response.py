"""
Integration tests for query and response flow.

Tests Requirements: 1.2, 1.3
"""

import pytest
from io import BytesIO

from utils.helpers import ValidationError


class TestQueryResponse:
    """Test end-to-end query and response flow."""
    
    def test_query_with_relevant_documents(self, document_service, rag_service):
        """Test querying with relevant documents in the system."""
        # Upload a test document
        file = BytesIO(b"Python is a programming language. It is used for web development and data science.")
        file.name = "python_info.txt"
        document_service.upload_document(file, "python_info.txt")
        
        # Query the system
        result = rag_service.query("What is Python?")
        
        # Verify response structure
        assert 'response' in result
        assert 'sources' in result
        assert 'chunk_count' in result
        
        # Verify response content
        assert isinstance(result['response'], str)
        assert len(result['response']) > 0
        
        # Verify sources
        assert len(result['sources']) > 0
        assert "python_info.txt" in result['sources']
        
        # Verify chunks were retrieved
        assert result['chunk_count'] > 0
    
    def test_query_without_documents(self, rag_service):
        """Test querying when no documents are in the system."""
        result = rag_service.query("What is Python?")
        
        # Verify response indicates no documents
        assert 'response' in result
        assert "don't have any relevant information" in result['response'].lower() or \
               "no relevant" in result['response'].lower()
        assert result['chunk_count'] == 0
        assert len(result['sources']) == 0
    
    def test_query_empty_string(self, rag_service):
        """Test querying with empty string."""
        with pytest.raises(ValidationError) as exc_info:
            rag_service.query("")
        
        assert "cannot be empty" in str(exc_info.value).lower()
    
    def test_query_retrieves_correct_chunks(self, document_service, rag_service):
        """Test that query retrieves relevant chunks."""
        # Upload documents with different topics
        file1 = BytesIO(b"Python is a programming language used for software development.")
        file1.name = "python.txt"
        document_service.upload_document(file1, "python.txt")
        
        file2 = BytesIO(b"JavaScript is a programming language used for web development.")
        file2.name = "javascript.txt"
        document_service.upload_document(file2, "javascript.txt")
        
        # Query about Python
        result = rag_service.query("Tell me about Python")
        
        # Verify response was generated
        assert result['chunk_count'] > 0
        assert len(result['response']) > 0
    
    def test_multiple_queries_same_session(self, document_service, rag_service):
        """Test multiple queries in the same session."""
        # Upload a document
        file = BytesIO(b"Machine learning is a subset of AI. Deep learning uses neural networks.")
        file.name = "ml_info.txt"
        document_service.upload_document(file, "ml_info.txt")
        
        # First query
        result1 = rag_service.query("What is machine learning?")
        assert result1['chunk_count'] > 0
        
        # Second query
        result2 = rag_service.query("What is deep learning?")
        assert result2['chunk_count'] > 0
        
        # Both queries should return responses
        assert len(result1['response']) > 0
        assert len(result2['response']) > 0
