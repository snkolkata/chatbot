"""
Pytest configuration and fixtures for integration tests.
"""

import pytest
import os
import shutil
import tempfile
from unittest.mock import Mock, patch
from io import BytesIO

from config.settings import Settings
from services.vector_store import VectorStoreManager
from services.document_service import DocumentService
from services.rag_service import RAGService


@pytest.fixture(scope="function")
def temp_dir():
    """Create a temporary directory for test data."""
    temp_path = tempfile.mkdtemp()
    yield temp_path
    # Cleanup after test
    if os.path.exists(temp_path):
        import gc
        import time
        gc.collect()  # Force garbage collection
        time.sleep(0.2)  # Small delay to ensure file handles are released
        
        # Try multiple times with increasing delays
        max_retries = 5
        for attempt in range(max_retries):
            try:
                shutil.rmtree(temp_path)
                break
            except PermissionError as e:
                if attempt < max_retries - 1:
                    time.sleep(0.5 * (attempt + 1))  # Exponential backoff
                    gc.collect()
                else:
                    # On final attempt, try to remove what we can
                    import warnings
                    warnings.warn(f"Could not fully clean up temp directory: {temp_path}")
                    break


@pytest.fixture(scope="function")
def test_settings(temp_dir):
    """Create test settings with temporary paths."""
    settings = Settings()
    settings.VECTOR_STORE_PATH = os.path.join(temp_dir, "chroma_db")
    settings.DOCUMENT_STORAGE_PATH = os.path.join(temp_dir, "documents")
    settings.OPENAI_API_KEY = "test-api-key"
    settings.MAX_FILE_SIZE_MB = 10
    return settings


@pytest.fixture(scope="function")
def mock_openai_embeddings():
    """Mock OpenAI embeddings to avoid API calls."""
    with patch('services.vector_store.OpenAIEmbeddings') as mock:
        mock_instance = Mock()
        # Return one embedding per input document
        mock_instance.embed_documents.side_effect = lambda texts: [[0.1] * 1536 for _ in texts]
        mock_instance.embed_query.return_value = [0.1] * 1536
        mock.return_value = mock_instance
        yield mock_instance


@pytest.fixture(scope="function")
def vector_store(test_settings, mock_openai_embeddings):
    """Create a vector store instance for testing."""
    store = VectorStoreManager(
        persist_directory=test_settings.VECTOR_STORE_PATH,
        embedding_function=mock_openai_embeddings
    )
    store.initialize()
    yield store
    store.cleanup()


@pytest.fixture(scope="function")
def document_service(vector_store, test_settings):
    """Create a document service instance for testing."""
    with patch('config.settings.settings', test_settings):
        service = DocumentService(
            vector_store=vector_store,
            storage_path=test_settings.DOCUMENT_STORAGE_PATH
        )
        return service


@pytest.fixture(scope="function")
def mock_llm_client():
    """Mock LLM client to avoid API calls."""
    mock_client = Mock()
    mock_response = Mock()
    mock_response.content = "This is a test response based on the provided context."
    mock_client.invoke.return_value = mock_response
    return mock_client


@pytest.fixture(scope="function")
def rag_service(vector_store, test_settings, mock_llm_client):
    """Create a RAG service instance for testing."""
    with patch('config.settings.settings', test_settings):
        service = RAGService(vector_store=vector_store)
        service.llm_client = mock_llm_client
        return service


@pytest.fixture
def sample_txt_file():
    """Create a sample TXT file for testing."""
    content = b"This is a test document.\nIt contains multiple lines.\nThis is used for testing the RAG system."
    file = BytesIO(content)
    file.name = "test_document.txt"
    return file


@pytest.fixture
def sample_pdf_content():
    """Create sample PDF content for testing."""
    # Simple PDF content for testing
    content = b"%PDF-1.4\nTest PDF content for integration testing.\nThis document tests the upload functionality."
    return content
