"""Comprehensive API key diagnostic"""
import os
import sys
from pathlib import Path

print("="*60)
print("GEMINI API KEY DIAGNOSTIC")
print("="*60)

# 1. Check .env file directly
print("\n1. Reading .env file directly:")
env_path = Path('.env')
if env_path.exists():
    with open(env_path, 'r', encoding='utf-8') as f:
        for line in f:
            if 'GEMINI_API_KEY' in line and not line.strip().startswith('#'):
                print(f"   Found in file: {line.strip()}")
                key_from_file = line.split('=', 1)[1].strip().strip('"').strip("'")
                print(f"   Extracted key: {key_from_file}")
                print(f"   Key length: {len(key_from_file)}")
                print(f"   First 15 chars: {key_from_file[:15]}")
                print(f"   Last 5 chars: {key_from_file[-5:]}")
else:
    print("   ERROR: .env file not found!")

# 2. Check with python-dotenv
print("\n2. Loading with python-dotenv:")
from dotenv import load_dotenv
load_dotenv(override=True)
api_key = os.getenv('GEMINI_API_KEY')
if api_key:
    print(f"   Loaded key: {api_key}")
    print(f"   Key length: {len(api_key)}")
    print(f"   First 15 chars: {api_key[:15]}")
    print(f"   Last 5 chars: {api_key[-5:]}")
else:
    print("   ERROR: Key not loaded by dotenv!")

# 3. Test with Google API directly
print("\n3. Testing with Google Generative AI library:")
try:
    import google.generativeai as genai
    genai.configure(api_key=api_key)
    
    # Try to list models
    print("   Attempting to list models...")
    models = genai.list_models()
    model_list = list(models)
    print(f"   ✓ SUCCESS! Found {len(model_list)} models")
    print(f"   API key is VALID!")
    
except Exception as e:
    print(f"   ✗ FAILED: {str(e)}")
    print(f"   API key is INVALID or has wrong permissions")

# 4. Test with LangChain
print("\n4. Testing with LangChain GoogleGenerativeAIEmbeddings:")
try:
    from langchain_google_genai import GoogleGenerativeAIEmbeddings
    embeddings = GoogleGenerativeAIEmbeddings(
        model="models/embedding-001",
        google_api_key=api_key
    )
    result = embeddings.embed_query("test")
    print(f"   ✓ SUCCESS! Embedding dimension: {len(result)}")
    print(f"   API key works with LangChain!")
    
except Exception as e:
    print(f"   ✗ FAILED: {str(e)}")
    import traceback
    traceback.print_exc()

print("\n" + "="*60)
print("DIAGNOSIS COMPLETE")
print("="*60)
