# Integration Tests

This directory contains integration tests for the RAG Chatbot application.

## Test Coverage

The integration tests cover the following core functionality:

1. **Document Upload Flow** (`test_document_upload.py`)
   - Successful document upload
   - File format validation
   - File size validation
   - Multiple document uploads
   - Document chunking

2. **Query and Response Flow** (`test_query_response.py`)
   - Querying with relevant documents
   - Querying without documents
   - Empty query validation
   - Chunk retrieval
   - Multiple queries in same session

3. **Document Deletion and Cleanup** (`test_document_deletion.py`)
   - Successful document deletion
   - Nonexistent document handling
   - Physical file removal
   - Vector store cleanup
   - Selective deletion from multiple documents

## Running Tests

### Install Test Dependencies

```bash
pip install -r requirements.txt
```

### Run All Tests

```bash
pytest tests/
```

### Run Specific Test File

```bash
pytest tests/test_document_upload.py
```

### Run with Verbose Output

```bash
pytest tests/ -v
```

### Run with Coverage Report

```bash
pytest tests/ --cov=services --cov=utils
```

## Test Configuration

- Tests use mocked OpenAI API calls to avoid actual API usage
- Temporary directories are created for each test and cleaned up automatically
- Each test runs in isolation with fresh service instances

## Notes

- OpenAI API calls are mocked to prevent actual API usage during tests
- Tests focus on core functional logic without over-testing edge cases
- All tests are designed to run quickly and independently
