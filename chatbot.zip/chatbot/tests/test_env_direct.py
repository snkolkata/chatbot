"""Direct test of .env loading"""
import os
from pathlib import Path

# Read .env file directly
env_path = Path('.env')
print(f"Reading from: {env_path.absolute()}")
print(f"File exists: {env_path.exists()}")

if env_path.exists():
    with open(env_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        for i, line in enumerate(lines, 1):
            if 'GEMINI_API_KEY' in line:
                print(f"Line {i}: {repr(line)}")
                # Extract the key
                if '=' in line and not line.strip().startswith('#'):
                    key = line.split('=', 1)[1].strip()
                    print(f"Extracted key: {key}")
                    print(f"Key length: {len(key)}")
                    print(f"First 20 chars: {key[:20]}")

# Now test with dotenv
print("\n--- Testing with dotenv ---")
from dotenv import load_dotenv
load_dotenv()
api_key = os.getenv('GEMINI_API_KEY')
print(f"Loaded via dotenv: {api_key}")
print(f"Type: {type(api_key)}")
if api_key:
    print(f"Length: {len(api_key)}")
