"""Quick test to verify Gemini API key works"""
import os
from dotenv import load_dotenv
from langchain_google_genai import GoogleGenerativeAIEmbeddings, ChatGoogleGenerativeAI

load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")
print(f"API Key loaded: {api_key[:10]}..." if api_key else "No API key found")

try:
    # Test embeddings
    print("\nTesting Gemini Embeddings...")
    embeddings = GoogleGenerativeAIEmbeddings(
        model="models/embedding-001",
        google_api_key=api_key
    )
    result = embeddings.embed_query("Hello world")
    print(f"✓ Embeddings working! Vector dimension: {len(result)}")
    
    # Test LLM
    print("\nTesting Gemini LLM...")
    llm = ChatGoogleGenerativeAI(
        model="gemini-2.0-flash-exp",
        google_api_key=api_key
    )
    response = llm.invoke("Say 'API key is working'")
    print(f"✓ LLM working! Response: {response.content}")
    
    print("\n✓ All tests passed! Your API key is valid.")
    
except Exception as e:
    print(f"\n✗ Error: {str(e)}")
    print(f"\nFull error details:")
    import traceback
    traceback.print_exc()
