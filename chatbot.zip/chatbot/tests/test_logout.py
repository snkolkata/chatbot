"""
Tests for logout functionality.

This module tests the logout function and session cleanup.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime

# Mock streamlit before importing modules that use it
import sys
sys.modules['streamlit'] = MagicMock()

from utils.auth_guard import logout, clear_session, is_authenticated


class TestLogoutFunctionality:
    """Test suite for logout functionality."""
    
    @patch('utils.auth_guard.st')
    @patch('utils.auth_guard.logger')
    def test_logout_clears_session_data(self, mock_logger, mock_st):
        """Test that logout clears all session data."""
        # Setup mock session state
        mock_session_state = {
            'user_id': 'test-user-id',
            'email': 'test@example.com',
            'full_name': 'Test User',
            'role': 'user',
            'is_active': True,
            'last_activity': datetime.now(),
            'remember_me': False,
            'authenticated': True,
            'current_session_id': 'session-123',
            'messages': [],
            'user_sessions': []
        }
        
        # Mock session_state to behave like a dict
        mock_st.session_state = mock_session_state
        
        # Perform logout
        logout()
        
        # Verify logging occurred
        assert mock_logger.info.call_count >= 1
        
        # Verify session was cleared (all keys should be deleted)
        # Note: In actual implementation, keys are deleted from session_state
        # Here we just verify the function was called
        assert mock_logger.info.called
    
    @patch('utils.auth_guard.st')
    @patch('utils.auth_guard.logger')
    def test_logout_logs_user_email(self, mock_logger, mock_st):
        """Test that logout logs the user email."""
        # Setup mock session state with user data
        mock_session_state = {
            'user_id': 'test-user-id',
            'email': 'test@example.com',
            'authenticated': True
        }
        
        mock_st.session_state = mock_session_state
        
        # Perform logout
        logout()
        
        # Verify that logging included user information
        log_calls = [str(call) for call in mock_logger.info.call_args_list]
        assert any('test@example.com' in str(call) or 'test-user-id' in str(call) for call in log_calls)
    
    @patch('utils.auth_guard.st')
    def test_clear_session_removes_all_keys(self, mock_st):
        """Test that clear_session removes all authentication keys."""
        # Setup mock session state
        mock_session_state = {
            'user_id': 'test-user-id',
            'email': 'test@example.com',
            'full_name': 'Test User',
            'role': 'user',
            'is_active': True,
            'last_activity': datetime.now(),
            'remember_me': False,
            'authenticated': True,
            'current_session_id': 'session-123',
            'messages': [],
            'user_sessions': [],
            'rag_service': Mock(),
            'document_service': Mock(),
            'services_initialized': True,
            'last_error': None,
            'admin_document_service': Mock(),
            'admin_services_initialized': True,
            'upload_status': None,
            'delete_confirm': None,
            'some_other_key': 'should remain'
        }
        
        # Create a mock that tracks deletions
        deleted_keys = []
        
        def mock_delitem(self, key):
            deleted_keys.append(key)
            if key in mock_session_state:
                del mock_session_state[key]
        
        def mock_contains(self, key):
            return key in mock_session_state
        
        mock_st.session_state.__delitem__ = mock_delitem
        mock_st.session_state.__contains__ = mock_contains
        mock_st.session_state.get = mock_session_state.get
        
        # Perform clear_session
        clear_session()
        
        # Verify that authentication-related keys were deleted
        expected_keys = [
            'user_id', 'email', 'full_name', 'role', 'is_active',
            'last_activity', 'remember_me', 'authenticated',
            'current_session_id', 'messages', 'user_sessions',
            'rag_service', 'document_service', 'services_initialized',
            'last_error', 'admin_document_service', 'admin_services_initialized',
            'upload_status', 'delete_confirm'
        ]
        
        for key in expected_keys:
            assert key in deleted_keys, f"Key '{key}' should have been deleted"
        
        # Verify that non-auth keys remain
        assert 'some_other_key' not in deleted_keys
    
    @patch('utils.auth_guard.st')
    def test_logout_handles_missing_user_data(self, mock_st):
        """Test that logout handles case where user data is missing."""
        # Setup mock session state without user data
        mock_session_state = {}
        mock_st.session_state = mock_session_state
        
        # Should not raise an exception
        try:
            logout()
        except Exception as e:
            pytest.fail(f"logout() raised an exception with missing user data: {e}")
    
    @patch('utils.auth_guard.st')
    def test_is_authenticated_after_logout(self, mock_st):
        """Test that is_authenticated returns False after logout."""
        # Setup mock session state
        mock_session_state = {
            'user_id': 'test-user-id',
            'email': 'test@example.com',
            'authenticated': True
        }
        
        # Create a mock that tracks deletions
        def mock_delitem(self, key):
            if key in mock_session_state:
                del mock_session_state[key]
        
        def mock_contains(self, key):
            return key in mock_session_state
        
        def mock_get(key, default=None):
            return mock_session_state.get(key, default)
        
        mock_st.session_state.__delitem__ = mock_delitem
        mock_st.session_state.__contains__ = mock_contains
        mock_st.session_state.get = mock_get
        
        # Before logout, should be authenticated
        assert 'user_id' in mock_session_state
        
        # Perform logout
        clear_session()
        
        # After logout, user_id should be removed
        assert 'user_id' not in mock_session_state
        
        # is_authenticated should return False
        result = is_authenticated()
        assert result is False


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
