"""
Tests for the email service.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from services.email_service import EmailService


@pytest.fixture
def email_service_configured():
    """Create an email service instance with mocked SMTP configuration."""
    with patch('services.email_service.settings') as mock_settings:
        mock_settings.SMTP_HOST = "smtp.test.com"
        mock_settings.SMTP_PORT = 587
        mock_settings.SMTP_USER = "test@test.com"
        mock_settings.SMTP_PASSWORD = "test_password"
        mock_settings.SMTP_FROM_EMAIL = "noreply@test.com"
        mock_settings.SMTP_FROM_NAME = "Test Service"
        mock_settings.APP_URL = "http://localhost:8501"
        mock_settings.ADMIN_EMAIL = "admin@test.com"
        mock_settings.RESET_TOKEN_EXPIRY_HOURS = 1
        mock_settings.ACCOUNT_LOCKOUT_MINUTES = 15
        
        service = EmailService()
        return service


@pytest.fixture
def email_service_unconfigured():
    """Create an email service instance without SMTP configuration."""
    with patch('services.email_service.settings') as mock_settings:
        mock_settings.SMTP_HOST = ""
        mock_settings.SMTP_PORT = 587
        mock_settings.SMTP_USER = ""
        mock_settings.SMTP_PASSWORD = ""
        mock_settings.SMTP_FROM_EMAIL = "noreply@test.com"
        mock_settings.SMTP_FROM_NAME = "Test Service"
        mock_settings.APP_URL = "http://localhost:8501"
        mock_settings.ADMIN_EMAIL = "admin@test.com"
        mock_settings.RESET_TOKEN_EXPIRY_HOURS = 1
        mock_settings.ACCOUNT_LOCKOUT_MINUTES = 15
        
        service = EmailService()
        return service


class TestEmailService:
    """Test cases for EmailService."""
    
    def test_email_service_initialization_configured(self, email_service_configured):
        """Test that email service initializes correctly when configured."""
        assert email_service_configured.is_configured is True
        assert email_service_configured.smtp_host == "smtp.test.com"
        assert email_service_configured.smtp_port == 587
    
    def test_email_service_initialization_unconfigured(self, email_service_unconfigured):
        """Test that email service initializes correctly when not configured."""
        assert email_service_unconfigured.is_configured is False
    
    @patch('services.email_service.smtplib.SMTP')
    def test_send_password_reset_email_configured(self, mock_smtp, email_service_configured):
        """Test sending password reset email when SMTP is configured."""
        # Setup mock
        mock_server = MagicMock()
        mock_smtp.return_value.__enter__.return_value = mock_server
        
        # Send email
        result = email_service_configured.send_password_reset_email(
            email="user@test.com",
            reset_token="test-token-123",
            full_name="Test User"
        )
        
        # Verify
        assert result is True
        mock_smtp.assert_called_once_with("smtp.test.com", 587)
        mock_server.starttls.assert_called_once()
        mock_server.login.assert_called_once_with("test@test.com", "test_password")
        mock_server.send_message.assert_called_once()
    
    def test_send_password_reset_email_unconfigured(self, email_service_unconfigured, caplog):
        """Test sending password reset email when SMTP is not configured (logs to console)."""
        import logging
        caplog.set_level(logging.INFO, logger='services.email_service')
        
        result = email_service_unconfigured.send_password_reset_email(
            email="user@test.com",
            reset_token="test-token-123",
            full_name="Test User"
        )
        
        # Should return True (logged to console)
        assert result is True
        # Check that it was logged
        assert "EMAIL (Development Mode)" in caplog.text
        assert "user@test.com" in caplog.text
    
    @patch('services.email_service.smtplib.SMTP')
    def test_send_welcome_email_configured(self, mock_smtp, email_service_configured):
        """Test sending welcome email when SMTP is configured."""
        # Setup mock
        mock_server = MagicMock()
        mock_smtp.return_value.__enter__.return_value = mock_server
        
        # Send email
        result = email_service_configured.send_welcome_email(
            email="newuser@test.com",
            full_name="New User"
        )
        
        # Verify
        assert result is True
        mock_server.send_message.assert_called_once()
    
    def test_send_welcome_email_unconfigured(self, email_service_unconfigured, caplog):
        """Test sending welcome email when SMTP is not configured."""
        import logging
        caplog.set_level(logging.INFO, logger='services.email_service')
        
        result = email_service_unconfigured.send_welcome_email(
            email="newuser@test.com",
            full_name="New User"
        )
        
        assert result is True
        assert "EMAIL (Development Mode)" in caplog.text
    
    @patch('services.email_service.smtplib.SMTP')
    def test_send_account_locked_email_configured(self, mock_smtp, email_service_configured):
        """Test sending account locked email when SMTP is configured."""
        # Setup mock
        mock_server = MagicMock()
        mock_smtp.return_value.__enter__.return_value = mock_server
        
        # Send email
        result = email_service_configured.send_account_locked_email(
            email="locked@test.com",
            full_name="Locked User"
        )
        
        # Verify
        assert result is True
        mock_server.send_message.assert_called_once()
    
    def test_send_account_locked_email_unconfigured(self, email_service_unconfigured, caplog):
        """Test sending account locked email when SMTP is not configured."""
        import logging
        caplog.set_level(logging.INFO, logger='services.email_service')
        
        result = email_service_unconfigured.send_account_locked_email(
            email="locked@test.com",
            full_name="Locked User"
        )
        
        assert result is True
        assert "EMAIL (Development Mode)" in caplog.text
    
    @patch('services.email_service.smtplib.SMTP')
    def test_smtp_error_handling(self, mock_smtp, email_service_configured):
        """Test that SMTP errors are handled gracefully."""
        # Setup mock to raise an exception
        mock_smtp.return_value.__enter__.side_effect = Exception("SMTP connection failed")
        
        # Send email
        result = email_service_configured.send_password_reset_email(
            email="user@test.com",
            reset_token="test-token-123"
        )
        
        # Should return False on error
        assert result is False
    
    def test_password_reset_email_contains_token(self, email_service_unconfigured, caplog):
        """Test that password reset email contains the reset token in the link."""
        import logging
        caplog.set_level(logging.INFO, logger='services.email_service')
        
        reset_token = "unique-test-token-456"
        
        email_service_unconfigured.send_password_reset_email(
            email="user@test.com",
            reset_token=reset_token,
            full_name="Test User"
        )
        
        # Check that the token appears in the logged content
        assert reset_token in caplog.text
    
    def test_welcome_email_contains_user_name(self, email_service_unconfigured, caplog):
        """Test that welcome email contains the user's name."""
        import logging
        caplog.set_level(logging.INFO, logger='services.email_service')
        
        full_name = "John Doe"
        
        email_service_unconfigured.send_welcome_email(
            email="john@test.com",
            full_name=full_name
        )
        
        # Check that the name appears in the logged content
        assert full_name in caplog.text
