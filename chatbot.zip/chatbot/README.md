# RAG Chatbot with Streamlit

A Retrieval-Augmented Generation (RAG) based chatbot application that allows users to interact with an AI assistant powered by their own documents. Built with Streamlit, LangChain, ChromaDB, and OpenAI.

## Features

- 🔐 **User Authentication**: Secure registration, login, and password reset functionality
- 👥 **Role-Based Access Control**: User and Admin roles with different permissions
- 💬 **Interactive Chat Interface**: Ask questions and get AI-powered responses based on your documents
- 📝 **Session Management**: Create, manage, and switch between multiple chat sessions
- 📚 **Document Management**: Upload and manage PDF, TXT, and DOCX files through an admin interface
- 🔍 **Smart Retrieval**: Uses vector embeddings to find relevant information from your documents
- 💾 **Persistent Storage**: PostgreSQL database for user data and ChromaDB for vector embeddings
- 📊 **Admin Dashboard**: User management, session analytics, and system monitoring
- 🛡️ **Security Features**: Password hashing, brute force protection, and secure session management
- 📧 **Email Notifications**: Password reset and account notifications via SMTP

## Prerequisites

- Python 3.8 or higher
- OpenAI API key

## Installation

1. **Clone or download this repository**

2. **Install dependencies**

```bash
pip install -r requirements.txt
```

3. **Set up environment variables**

Copy the `.env.example` file to `.env`:

```bash
cp .env.example .env
```

Edit the `.env` file and add your OpenAI API key and database configuration:

```
# OpenAI Configuration
OPENAI_API_KEY=your_api_key_here

# Database Configuration
DATABASE_URL=postgresql://postgres:password@localhost:5432/rag_chatbot

# Other settings
EMBEDDING_MODEL=text-embedding-ada-002
LLM_MODEL=gpt-3.5-turbo
CHUNK_SIZE=1000
CHUNK_OVERLAP=200
VECTOR_STORE_PATH=./data/chroma_db
DOCUMENT_STORAGE_PATH=./data/documents
MAX_FILE_SIZE_MB=10
```

4. **Set up PostgreSQL database**

Ensure PostgreSQL is installed and running, then create the database:

```bash
# Create database
createdb rag_chatbot

# Initialize database tables (choose one method)

# Method 1: Using the unified Database CLI (recommended)
python scripts/db_cli.py init                    # Initialize database
python scripts/db_cli.py create-admin            # Create admin user (interactive)

# Or do both in one step
python scripts/db_cli.py setup --create-admin --email admin@example.com --name "Admin User"

# Method 2: Using Alembic migrations (recommended for production)
python -m alembic upgrade head
python scripts/create_admin.py --email admin@example.com --name "Admin User"

# Method 3: Direct table creation (simpler for development)
python scripts/init_database.py
python scripts/create_admin.py --email admin@example.com --name "Admin User"
```

See `scripts/README.md` for detailed information about database scripts and `alembic/README_MIGRATIONS.md` for database migrations.

5. **Create required directories**

The application will automatically create the necessary directories on first run:
- `data/chroma_db` - Vector store persistence
- `data/documents` - Uploaded document storage
- `logs` - Application logs

## Usage

### Starting the Application

Run the Streamlit application:

```bash
streamlit run Home.py
```

The application will open in your default web browser at `http://localhost:8501`

### First Time Setup

1. **Create an Admin Account**: Use the setup script to create your first admin user:
   ```bash
   python scripts/create_admin.py --email admin@example.com --name "Admin User"
   ```

2. **Register as a User**: Navigate to the registration page and create a user account

3. **Login**: Use your credentials to access the application

### User Registration and Login

**Registration:**
1. Click "Sign up" on the login page
2. Enter your full name, email, and password
3. Password must be at least 8 characters with uppercase, lowercase, and number
4. Accept the terms of service
5. Click "Register" to create your account

**Login:**
1. Enter your email and password on the login page
2. Optionally check "Remember me" to extend your session to 7 days
3. Click "Login" to access the application

**Password Reset:**
1. Click "Forgot password?" on the login page
2. Enter your email address
3. Check your email for the reset link (valid for 1 hour)
4. Click the link and enter your new password

### Chatting with Your Documents

1. After logging in, you'll be on the **Home** page (chat interface)
2. Type your question in the chat input at the bottom
3. Press Enter or click Send
4. The AI will retrieve relevant information from your documents and generate a response
5. View conversation history with timestamps and sources

**Session Management:**
- Create new chat sessions using the "New Chat" button
- Switch between sessions using the session selector
- Rename sessions by editing the session title
- Delete old sessions you no longer need
- All your chat history is automatically saved

### Admin Features

Admins have access to additional features on the **Admin** page:

**User Management:**
- View all registered users
- Change user roles (User ↔ Admin)
- Activate/deactivate user accounts
- Delete users (with confirmation)
- Search users by email

**Session Analytics:**
- View total users and active sessions
- See message volume over time
- Identify most active users
- Monitor average session duration

**Document Management:**
- Upload and manage documents for the knowledge base
- View document statistics
- Delete documents

**System Monitoring:**
- Check database connection status
- View vector store statistics
- Monitor system health

## Project Structure

```
.
├── Home.py                      # Main chatbot interface
├── pages/
│   └── Admin.py                # Admin document management page
├── services/
│   ├── rag_service.py          # RAG orchestration logic
│   ├── document_service.py     # Document processing and management
│   └── vector_store.py         # ChromaDB vector store operations
├── config/
│   └── settings.py             # Configuration management
├── utils/
│   └── helpers.py              # Utility functions and error handling
├── data/                        # Data storage (created automatically)
│   ├── chroma_db/              # Vector store persistence
│   └── documents/              # Uploaded documents
├── logs/                        # Application logs (created automatically)
│   └── app.log
├── requirements.txt             # Python dependencies
├── .env.example                # Example environment variables
└── README.md                   # This file
```

## Configuration

### Environment Variables

All configuration is managed through environment variables in the `.env` file. Below is a comprehensive list of all available settings:

#### LLM Configuration

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `LLM_PROVIDER` | LLM provider to use (`openai` or `gemini`) | `openai` | Yes |
| `OPENAI_API_KEY` | Your OpenAI API key | - | If using OpenAI |
| `GEMINI_API_KEY` | Your Google Gemini API key | - | If using Gemini |
| `EMBEDDING_MODEL` | Embedding model to use | `text-embedding-ada-002` | No |
| `LLM_MODEL` | Language model to use | `gpt-3.5-turbo` | No |

#### Document Processing

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `CHUNK_SIZE` | Document chunk size in characters | `1000` | No |
| `CHUNK_OVERLAP` | Overlap between chunks in characters | `200` | No |
| `MAX_FILE_SIZE_MB` | Maximum file upload size in MB | `10` | No |

#### Storage Configuration

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `VECTOR_STORE_PATH` | Path to ChromaDB storage | `./data/chroma_db` | No |
| `DOCUMENT_STORAGE_PATH` | Path to document storage | `./data/documents` | No |

#### Database Configuration

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://postgres:postgres@localhost:5432/rag_chatbot` | Yes |
| `DATABASE_POOL_SIZE` | Connection pool size | `5` | No |
| `DATABASE_MAX_OVERFLOW` | Max overflow connections | `10` | No |
| `DATABASE_POOL_TIMEOUT` | Connection timeout in seconds | `30` | No |
| `DATABASE_POOL_RECYCLE` | Connection recycle time in seconds | `3600` | No |

#### Session Configuration

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `SESSION_TIMEOUT_HOURS` | Session timeout in hours | `24` | No |
| `SESSION_REMEMBER_ME_DAYS` | "Remember me" duration in days | `7` | No |

#### Security Configuration

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `PASSWORD_MIN_LENGTH` | Minimum password length | `8` | No |
| `MAX_LOGIN_ATTEMPTS` | Max failed login attempts before lockout | `5` | No |
| `ACCOUNT_LOCKOUT_MINUTES` | Account lockout duration in minutes | `15` | No |
| `RESET_TOKEN_EXPIRY_HOURS` | Password reset token expiry in hours | `1` | No |
| `BCRYPT_COST_FACTOR` | Bcrypt hashing cost factor (higher = more secure but slower) | `12` | No |

#### Email Configuration

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `SMTP_HOST` | SMTP server hostname | - | For email features |
| `SMTP_PORT` | SMTP server port | `587` | No |
| `SMTP_USER` | SMTP username | - | For email features |
| `SMTP_PASSWORD` | SMTP password or app password | - | For email features |
| `SMTP_FROM_EMAIL` | From email address | `noreply@ragchatbot.com` | No |
| `SMTP_FROM_NAME` | From name | `RAG Chatbot` | No |

#### Application Configuration

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `APP_URL` | Application URL (for email links) | `http://localhost:8501` | No |
| `ADMIN_EMAIL` | Default admin email | `admin@example.com` | No |

### Configuration Notes

**Security Best Practices:**
- The `BCRYPT_COST_FACTOR` of 12 provides strong security. Increasing it will make password hashing slower but more secure.
- Failed login attempts are tracked per email address. After `MAX_LOGIN_ATTEMPTS` failures, the account is locked for `ACCOUNT_LOCKOUT_MINUTES`.
- Password reset tokens expire after `RESET_TOKEN_EXPIRY_HOURS` and can only be used once.
- All passwords must meet the minimum length requirement and contain at least one uppercase letter, one lowercase letter, and one number.

**Database Connection:**
- The `DATABASE_URL` format is: `postgresql://username:password@host:port/database`
- Connection pooling helps manage database connections efficiently. Adjust pool settings based on your expected load.
- The pool recycles connections after `DATABASE_POOL_RECYCLE` seconds to prevent stale connections.

**Email Configuration:**
- Email features (password reset, welcome emails) require SMTP configuration.
- For Gmail, use an App Password instead of your regular password.
- In development, emails will be logged to console if SMTP is not configured.

**Session Management:**
- Sessions expire after `SESSION_TIMEOUT_HOURS` of inactivity.
- The "Remember me" option extends session duration to `SESSION_REMEMBER_ME_DAYS`.
- Session data is stored in PostgreSQL for persistence across application restarts

### Supported File Types

- PDF (`.pdf`)
- Text files (`.txt`)
- Microsoft Word documents (`.docx`)

## How It Works

1. **Document Upload**: Documents are uploaded through the Admin interface and processed into smaller chunks
2. **Embedding Generation**: Each chunk is converted into a vector embedding using OpenAI's embedding model
3. **Vector Storage**: Embeddings are stored in ChromaDB for efficient similarity search
4. **Query Processing**: When you ask a question, the system:
   - Converts your query into an embedding
   - Searches for the most relevant document chunks
   - Sends the relevant context to the LLM
   - Generates a response based on the retrieved information

## Troubleshooting

### "Failed to initialize services" Error

- Ensure your `.env` file exists and contains a valid `OPENAI_API_KEY`
- Check that you have internet connectivity to reach OpenAI's API
- Verify that the API key has sufficient credits

### Documents Not Uploading

- Check that the file format is supported (PDF, TXT, or DOCX)
- Ensure the file size is under the configured limit (default 10MB)
- Check the logs at `logs/app.log` for detailed error messages

### No Relevant Information Found

- Make sure you have uploaded documents to the knowledge base
- Try rephrasing your question
- Upload more documents related to your query topic

### ChromaDB Errors

- Delete the `data/chroma_db` directory and restart the application to reset the vector store
- Ensure you have write permissions in the data directory

## Logging

Application logs are stored in `logs/app.log` and include:
- Service initialization events
- Document upload and processing activities
- Query processing and retrieval operations
- Error messages with stack traces

## Security Features

The application implements comprehensive security measures:

**Password Security:**
- Passwords are hashed using bcrypt with cost factor 12
- Minimum password requirements: 8 characters, uppercase, lowercase, and number
- Passwords are never stored in plain text
- Password reset tokens expire after 1 hour and are single-use

**Brute Force Protection:**
- Failed login attempts are tracked per email address
- After 5 failed attempts, accounts are locked for 15 minutes
- Account lockout notifications are sent via email

**Session Security:**
- Sessions expire after 24 hours of inactivity (or 7 days with "Remember me")
- Session data is stored securely in PostgreSQL
- Automatic logout on session expiration

**Database Security:**
- PostgreSQL with connection pooling
- SQL injection prevention through SQLAlchemy ORM
- Parameterized queries for all database operations

**Best Practices:**
- Never commit your `.env` file to version control
- Keep your API keys and database credentials secure
- Use strong passwords for database and admin accounts
- Enable HTTPS in production environments
- Regularly update dependencies for security patches
- Use environment-specific configurations for dev/staging/production

## License

This project is provided as-is for educational and development purposes.

## Support

For issues or questions:
1. Check the logs at `logs/app.log` for detailed error information
2. Verify your configuration in the `.env` file
3. Ensure all dependencies are installed correctly

## Future Enhancements

- User authentication and authorization
- Support for additional document formats
- Advanced search filters and options
- Export conversation history
- Multi-language support
- Custom embedding models


   Email: user@example.com
  Password: User123!

Admin User:
  Email: admin@example.com
   Password: Admin123!
