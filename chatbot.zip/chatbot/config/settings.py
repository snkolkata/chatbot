import os
from typing import List
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


class Settings:
    """
    Configuration settings for the RAG chatbot application.
    
    All settings are loaded from environment variables with sensible defaults.
    See .env.example for a complete list of available configuration options.
    """
    
    # ============================================================================
    # LLM Configuration
    # ============================================================================
    LLM_PROVIDER: str = os.getenv("LLM_PROVIDER", "openai")  # "openai" or "gemini"
    EMBEDDING_PROVIDER: str = os.getenv("EMBEDDING_PROVIDER", os.getenv("LLM_PROVIDER", "openai"))  # "openai" or "gemini"
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "") or os.getenv("GOOGLE_API_KEY", "")
    EMBEDDING_MODEL: str = os.getenv("EMBEDDING_MODEL", "text-embedding-ada-002")
    LLM_MODEL: str = os.getenv("LLM_MODEL", "gpt-3.5-turbo")
    
    # ============================================================================
    # Document Processing Configuration
    # ============================================================================
    CHUNK_SIZE: int = int(os.getenv("CHUNK_SIZE", "1000"))
    CHUNK_OVERLAP: int = int(os.getenv("CHUNK_OVERLAP", "200"))
    
    # ============================================================================
    # Storage Configuration
    # ============================================================================
    VECTOR_STORE_PATH: str = os.getenv("VECTOR_STORE_PATH", "./data/chroma_db")
    DOCUMENT_STORAGE_PATH: str = os.getenv("DOCUMENT_STORAGE_PATH", "./data/documents")
    
    # ============================================================================
    # File Upload Configuration
    # ============================================================================
    MAX_FILE_SIZE_MB: int = int(os.getenv("MAX_FILE_SIZE_MB", "10"))
    SUPPORTED_FILE_TYPES: List[str] = [".pdf", ".txt", ".docx"]
    
    # ============================================================================
    # Database Configuration
    # ============================================================================
    # PostgreSQL connection string format: postgresql://user:password@host:port/database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/rag_chatbot")
    
    # Connection pool settings for optimal database performance
    DATABASE_POOL_SIZE: int = int(os.getenv("DATABASE_POOL_SIZE", "5"))  # Number of connections to maintain
    DATABASE_MAX_OVERFLOW: int = int(os.getenv("DATABASE_MAX_OVERFLOW", "10"))  # Max additional connections
    DATABASE_POOL_TIMEOUT: int = int(os.getenv("DATABASE_POOL_TIMEOUT", "30"))  # Timeout in seconds
    DATABASE_POOL_RECYCLE: int = int(os.getenv("DATABASE_POOL_RECYCLE", "3600"))  # Recycle connections after 1 hour
    
    # ============================================================================
    # Session Configuration
    # ============================================================================
    # Session timeout for regular login (in hours)
    SESSION_TIMEOUT_HOURS: int = int(os.getenv("SESSION_TIMEOUT_HOURS", "24"))
    
    # Extended session duration when "Remember me" is checked (in days)
    SESSION_REMEMBER_ME_DAYS: int = int(os.getenv("SESSION_REMEMBER_ME_DAYS", "7"))
    
    # ============================================================================
    # Security Configuration
    # ============================================================================
    # Password requirements
    PASSWORD_MIN_LENGTH: int = int(os.getenv("PASSWORD_MIN_LENGTH", "8"))
    # Note: Passwords must also contain at least one uppercase, lowercase, and number
    
    # Brute force protection settings
    MAX_LOGIN_ATTEMPTS: int = int(os.getenv("MAX_LOGIN_ATTEMPTS", "5"))  # Failed attempts before lockout
    ACCOUNT_LOCKOUT_MINUTES: int = int(os.getenv("ACCOUNT_LOCKOUT_MINUTES", "15"))  # Lockout duration
    
    # Password reset token expiration (in hours)
    RESET_TOKEN_EXPIRY_HOURS: int = int(os.getenv("RESET_TOKEN_EXPIRY_HOURS", "1"))
    
    # Bcrypt cost factor (higher = more secure but slower; recommended: 12-14)
    BCRYPT_COST_FACTOR: int = int(os.getenv("BCRYPT_COST_FACTOR", "12"))
    
    # ============================================================================
    # Email Configuration
    # ============================================================================
    # SMTP server settings for sending emails (password reset, notifications)
    SMTP_HOST: str = os.getenv("SMTP_HOST", "")
    SMTP_PORT: int = int(os.getenv("SMTP_PORT", "587"))
    SMTP_USER: str = os.getenv("SMTP_USER", "")
    SMTP_PASSWORD: str = os.getenv("SMTP_PASSWORD", "")
    
    # Email sender information
    SMTP_FROM_EMAIL: str = os.getenv("SMTP_FROM_EMAIL", "noreply@ragchatbot.com")
    SMTP_FROM_NAME: str = os.getenv("SMTP_FROM_NAME", "RAG Chatbot")
    
    # ============================================================================
    # Application Configuration
    # ============================================================================
    # Base URL for the application (used in email links)
    APP_URL: str = os.getenv("APP_URL", "http://localhost:8501")
    
    # Default admin email for system notifications
    ADMIN_EMAIL: str = os.getenv("ADMIN_EMAIL", "admin@example.com")
    
    @classmethod
    def validate(cls) -> bool:
        """Validate that required settings are configured."""
        if cls.LLM_PROVIDER == "openai" and not cls.OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY is required but not set")
        if cls.LLM_PROVIDER == "gemini" and not cls.GEMINI_API_KEY:
            raise ValueError("GEMINI_API_KEY is required but not set")
        return True


# Create a singleton instance
settings = Settings()
