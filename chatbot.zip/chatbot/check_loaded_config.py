"""Check what configuration is actually loaded"""
import os
import sys
sys.path.insert(0, '.')

from dotenv import load_dotenv
load_dotenv(override=True)

from config.settings import settings

print("="*60)
print("LOADED CONFIGURATION")
print("="*60)
print(f"GEMINI_API_KEY from env: {os.getenv('GEMINI_API_KEY')}")
print(f"GEMINI_API_KEY from settings: {settings.GEMINI_API_KEY}")
print(f"EMBEDDING_PROVIDER: {settings.EMBEDDING_PROVIDER}")
print(f"EMBEDDING_MODEL: {settings.EMBEDDING_MODEL}")
print(f"LLM_PROVIDER: {settings.LLM_PROVIDER}")
print(f"LLM_MODEL: {settings.LLM_MODEL}")
print("="*60)
