"""
Script to create dummy users for testing.
Creates one regular user and one admin user.
"""
import sys
import os
import logging

# Add parent directory to path to import modules
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from services.database_manager import DatabaseManager
from services.models import User
import bcrypt

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def hash_password(password: str) -> str:
    """Hash a password using bcrypt."""
    salt = bcrypt.gensalt(rounds=12)
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')


def create_dummy_users():
    """Create dummy users for testing."""
    try:
        # Initialize database
        DatabaseManager.initialize()
        logger.info("Database engine initialized")
        
        with DatabaseManager.get_session() as session:
            # Dummy users data
            users_data = [
                {
                    'email': 'user@example.com',
                    'password': 'User123!',
                    'full_name': 'Test User',
                    'role': 'user'
                },
                {
                    'email': 'admin@example.com',
                    'password': 'Admin123!',
                    'full_name': 'Test Admin',
                    'role': 'admin'
                }
            ]
            
            created_count = 0
            
            for user_data in users_data:
                # Check if user already exists
                existing_user = session.query(User).filter_by(email=user_data['email']).first()
                if existing_user:
                    logger.info(f"User {user_data['email']} already exists, skipping...")
                    continue
                
                # Hash password
                password_hash = hash_password(user_data['password'])
                
                # Create user
                user = User(
                    email=user_data['email'],
                    password_hash=password_hash,
                    full_name=user_data['full_name'],
                    role=user_data['role'],
                    is_active=True
                )
                
                session.add(user)
                created_count += 1
                logger.info(f"Created {user_data['role']}: {user_data['email']}")
            
            session.commit()
            
            if created_count > 0:
                logger.info(f"\n{'='*50}")
                logger.info("Dummy users created successfully!")
                logger.info(f"{'='*50}")
                logger.info("\nLogin credentials:")
                logger.info("\nRegular User:")
                logger.info("  Email: user@example.com")
                logger.info("  Password: User123!")
                logger.info("\nAdmin User:")
                logger.info("  Email: admin@example.com")
                logger.info("  Password: Admin123!")
                logger.info(f"{'='*50}\n")
            else:
                logger.info("All users already exist. No new users created.")
            
            return True
            
    except Exception as e:
        logger.error(f"Failed to create dummy users: {e}")
        return False
    finally:
        DatabaseManager.close()


if __name__ == "__main__":
    success = create_dummy_users()
    sys.exit(0 if success else 1)
