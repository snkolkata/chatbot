# Database Scripts

This directory contains scripts for database initialization, management, and administration.

## Overview

The database scripts provide a complete toolkit for setting up and managing the PostgreSQL database for the RAG chatbot application.

## Available Scripts

### 1. Database CLI (Recommended)

**`db_cli.py`** - Unified command-line interface for all database operations.

```bash
# Show available commands
python scripts/db_cli.py --help

# Initialize database schema
python scripts/db_cli.py init

# Check database health
python scripts/db_cli.py check

# Create admin user (interactive)
python scripts/db_cli.py create-admin

# Complete setup with admin user
python scripts/db_cli.py setup --create-admin --email admin@example.com --name "Admin User"
```

### 2. Individual Scripts

#### Initialize Database
**`init_database.py`** - Creates all database tables and indexes.

```bash
python scripts/init_database.py
```

This script:
- Initializes the database engine
- Performs a health check
- Creates all tables (users, chat_sessions, chat_messages, password_reset_tokens)
- Creates all indexes defined in the models
- Displays connection pool information

#### Check Database Health
**`check_database.py`** - Verifies database connectivity and displays connection pool stats.

```bash
python scripts/check_database.py
```

This script:
- Tests database connectivity
- Displays connection pool statistics
- Shows pool size, checked in/out connections, overflow connections

#### Create Admin User
**`create_admin.py`** - Creates an admin user with specified credentials.

```bash
# Interactive mode
python scripts/create_admin.py --interactive

# With parameters
python scripts/create_admin.py --email admin@example.com --name "Admin User"

# With all parameters (password will be prompted securely)
python scripts/create_admin.py --email admin@example.com --password SecurePass123 --name "Admin User"
```

This script:
- Validates email format
- Validates password strength (min 8 chars, uppercase, lowercase, number)
- Checks for duplicate emails
- Hashes password using bcrypt (cost factor 12)
- Creates admin user with role="admin"

#### Complete Setup
**`setup_database.py`** - Comprehensive setup script that can initialize database and create admin user.

```bash
# Initialize database only
python scripts/setup_database.py

# Initialize and create admin user
python scripts/setup_database.py --create-admin --email admin@example.com --name "Admin User"

# Use Alembic migrations instead of direct table creation
python scripts/setup_database.py --use-alembic

# Complete setup with Alembic and admin user
python scripts/setup_database.py --use-alembic --create-admin --email admin@example.com --name "Admin User"
```

## Quick Start

### First Time Setup

1. **Configure database connection** in `.env`:
   ```bash
   DATABASE_URL=postgresql://username:password@localhost:5432/rag_chatbot
   ```

2. **Initialize database**:
   ```bash
   python scripts/db_cli.py init
   ```

3. **Create admin user**:
   ```bash
   python scripts/db_cli.py create-admin
   ```

### Alternative: One-Step Setup

```bash
python scripts/db_cli.py setup --create-admin --email admin@example.com --name "Admin User"
```

## Database Schema

The scripts create the following tables:

### users
- `user_id` (UUID, Primary Key)
- `email` (String, Unique, Indexed)
- `password_hash` (String)
- `full_name` (String)
- `role` (String: 'user' or 'admin', Indexed)
- `is_active` (Boolean)
- `failed_login_attempts` (Integer)
- `account_locked_until` (DateTime)
- `created_at` (DateTime)
- `last_login` (DateTime)

### chat_sessions
- `session_id` (UUID, Primary Key)
- `user_id` (UUID, Foreign Key → users)
- `title` (String)
- `is_active` (Boolean)
- `created_at` (DateTime)
- `updated_at` (DateTime, Indexed)

### chat_messages
- `message_id` (UUID, Primary Key)
- `session_id` (UUID, Foreign Key → chat_sessions)
- `role` (String: 'user' or 'assistant')
- `content` (Text)
- `sources` (JSONB)
- `created_at` (DateTime, Indexed)

### password_reset_tokens
- `token_id` (UUID, Primary Key)
- `user_id` (UUID, Foreign Key → users)
- `token` (String, Unique, Indexed)
- `expires_at` (DateTime)
- `used` (Boolean)
- `created_at` (DateTime)

## Password Requirements

Admin passwords must meet the following requirements:
- Minimum 8 characters
- At least one uppercase letter
- At least one lowercase letter
- At least one number

## Error Handling

All scripts include comprehensive error handling:
- Database connection errors
- Validation errors
- Duplicate email errors
- Password strength errors
- Transaction rollback on failures

## Logging

All scripts use Python's logging module with INFO level by default. Logs include:
- Timestamps
- Operation status
- Error messages with context
- Connection pool statistics

## Using Alembic Migrations

For production environments, it's recommended to use Alembic migrations instead of direct table creation:

```bash
# Apply all migrations
python -m alembic upgrade head

# Create admin user after migrations
python scripts/create_admin.py --email admin@example.com --name "Admin User"
```

See `alembic/README_MIGRATIONS.md` for more information about database migrations.

## Troubleshooting

### Connection Errors

If you see connection errors:
1. Verify PostgreSQL is running
2. Check DATABASE_URL in `.env`
3. Verify database credentials
4. Ensure database exists: `createdb rag_chatbot`

### Permission Errors

If you see permission errors:
1. Verify database user has CREATE TABLE permissions
2. Check database user has INSERT permissions

### Password Validation Errors

If password validation fails:
- Ensure password is at least 8 characters
- Include uppercase, lowercase, and numbers
- Avoid common passwords

## Environment Variables

Required environment variables (set in `.env`):

```bash
# Database Configuration
DATABASE_URL=postgresql://user:password@localhost:5432/rag_chatbot
DATABASE_POOL_SIZE=5
DATABASE_MAX_OVERFLOW=10
DATABASE_POOL_TIMEOUT=30
DATABASE_POOL_RECYCLE=3600
```

## Security Notes

- Passwords are hashed using bcrypt with cost factor 12
- Never commit `.env` file to version control
- Use strong passwords for admin accounts
- Regularly rotate admin passwords
- Monitor failed login attempts

## Development vs Production

### Development
```bash
# Use direct table creation for quick setup
python scripts/db_cli.py init
```

### Production
```bash
# Use Alembic migrations for version control
python scripts/db_cli.py setup --use-alembic
```

## Additional Resources

- Database Manager: `services/database_manager.py`
- Database Models: `services/models.py`
- Alembic Migrations: `alembic/README_MIGRATIONS.md`
- Configuration: `config/settings.py`
