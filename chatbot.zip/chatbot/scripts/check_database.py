"""
Database health check script.
Verifies database connectivity and displays connection pool information.
"""
import sys
import os
import logging

# Add parent directory to path to import modules
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from services.database_manager import DatabaseManager
from config.settings import settings

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def check_database():
    """
    Perform database health check and display connection information.
    """
    try:
        logger.info("Starting database health check...")
        logger.info(f"Database URL: {settings.DATABASE_URL.split('@')[1] if '@' in settings.DATABASE_URL else 'N/A'}")
        
        # Initialize database engine
        DatabaseManager.initialize()
        logger.info("Database engine initialized")
        
        # Perform health check
        is_healthy = DatabaseManager.health_check()
        
        if is_healthy:
            logger.info("✓ Database is healthy and accessible")
            
            # Display connection pool info
            conn_info = DatabaseManager.get_connection_info()
            logger.info("Connection Pool Information:")
            logger.info(f"  - Status: {conn_info.get('status')}")
            logger.info(f"  - Pool Size: {conn_info.get('pool_size')}")
            logger.info(f"  - Checked In: {conn_info.get('checked_in_connections')}")
            logger.info(f"  - Checked Out: {conn_info.get('checked_out_connections')}")
            logger.info(f"  - Overflow: {conn_info.get('overflow_connections')}")
            logger.info(f"  - Total: {conn_info.get('total_connections')}")
            
            return True
        else:
            logger.error("✗ Database health check failed")
            return False
        
    except Exception as e:
        logger.error(f"Database health check error: {e}")
        return False
    finally:
        # Close connections
        DatabaseManager.close()


if __name__ == "__main__":
    success = check_database()
    sys.exit(0 if success else 1)
