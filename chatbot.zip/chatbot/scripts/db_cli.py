"""
Database CLI - Unified interface for database operations.

This script provides a simple command-line interface for common database operations:
- Initialize database schema
- Check database health
- Create admin user
- Run database setup

Usage:
    python scripts/db_cli.py init          # Initialize database schema
    python scripts/db_cli.py check         # Check database health
    python scripts/db_cli.py create-admin  # Create admin user (interactive)
    python scripts/db_cli.py setup         # Complete setup (init + optional admin)
"""
import sys
import os
import argparse

# Add parent directory to path to import modules
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


def print_banner():
    """Print CLI banner."""
    print("=" * 60)
    print("  RAG Chatbot - Database CLI")
    print("=" * 60)
    print()


def run_init():
    """Run database initialization."""
    print("Running database initialization...")
    print()
    from scripts.init_database import init_database
    success = init_database()
    return success


def run_check():
    """Run database health check."""
    print("Running database health check...")
    print()
    from scripts.check_database import check_database
    success = check_database()
    return success


def run_create_admin():
    """Run admin user creation (interactive)."""
    print("Creating admin user...")
    print()
    from scripts.create_admin import main as create_admin_main
    success = create_admin_main()
    return success


def run_setup():
    """Run complete database setup."""
    print("Running complete database setup...")
    print()
    from scripts.setup_database import main as setup_main
    success = setup_main()
    return success


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description='Database CLI for RAG Chatbot',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python scripts/db_cli.py init
  python scripts/db_cli.py check
  python scripts/db_cli.py create-admin
  python scripts/db_cli.py setup --create-admin --email admin@example.com --name "Admin User"
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    # Init command
    subparsers.add_parser('init', help='Initialize database schema')
    
    # Check command
    subparsers.add_parser('check', help='Check database health')
    
    # Create admin command
    subparsers.add_parser('create-admin', help='Create admin user (interactive)')
    
    # Setup command
    setup_parser = subparsers.add_parser('setup', help='Complete database setup')
    setup_parser.add_argument('--create-admin', action='store_true', help='Create admin user after initialization')
    setup_parser.add_argument('--email', type=str, help='Admin email address')
    setup_parser.add_argument('--password', type=str, help='Admin password')
    setup_parser.add_argument('--name', type=str, help='Admin full name')
    setup_parser.add_argument('--use-alembic', action='store_true', help='Use Alembic migrations')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return False
    
    print_banner()
    
    # Execute command
    if args.command == 'init':
        success = run_init()
    elif args.command == 'check':
        success = run_check()
    elif args.command == 'create-admin':
        success = run_create_admin()
    elif args.command == 'setup':
        # Pass arguments to setup script
        sys.argv = ['setup_database.py']
        if args.create_admin:
            sys.argv.append('--create-admin')
        if args.email:
            sys.argv.extend(['--email', args.email])
        if args.password:
            sys.argv.extend(['--password', args.password])
        if args.name:
            sys.argv.extend(['--name', args.name])
        if args.use_alembic:
            sys.argv.append('--use-alembic')
        success = run_setup()
    else:
        print(f"Unknown command: {args.command}")
        return False
    
    print()
    if success:
        print("✓ Operation completed successfully")
    else:
        print("✗ Operation failed")
    
    return success


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
