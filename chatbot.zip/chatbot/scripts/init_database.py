"""
Database initialization script.
Creates all tables and sets up the database schema.

This script creates tables directly using SQLAlchemy models.
For production environments, consider using Alembic migrations instead:
    python -m alembic upgrade head

See alembic/README_MIGRATIONS.md for more information.
"""
import sys
import os
import logging

# Add parent directory to path to import modules
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from services.database_manager import DatabaseManager
from services.models import User, ChatSession, ChatMessage, PasswordResetToken

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def init_database():
    """
    Initialize the database by creating all tables.
    """
    try:
        logger.info("Starting database initialization...")
        
        # Initialize database engine
        DatabaseManager.initialize()
        logger.info("Database engine initialized")
        
        # Perform health check
        if not DatabaseManager.health_check():
            logger.error("Database health check failed")
            return False
        
        logger.info("Database health check passed")
        
        # Create all tables
        logger.info("Creating database tables...")
        DatabaseManager.create_tables()
        logger.info("Database tables created successfully")
        
        # Display connection info
        conn_info = DatabaseManager.get_connection_info()
        logger.info(f"Connection pool info: {conn_info}")
        
        logger.info("Database initialization completed successfully!")
        return True
        
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        return False
    finally:
        # Close connections
        DatabaseManager.close()


if __name__ == "__main__":
    success = init_database()
    sys.exit(0 if success else 1)
