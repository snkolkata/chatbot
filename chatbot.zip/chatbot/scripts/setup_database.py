"""
Complete database setup script.
Initializes database and optionally creates an admin user.

Usage:
    # Initialize database only
    python scripts/setup_database.py
    
    # Initialize database and create admin user
    python scripts/setup_database.py --create-admin --email admin@example.com --name "Admin User"
"""
import sys
import os
import argparse
import logging
import getpass

# Add parent directory to path to import modules
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from services.database_manager import DatabaseManager
from services.models import User
import bcrypt

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def validate_password(password: str) -> bool:
    """Validate password meets minimum security requirements."""
    if len(password) < 8:
        logger.error("Password must be at least 8 characters long")
        return False
    
    if not any(c.isupper() for c in password):
        logger.error("Password must contain at least one uppercase letter")
        return False
    
    if not any(c.islower() for c in password):
        logger.error("Password must contain at least one lowercase letter")
        return False
    
    if not any(c.isdigit() for c in password):
        logger.error("Password must contain at least one number")
        return False
    
    return True


def hash_password(password: str) -> str:
    """Hash a password using bcrypt."""
    salt = bcrypt.gensalt(rounds=12)
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')


def init_database() -> bool:
    """Initialize the database by creating all tables."""
    try:
        logger.info("Starting database initialization...")
        
        # Initialize database engine
        DatabaseManager.initialize()
        logger.info("Database engine initialized")
        
        # Perform health check
        if not DatabaseManager.health_check():
            logger.error("Database health check failed")
            return False
        
        logger.info("Database health check passed")
        
        # Create all tables
        logger.info("Creating database tables...")
        DatabaseManager.create_tables()
        logger.info("Database tables created successfully")
        
        return True
        
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        return False


def create_admin_user(email: str, password: str, full_name: str) -> bool:
    """Create an admin user in the database."""
    try:
        # Validate password
        if not validate_password(password):
            return False
        
        # Check if user already exists
        with DatabaseManager.get_session() as session:
            existing_user = session.query(User).filter_by(email=email).first()
            if existing_user:
                logger.error(f"User with email {email} already exists")
                return False
            
            # Hash password
            password_hash = hash_password(password)
            
            # Create admin user
            admin_user = User(
                email=email,
                password_hash=password_hash,
                full_name=full_name,
                role="admin",
                is_active=True
            )
            
            session.add(admin_user)
            session.commit()
            
            logger.info(f"Admin user created successfully: {email}")
            logger.info(f"User ID: {admin_user.user_id}")
            return True
            
    except Exception as e:
        logger.error(f"Failed to create admin user: {e}")
        return False


def main():
    """Main function to parse arguments and setup database."""
    parser = argparse.ArgumentParser(description='Setup database for RAG chatbot')
    parser.add_argument('--create-admin', action='store_true', help='Create an admin user after initialization')
    parser.add_argument('--email', type=str, help='Admin email address')
    parser.add_argument('--password', type=str, help='Admin password (will prompt if not provided)')
    parser.add_argument('--name', type=str, help='Admin full name')
    parser.add_argument('--use-alembic', action='store_true', help='Use Alembic migrations instead of direct table creation')
    
    args = parser.parse_args()
    
    try:
        # Initialize database
        if args.use_alembic:
            logger.info("Using Alembic migrations for database setup")
            logger.info("Run: python -m alembic upgrade head")
            import subprocess
            result = subprocess.run([sys.executable, '-m', 'alembic', 'upgrade', 'head'], 
                                  capture_output=True, text=True)
            if result.returncode != 0:
                logger.error(f"Alembic migration failed: {result.stderr}")
                return False
            logger.info("Alembic migrations applied successfully")
            # Still need to initialize the engine for admin user creation
            DatabaseManager.initialize()
        else:
            if not init_database():
                return False
        
        # Create admin user if requested
        if args.create_admin:
            logger.info("\n=== Creating Admin User ===")
            
            if not args.email or not args.name:
                email = args.email or input("Enter admin email: ")
                full_name = args.name or input("Enter admin full name: ")
            else:
                email = args.email
                full_name = args.name
            
            password = args.password or getpass.getpass("Enter admin password: ")
            if not args.password:
                password_confirm = getpass.getpass("Confirm admin password: ")
                if password != password_confirm:
                    logger.error("Passwords do not match")
                    return False
            
            if not create_admin_user(email, password, full_name):
                return False
        
        logger.info("\n=== Database Setup Complete ===")
        if not args.create_admin:
            logger.info("To create an admin user, run:")
            logger.info("  python scripts/create_admin.py --email admin@example.com --name 'Admin User'")
        
        return True
        
    except Exception as e:
        logger.error(f"Setup failed: {e}")
        return False
    finally:
        # Close connections
        DatabaseManager.close()


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
