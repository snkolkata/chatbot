"""Database initialization and management scripts."""
