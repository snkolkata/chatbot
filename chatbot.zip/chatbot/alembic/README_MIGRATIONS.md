# Database Migrations with Alembic

This directory contains database migration scripts managed by Alembic.

## Setup

Alembic is already configured and ready to use. The configuration automatically reads the database URL from your `.env` file.

## Common Commands

### Apply all pending migrations
```bash
python -m alembic upgrade head
```

### Revert the last migration
```bash
python -m alembic downgrade -1
```

### Revert all migrations
```bash
python -m alembic downgrade base
```

### Create a new migration (auto-generate from model changes)
```bash
python -m alembic revision --autogenerate -m "Description of changes"
```

### Create a new empty migration
```bash
python -m alembic revision -m "Description of changes"
```

### View migration history
```bash
python -m alembic history
```

### View current migration version
```bash
python -m alembic current
```

## Initial Setup

When setting up a new database:

1. Ensure PostgreSQL is running and the database exists
2. Configure DATABASE_URL in your `.env` file
3. Run migrations:
   ```bash
   python -m alembic upgrade head
   ```
4. Create an admin user:
   ```bash
   python scripts/create_admin.py --email admin@example.com --name "Admin User"
   ```

## Migration Files

Migration files are stored in `alembic/versions/` and are automatically applied in order based on their revision IDs.

### Current Migrations

- `001_initial_migration.py`: Creates all tables for user authentication and session management
  - users table
  - chat_sessions table
  - chat_messages table
  - password_reset_tokens table

## Best Practices

1. **Always review auto-generated migrations** before applying them
2. **Test migrations** on a development database first
3. **Backup production data** before running migrations
4. **Never edit applied migrations** - create a new migration instead
5. **Keep migrations small and focused** on specific changes

## Troubleshooting

### Connection Issues

If you get database connection errors:
- Verify DATABASE_URL in `.env` is correct
- Ensure PostgreSQL is running
- Check database credentials and permissions

### Migration Conflicts

If you have migration conflicts:
```bash
# View current state
python -m alembic current

# View history
python -m alembic history

# Resolve by downgrading and reapplying
python -m alembic downgrade <revision>
python -m alembic upgrade head
```

## Alternative: Direct Table Creation

If you prefer not to use migrations, you can create tables directly:

```bash
python scripts/init_database.py
```

This will create all tables based on the SQLAlchemy models without using Alembic.
